-----------------------------------------------------------------
-----------------------------------------------------------------
-- MASS EFFECT: UNIFICATION Sides Script by A. Gilbert
-- Version 10304/03
-- Screen Names: Marth8880, GT-Marth8880, [GT] Marth8880, [GT] Bran
-- E-Mail: Marth8880@gmail.com
-- Mar 4, 2014
-- Copyright (c) 2014 A. Gilbert.

-- About this script: The purpose of script is to simplify the process 
-- of loading a map's sides, music, and some other related things.

-- Usage:
-- Load the script using ScriptCB_DoFile() in your main mission script
-- Call whichever functions you need out of this script. Example:
-- 
-- LoadSSV()
-- LoadGTH()
-- Setup_SSVxGTH_sm()
-- 
-- The above example would load and then set up the Systems Alliance and Geth side


-- Legal Stuff:
-- You are welcome to use this script in your custom-made mods and maps so long as they are not being rented or sold.
-- If you use this script, please credit me in the readme of the project you used it in.
-- Do not claim this script as your own. It may not be much, but I did spend some time writing it after all.
-- You may edit this script as you need in order to make it work with your own map or mod.
-- I am not responsible for any damages that might be incurred through the use of this script.
-- THIS SCRIPT IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS, A DIVISION OF LUCASFILM ENTERTAINMENT COMPANY LTD.
-----------------------------------------------------------------
-----------------------------------------------------------------
	print("ME5_RandomSides: Entered")
	print("ME5_RandomSides: Mass Effect: Unification is currently running on Build 10304/03, Release 3, Version 1.11")
	print("ME5_RandomSides: Checking configuration parameters...")
if ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_AIHeroes_0") == 1 then
		print("ME5_ConfigCheck: AI Heroes are DISABLED")
	ME5_AIHeroes = 0
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_AIHeroes_1") == 1 then
		print("ME5_ConfigCheck: AI Heroes are ENABLED")
	ME5_AIHeroes = 1
else end

if ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_CustomGUIEnabled_0") == 1 then
		print("ME5_ConfigCheck: Custom GUI is DISABLED")
	ME5_CustomGUIEnabled = 0
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_CustomGUIEnabled_1") == 1 then
		print("ME5_ConfigCheck: Custom GUI is ENABLED")
	ME5_CustomGUIEnabled = 1
else end

if ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_Difficulty_0") == 1 then
		print("ME5_ConfigCheck: Difficulty is NORMAL")
	ME5_Difficulty = 1
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_Difficulty_1") == 1 then
		print("ME5_ConfigCheck: Difficulty is VETERAN")
	ME5_Difficulty = 2
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_Difficulty_2") == 1 then
		print("ME5_ConfigCheck: Difficulty is HARDCORE")
	ME5_Difficulty = 3
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_Difficulty_3") == 1 then
		print("ME5_ConfigCheck: Difficulty is INSANITY")
	ME5_Difficulty = 4
else end

if ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_HealthFunc_0") == 1 then
		print("ME5_ConfigCheck: Health Functionality is AUTO-REGEN")
	ME5_HealthFunc = 1
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_HealthFunc_1") == 1 then
		print("ME5_ConfigCheck: Health Functionality is PICKUPS")
	ME5_HealthFunc = 2
else end

if ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShieldFunc_0") == 1 then
		print("ME5_ConfigCheck: Shields Functionality is AUTO-REGEN")
	ME5_ShieldFunc = 1
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShieldFunc_1") == 1 then
		print("ME5_ConfigCheck: Shields Functionality is PICKUPS")
	ME5_ShieldFunc = 2
else end

if ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_HeroClassCOL_0") == 1 then
		print("ME5_ConfigCheck: COL Hero Class is RANDOM")
	ME5_HeroClassCOL = 0
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_HeroClassCOL_1") == 1 then
		print("ME5_ConfigCheck: COL Hero Class is HARBINGER")
	ME5_HeroClassCOL = 1
else end

if ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_HeroClassGTH_0") == 1 then
		print("ME5_ConfigCheck: GTH Hero Class is RANDOM")
	ME5_HeroClassGTH = 0
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_HeroClassGTH_1") == 1 then
		print("ME5_ConfigCheck: GTH Hero Class is GETH PRIME")
	ME5_HeroClassGTH = 1
else end

if ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_HeroClassSSV_0") == 1 then
		print("ME5_ConfigCheck: SSV Hero Class is RANDOM")
	ME5_HeroClassSSV = 0
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_HeroClassSSV_1") == 1 then
		print("ME5_ConfigCheck: SSV Hero Class is SHEPARD")
	ME5_HeroClassSSV = 1
else end

if ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShepardClass_0") == 1 then
		print("ME5_ConfigCheck: Shepard Class is RANDOM")
	ME5_ShepardClass = 0
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShepardClass_1") == 1 then
		print("ME5_ConfigCheck: Shepard Class is SOLDIER")
	ME5_ShepardClass = 1
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShepardClass_2") == 1 then
		print("ME5_ConfigCheck: Shepard Class is INFILTRATOR")
	ME5_ShepardClass = 2
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShepardClass_3") == 1 then
		print("ME5_ConfigCheck: Shepard Class is ENGINEER")
	ME5_ShepardClass = 3
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShepardClass_4") == 1 then
		print("ME5_ConfigCheck: Shepard Class is ADEPT")
	ME5_ShepardClass = 4
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShepardClass_5") == 1 then
		print("ME5_ConfigCheck: Shepard Class is SENTINEL")
	ME5_ShepardClass = 5
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShepardClass_6") == 1 then
		print("ME5_ConfigCheck: Shepard Class is VANGUARD")
	ME5_ShepardClass = 6
else end

if ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShepardGender_0") == 1 then
		print("ME5_ConfigCheck: Shepard Gender is RANDOM")
	ME5_ShepardGender = 0
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShepardGender_1") == 1 then
		print("ME5_ConfigCheck: Shepard Gender is MALE")
	ME5_ShepardGender = 1
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_ShepardGender_2") == 1 then
		print("ME5_ConfigCheck: Shepard Gender is FEMALE")
	ME5_ShepardGender = 2
else end

if ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_SideVar_0") == 1 then
		print("ME5_ConfigCheck: Side Variation is RANDOM")
	ME5_SideVar = 0
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_SideVar_1") == 1 then
		print("ME5_ConfigCheck: Side Variation is SSVxGTH")
	ME5_SideVar = 1
elseif ScriptCB_IsFileExist("..\\..\\addon\\ME5\\data\\_LVL_PC\\cfg\\cfg_SideVar_2") == 1 then
		print("ME5_ConfigCheck: Side Variation is SSVxCOL")
	ME5_SideVar = 2
else end
	print("ME5_RandomSides: Checking configuration parameters... Done!")


if ME5_AIHeroes == 1 then
	ScriptCB_DoFile("AIHeroSupport")
else end


	-- Declare global info variables
		xxs	= 1
		xs	= 2
		sm	= 3
		med	= 4
		lg	= 5
		
		SSVxGTH	= 1
		SSVxCOL	= 2
		
		shep_soldier	 = 1
		shep_infiltrator = 2
		shep_engineer	 = 3
		shep_adept		 = 4
		shep_sentinel	 = 5
		shep_vanguard	 = 6
		
		gethprime_me2	= 1
		gethprime_me3	= 2
		
		colgeneral	= 1
		
		snd_SSV_cpCapture_SSV	= "ssv_adm_com_report_captured_commandpost"
		snd_SSV_cpCapture_GTH	= "ssv_adm_com_report_gthCaptured_commandpost"
		snd_SSV_cpCapture_COL	= "ssv_adm_com_report_colCaptured_commandpost"
		snd_SSV_cpLost_SSV		= "ssv_adm_com_report_lost_commandpost"
		snd_SSV_cpLost_GTH		= "ssv_adm_com_report_gthLost_commandpost"
		snd_SSV_cpLost_COL		= "ssv_adm_com_report_colLost_commandpost"

		snd_GTH_cpCapture_SSV	= "gth_ann_com_report_ssvCaptured_commandpost"
		snd_GTH_cpCapture_GTH	= "gth_ann_com_report_captured_commandpost"
		snd_GTH_cpLost_SSV		= "gth_ann_com_report_ssvLost_commandpost"
		snd_GTH_cpLost_GTH		= "gth_ann_com_report_lost_commandpost"


function PreLoadStuff()
		print("ME5_RandomSides: PreLoadStuff()")
	if not ScriptCB_InMultiplayer() then
		if ME5_Difficulty == 1 then
			local damageMult = 0.6
				print("ME5_RandomSides: Initializing difficulty parameters for NORMAL...")
				--print("ME5_RandomSides: AI Damage Threshold is "..damageMult)
			SetAIDifficulty(0, 0)
			--[[SetAIDamageThreshold(0,						damageMult)
			SetAIDamageThreshold("com_inf_default",		damageMult)
			SetAIDamageThreshold("com_hero_default",	damageMult)
			SetAIDamageThreshold("com_hero_default",	damageMult)
			SetAIDamageThreshold("gth_walk_colussus",	damageMult)
			SetAIDamageThreshold("ssv_fly_a61_gunship",	damageMult)
			SetAIDamageThreshold("ssv_tread_mako",		damageMult)
			SetTeamAggressiveness(CIS,(0.73))
			SetTeamAggressiveness(REP,(0.73))]]
		elseif ME5_Difficulty == 2 then
			local damageMult = 0.8
				print("ME5_RandomSides: Initializing difficulty parameters for VETERAN...")
				--print("ME5_RandomSides: AI Damage Threshold is "..damageMult)
			SetAIDifficulty(-2, 2)
			--[[SetAIDamageThreshold(0,						damageMult)
			SetAIDamageThreshold("com_inf_default",		damageMult)
			SetAIDamageThreshold("com_hero_default",	damageMult)
			SetAIDamageThreshold("com_hero_default",	damageMult)
			SetAIDamageThreshold("gth_walk_colussus",	damageMult)
			SetAIDamageThreshold("ssv_fly_a61_gunship",	damageMult)
			SetAIDamageThreshold("ssv_tread_mako",		damageMult)
			SetTeamAggressiveness(CIS,(0.83))
			SetTeamAggressiveness(REP,(0.83))]]
		elseif ME5_Difficulty == 3 then
			local damageMult = 1.0
				print("ME5_RandomSides: Initializing difficulty parameters for HARDCORE...")
				--print("ME5_RandomSides: AI Damage Threshold is "..damageMult)
			SetAIDifficulty(-2, 4)
			--[[SetAIDamageThreshold(0,						damageMult)
			SetAIDamageThreshold("com_inf_default",		damageMult)
			SetAIDamageThreshold("com_hero_default",	damageMult)
			SetAIDamageThreshold("com_hero_default",	damageMult)
			SetAIDamageThreshold("gth_walk_colussus",	damageMult)
			SetAIDamageThreshold("ssv_fly_a61_gunship",	damageMult)
			SetAIDamageThreshold("ssv_tread_mako",		damageMult)
			SetTeamAggressiveness(CIS,(0.93))
			SetTeamAggressiveness(REP,(0.93))]]
		elseif ME5_Difficulty == 4 then
			local damageMult = 1.25
				print("ME5_RandomSides: Initializing difficulty parameters for INSANITY...")
				--print("ME5_RandomSides: AI Damage Threshold is "..damageMult)
			SetAIDifficulty(-3, 6)
			--[[SetAIDamageThreshold(0,						damageMult)
			SetAIDamageThreshold("com_inf_default",		damageMult)
			SetAIDamageThreshold("com_hero_default",	damageMult)
			SetAIDamageThreshold("com_hero_default",	damageMult)
			SetAIDamageThreshold("gth_walk_colussus",	damageMult)
			SetAIDamageThreshold("ssv_fly_a61_gunship",	damageMult)
			SetAIDamageThreshold("ssv_tread_mako",		damageMult)
			SetTeamAggressiveness(CIS,(1.0))
			SetTeamAggressiveness(REP,(1.0))]]
		end
	else
		local damageMult = 0.9
			print("ME5_RandomSides: Initializing difficulty parameters for MULTIPLAYER...")
			--print("ME5_RandomSides: AI Damage Threshold is "..damageMult)
		SetAIDifficulty(-2, 2)
			--[[SetAIDamageThreshold(0,						damageMult)
			SetAIDamageThreshold("com_inf_default",		damageMult)
			SetAIDamageThreshold("com_hero_default",	damageMult)
			SetAIDamageThreshold("com_hero_default",	damageMult)
			SetAIDamageThreshold("gth_walk_colussus",	damageMult)
			SetAIDamageThreshold("ssv_fly_a61_gunship",	damageMult)
			SetAIDamageThreshold("ssv_tread_mako",		damageMult)
		SetTeamAggressiveness(CIS,(0.95))
		SetTeamAggressiveness(REP,(0.95))]]
	end
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ingamessv.lvl")
			ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ingamegth.lvl")
		elseif RandomSide == 2 then
			ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ingamessv.lvl")
			ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ingamecol.lvl")
		end
	else
		if onlineSideVar == 1 then
			ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ingamessv.lvl")
			ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ingamegth.lvl")
		elseif onlineSideVar == 2 then
			ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ingamessv.lvl")
			ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ingamecol.lvl")
		else end
	end
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\common.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\common.lvl")
	if ME5_CustomGUIEnabled == 1 then
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\me5shell.lvl")
	else end
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\core.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\corebase.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ar\\ar.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ingame.lvl")
	ReadDataFile("ingame.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\weapons.lvl")

	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl")
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_Streaming.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_h_Streaming.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_vo_Streaming.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_Common_NonStreaming.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_WPN_NonStreaming.lvl")
	
	fShieldPickup()
end

function fShieldPickup()
		print("ME5_RandomSides: fShieldPickup()")
	--[[if not ScriptCB_InMultiplayer() then
		testcheckhumanspawn = OnCharacterSpawn(
			function(player)
				if IsCharacterHuman(player) then
					Iamhuman = GetEntityPtr(GetCharacterUnit(player))
				end
			end
		)
		
		shieldRegenTimerCount = 0
		
		ShieldRegenDelayStop = OnObjectDamage(
			function(object, damager)
				local playerHealth = GetObjectHealth(object)
				if Iamhuman == GetEntityPtr(object) and playerHealth > 0 then
					shieldRegenTimerCount = shieldRegenTimerCount + 1
						print("ShieldDelay: Character damaged")
						print(GetEntityPtr(object))
					
					StopTimer("shieldRegenTimer")
					DestroyTimer("shieldRegenTimer")

					SetProperty(object, "AddShield", "0.0")
					
					CreateTimer("shieldRegenTimer" .. shieldRegenTimerCount)
						SetTimerValue("shieldRegenTimer" .. shieldRegenTimerCount, 5)
						ShowTimer("shieldRegenTimer" .. shieldRegenTimerCount)
						StartTimer("shieldRegenTimer" .. shieldRegenTimerCount)
						OnTimerElapse(
							function(timer)
									print("ShieldDelay: Regenerating shields")
								SetProperty(object, "AddShield", "50.0")
								ShowMessageText("level.common.events.debug.shieldregen")   -- debug text

								local shieldPfx = CreateEffect("com_sfx_pickup_shield")
								local charPos = GetEntityMatrix(object)
								AttachEffectToMatrix(shieldPfx, charPos)

								DestroyTimer("shieldRegenTimer" .. shieldRegenTimerCount)
							end,
						"shieldRegenTimer" .. shieldRegenTimerCount
					)
				end
			end
		)
	else]]
	if not ScriptCB_InMultiplayer() then
		if ME5_ShieldFunc == 1 then
				print("ME5_RandomSides: Configuring Shield Functionality for AUTO-REGEN...")
			--[[SetClassProperty("ssv_inf_default", "AddShield", 9.0)
			SetClassProperty("ssv_inf_default_sentinel", "AddShield", 18.0)
			
			SetClassProperty("gth_inf_default", "AddShield", 11.0)
			SetClassProperty("gth_inf_default_trooper", "AddShield", 15.0)
			
			SetClassProperty("col_inf_default", "AddShield", 12.0)]]
			
			SetClassProperty("com_inf_default", "AddShield", 14.0)
			
		elseif ME5_ShieldFunc == 2 then
				print("ME5_RandomSides: Configuring Shield Functionality for PICKUPS...")
				------------------------------------------------
				-- DON'T FORGET TO UPDATE MULTIPLAYER VERSION --
				------------------------------------------------
			SetClassProperty("com_inf_default", "NextDropItem", "-")
			SetClassProperty("com_inf_default", "DropItemClass", "com_item_powerup_shields")
			SetClassProperty("com_inf_default", "DropItemProbability", 0.3)
			
			shieldDropCnt = 0	-- debug variable used to count # times item is dropped
		
			OnFlagPickUp(
				function(flag, character)
						print("ShieldRegen: Unit picked up flag")
					local charPtr = GetCharacterUnit(character)
					
					if GetEntityClass(flag) == FindEntityClass("com_item_powerup_shields") then
							ShowMessageText("level.common.events.debug.shieldregen")	-- debug text
						--SetProperty(charPtr, "AddShield", 175)
						
						local curShields = GetObjectShield(charPtr)
							print("ShieldRegen: Unit's current shields: "..curShields)
						local newShields = curShields + 150
						SetProperty(charPtr, "CurShield", newShields)
							print("ShieldRegen: Unit's new shields: "..newShields)
						
						KillObject(flag)
						
						shieldDropCnt = shieldDropCnt + 1
							print("ShieldRegen: Shield drop count: "..shieldDropCnt)
						
						local shieldPfx = CreateEffect("com_sfx_pickup_shield")
						local charPos = GetEntityMatrix(charPtr)
						AttachEffectToMatrix(shieldPfx, charPos)
						
						--[[local shieldTimer = CreateTimer("shieldTimer")
						SetTimerValue(shieldTimer, 1)
						StartTimer(shieldTimer)
						local shield_timer = OnTimerElapse(
							function(timer)
									print("ShieldRegen: Shield regen complete")
									ShowMessageText("level.common.events.debug.noregen")	-- debug text
								SetProperty(charPtr, "AddShield", 0)
								
								DestroyTimer(timer)
							end,
						shieldTimer
						)]]
					end
				end
			)
		else end
		
		if ME5_HealthFunc == 1 then
				print("ME5_RandomSides: Configuring Health Functionality for AUTO-REGEN...")
			SetClassProperty("com_inf_default", "AddHealth", 4.0)
		elseif ME5_HealthFunc == 2 then
				print("ME5_RandomSides: Configuring Health Functionality for PICKUPS...")
			--[[SetClassProperty("com_inf_default", "NextDropItem", "-")
			SetClassProperty("com_inf_default", "DropItemClass", "com_item_powerup_health")
			SetClassProperty("com_inf_default", "DropItemProbability", 0.2)]]
		else end
	else
		
	end
	--end
	
	
	
	--[[humantable = {}
	humantotal = 0

	testcheckhumanspawn = OnCharacterSpawn(
		function(player)
			if IsCharacterHuman(player) then
				humantable[humantotal] = GetEntityPtr(GetCharacterUnit(player))
					print(humantable[humantotal])
				humantotal = humantotal + 1
			end
		end
	)

	ShieldRegenDelayStop = OnObjectDamage(
		function(object, damager)
			iterateplayer = 0
			while iterateplayer <= humantotal do
				if humantable[iterateplayer] == GetEntityPtr(object) then            
					shieldRegenTimerCount = 5
						print("ShieldDelay: Character damaged")
						print(GetEntityPtr(object))
						print(iterateplayer)
						print(humantotal)

					SetProperty(object, "AddShield", "0.0")

					CreateTimer("shieldRegenTimer" .. shieldRegenTimerCount)
						SetTimerValue("shieldRegenTimer" .. shieldRegenTimerCount, 5)
						ShowTimer("shieldRegenTimer" .. shieldRegenTimerCount)
						StartTimer("shieldRegenTimer" .. shieldRegenTimerCount)
						OnTimerElapse(
							function(timer)
									print("ShieldDelay: Regenerating shields")
								SetProperty(object, "AddShield", "50.0")
								ShowMessageText("level.common.events.debug.shieldregen")   -- debug text

								local shieldPfx = CreateEffect("com_sfx_pickup_shield")
								local charPos = GetEntityMatrix(object)
								AttachEffectToMatrix(shieldPfx, charPos)

								DestroyTimer("shieldRegenTimer" .. shieldRegenTimerCount)
							end,
						"shieldRegenTimer" .. shieldRegenTimerCount
					)
				end
			iterateplayer = iterateplayer + 1
			end
		end
	)]]
	
	
	
	--[[shieldRegenTimerCount = 0
		
		ShieldRegenDelay = OnObjectDamage(
			function(object, damager)
				if IsCharacterHuman(object) then
						print("ShieldDelay: Character damaged")
					shieldRegenTimerCount = shieldRegenTimerCount + 1
					
					SetProperty(object, "AddShield", "0.0")
					
					CreateTimer("shieldRegenTimer" .. shieldRegenTimerCount)
						SetTimerValue("shieldRegenTimer" .. shieldRegenTimerCount, 5)
						ShowTimer("shieldRegenTimer" .. shieldRegenTimerCount)
						StartTimer("shieldRegenTimer" .. shieldRegenTimerCount)
						OnTimerElapse(
							function(timer)
									print("ShieldDelay: Regenerating shields")
								SetProperty(object, "AddShield", "50.0")
								--ShowMessageText("level.common.events.debug.shieldregen")	-- debug text
								
								local shieldPfx = CreateEffect("com_sfx_pickup_shield")
								local charPos = GetEntityMatrix(object)
								AttachEffectToMatrix(shieldPfx, charPos)
								
								DestroyTimer("shieldRegenTimer" .. shieldRegenTimerCount)
							end,
						"shieldRegenTimer" .. shieldRegenTimerCount
					)
				else end
			end
		)]]
end

function fHeadshotKill()
		print("ME5_RandomSides: fHeadshotKill()")
	--[[HeadshotHeadExplode = OnObjectHeadshot(
		function(object, killer)
				print("fHeadshotKill: Headshot")
			ShowMessageText("level.common.events.debug.headshot")	-- debug text
			
			if not IsObjectAlive(object) then
					print("fHeadshotKill: Unit is dead")
				ShowMessageText("level.common.events.debug.headshotkill")	-- debug text
				
				--local headPfx = CreateEffect("com_sfx_headexplode")
				--local charPos = GetEntityMatrix(object)
				--AttachEffectToMatrix(headPfx, charPos)
			end
		end
	)]]
	
	--[[HeadshotHeadExplode = OnCharacterDeath(
		function(player, killer)
				print("fHeadshotKill: Unit is dead")
					ShowMessageText("level.common.events.debug.headshotkill")	-- debug text
			if OnObjectHeadshot(player) then
					print("fHeadshotKill: Headshot")
						ShowMessageText("level.common.events.debug.headshot")	-- debug text
				local headshot2fx = CreateEffect("com_sfx_headexplode")
				local charPos = GetEntityMatrix(player)
				AttachEffectToObject(headshot2fx, charPos)
			end
		end
	)]] 

	
	--[[OnCharacterDeathTeam(
		function (OnObjectHeadshot)
				print("fHeadshotKill: Headshot")
			local headPfx = CreateEffect("com_sfx_headexplode")
			local charPos = GetEntityMatrix(object)
			AttachEffectToMatrix(headPfx, charPos)
		end,
	2)
	
	OnCharacterDeath(
		function (ObjectHeadshot)
				print("fHeadshotKill: Headshot")
			ShowMessageText("level.common.events.debug.headshot")	-- debug text
			
			local headshot2fx = CreateEffect("com_sfx_headexplode") 
			local charPos = GetEntityMatrix(object) 
			AttachEffectToObject(headshot2fx, character)
		end
	)]]

end

function PostLoadStuff()
		print("ME5_RandomSides: PostLoadStuff()")
	
end

function SFL_Turrets()
		print("ME5_RandomSides: SFL_Turrets()")
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_TUR_b_NonStreaming.lvl")
end

function SFL_SSV_vt()
		print("ME5_RandomSides: SFL_SSV_vt()")
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSV_v_t_NonStreaming.lvl")
end

function SFL_SSV_vf()
		print("ME5_RandomSides: SFL_SSV_vf()")
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSV_v_f_NonStreaming.lvl")
end

function Init_SideSetup()
	if not ScriptCB_InMultiplayer() then
		if ME5_SideVar == 0 then
			if RandomSide == 1 then
				Setup_SSVxGTH()
			elseif RandomSide == 2 then
				Setup_SSVxCOL()
			end
		elseif ME5_SideVar == 1 then
			Setup_SSVxGTH()
		elseif ME5_SideVar == 2 then
			Setup_SSVxCOL()
		else end
	else
		if onlineSideVar == 1 then
			Setup_SSVxGTH()
		elseif onlineSideVar == 2 then
			Setup_SSVxCOL()
		else end
	end
end

function Setup_SSVxGTH()
	LoadSSV()
	LoadGTH()
	
	if mapSize == 1 then
			print("ME5_RandomSides: Map size is xxs")
		Setup_SSVxGTH_xxs()
	elseif mapSize == 2 then
			print("ME5_RandomSides: Map size is xs")
		Setup_SSVxGTH_xs()
	elseif mapSize == 3 then
			print("ME5_RandomSides: Map size is sm")
		Setup_SSVxGTH_sm()
	elseif mapSize == 4 then
			print("ME5_RandomSides: Map size is med")
		Setup_SSVxGTH_med()
	elseif mapSize == 5 then
			print("ME5_RandomSides: Map size is lg")
		Setup_SSVxGTH_lg()
	else
		print("ME5_RandomSides: ALL YOUR MAP SIZE ARE BELONG TO US!!")
	end
	
	if ScriptCB_InMultiplayer() then
		if onlineHeroSSV == 1 then
				print("ME5_RandomSides: Online SSV hero is Shepard Soldier")
			SetHeroClass(REP, "ssv_hero_shepard_soldier")
		elseif onlineHeroSSV == 2 then
				print("ME5_RandomSides: Online SSV hero is Shepard Infiltrator")
			SetHeroClass(REP, "ssv_hero_shepard_infiltrator")
		elseif onlineHeroSSV == 3 then
				print("ME5_RandomSides: Online SSV hero is Shepard Engineer")
			SetHeroClass(REP, "ssv_hero_shepard_engineer")
		elseif onlineHeroSSV == 4 then
				print("ME5_RandomSides: Online SSV hero is Shepard Adept")
			SetHeroClass(REP, "ssv_hero_shepard_adept")
		elseif onlineHeroSSV == 5 then
				print("ME5_RandomSides: Online SSV hero is Shepard Sentinel")
			SetHeroClass(REP, "ssv_hero_shepard_sentinel")
		elseif onlineHeroSSV == 6 then
				print("ME5_RandomSides: Online SSV hero is Shepard Vanguard")
			SetHeroClass(REP, "ssv_hero_shepard_vanguard")
		else end
		
		if onlineHeroGTH == 1 then
				print("ME5_RandomSides: Online GTH hero is ME2 Geth Prime")
			SetHeroClass(CIS, "gth_hero_prime")
		else end
	else end
	
	if REP == 1 then
		team1ticketstring = "level.common.events.con.ticketboost.ssv"
	elseif REP == 2 then
		team2ticketstring = "level.common.events.con.ticketboost.ssv"
	else end
	
	if CIS == 1 then
		team1ticketstring = "level.common.events.con.ticketboost.gth"
	elseif CIS == 2 then
		team2ticketstring = "level.common.events.con.ticketboost.gth"
	else end
end

function Setup_SSVxCOL()
	LoadSSV()
	LoadCOL()
	if mapSize == 1 then
			print("ME5_RandomSides: Map size is xxs")
		Setup_SSVxCOL_xxs()
	elseif mapSize == 2 then
			print("ME5_RandomSides: Map size is xs")
		Setup_SSVxCOL_xs()
	elseif mapSize == 3 then
			print("ME5_RandomSides: Map size is sm")
		Setup_SSVxCOL_sm()
	elseif mapSize == 4 then
			print("ME5_RandomSides: Map size is med")
		Setup_SSVxCOL_med()
	elseif mapSize == 5 then
			print("ME5_RandomSides: Map size is lg")
		Setup_SSVxCOL_lg()
	else
		print("ME5_RandomSides: ALL YOUR MAP SIZE ARE BELONG TO US!!")
	end
	
	if ScriptCB_InMultiplayer() then
		if onlineHeroSSV == shep_soldier then
				print("ME5_RandomSides: Online SSV hero is Shepard Soldier")
			SetHeroClass(REP, "ssv_hero_shepard_soldier")
		elseif onlineHeroSSV == shep_infiltrator then
				print("ME5_RandomSides: Online SSV hero is Shepard Infiltrator")
			SetHeroClass(REP, "ssv_hero_shepard_infiltrator")
		elseif onlineHeroSSV == shep_engineer then
				print("ME5_RandomSides: Online SSV hero is Shepard Engineer")
			SetHeroClass(REP, "ssv_hero_shepard_engineer")
		elseif onlineHeroSSV == shep_adept then
				print("ME5_RandomSides: Online SSV hero is Shepard Adept")
			SetHeroClass(REP, "ssv_hero_shepard_adept")
		elseif onlineHeroSSV == shep_sentinel then
				print("ME5_RandomSides: Online SSV hero is Shepard Sentinel")
			SetHeroClass(REP, "ssv_hero_shepard_sentinel")
		elseif onlineHeroSSV == shep_vanguard then
				print("ME5_RandomSides: Online SSV hero is Shepard Vanguard")
			SetHeroClass(REP, "ssv_hero_shepard_vanguard")
		else end
		
		if onlineHeroCOL == colgeneral then
				print("ME5_RandomSides: Online COL hero is Harby")
			SetHeroClass(CIS, "col_hero_harbinger")
		else end
	else end
	
	if REP == 1 then
		team1ticketstring = "level.common.events.con.ticketboost.ssv"
	elseif REP == 2 then
		team2ticketstring = "level.common.events.con.ticketboost.ssv"
	else end
	
	if CIS == 1 then
		team1ticketstring = "level.common.events.con.ticketboost.col"
	elseif CIS == 2 then
		team2ticketstring = "level.common.events.con.ticketboost.col"
	else end
end

function LoadSSV()
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSV_NonStreaming.lvl")
	--[[ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\ssv.lvl",
				"ssv_fly_a61_gunship",
				"ssv_inf_soldier",
				"ssv_inf_infiltrator",
				"ssv_inf_adept",
				"ssv_inf_engineer",
				"ssv_inf_sentinel",
				"ssv_inf_vanguard",
				"ssv_inf_drone_combat",
				"ssv_hero_jack",
				"ssv_hero_legion",
				"ssv_hero_samara",
				"ssv_hero_shepard",
				"ssv_hero_shepard_soldier",
				"ssv_hero_shepard_infiltrator",
				"ssv_hero_shepard_engineer",
				"ssv_hero_shepard_adept",
				"ssv_hero_shepard_sentinel",
				"ssv_hero_shepard_vanguard",
				"ssv_tread_mako",
				"weap_tech_combatdrone_ssv_rigged")]]
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\GFX_SSV_Char.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\GFX_SSV_Misc.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\CON_SSV.lvl")
	
	if EnvironmentType == 1 then
			print("ME5_RandomSides: Loading SSV environment type Desert")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\ssv_desert.lvl")
	elseif EnvironmentType == 2 then
			print("ME5_RandomSides: Loading SSV environment type Jungle")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\ssv_jungle.lvl")
	elseif EnvironmentType == 3 then
			print("ME5_RandomSides: Loading SSV environment type Snow")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\ssv_snow.lvl")
	elseif EnvironmentType == 4 then
			print("ME5_RandomSides: Loading SSV environment type Urban")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\ssv_urban.lvl")
	else
			print("ME5_RandomSides: No environment type specified... Defaulting to SSV Urban instead")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\ssv_urban.lvl")
	end
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\coressv.lvl")
end

function LoadSSVspa()
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\ssv.lvl",
				"ssv_inf_pilot",
				"ssv_fly_recon",
				"ssv_fly_fighter",
				"ssv_fly_bomber")
				
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\coressv.lvl")
end

function LoadGTH()
	--SetAIDifficulty(-3, 3)
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_GTH_NonStreaming.lvl")
	--[[ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\gth.lvl",
				"gth_hero_prime",
				"gth_inf_trooper",
				"gth_inf_rocketeer",
				"gth_inf_sniper",
				"gth_inf_machinist",
				"gth_inf_hunter",
				"gth_inf_shock",
				"gth_inf_shock_online",
				"gth_inf_destroyer",
				"gth_inf_juggernaut")]]
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\GFX_GTH_Char.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\GFX_GTH_Misc.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\CON_GTH.lvl")
				
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\coregth.lvl")
end

function LoadCOL()
	--SetAIDifficulty(-3, 3)
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_COL_NonStreaming.lvl")
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_INDOC_NonStreaming.lvl")
	--[[ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\col.lvl",
				"col_inf_drone",
				"col_inf_assassin",
				"col_inf_guardian",
				"col_inf_guardian_online",
				"col_inf_scion",
				"col_hero_harbinger",
				"col_fly_oculus")]]
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\GFX_COL_Char.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\GFX_COL_Misc.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\CON_COL.lvl")
	
	--[[ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\indoc.lvl",
				"indoc_inf_husk",
				"indoc_inf_abomination")]]
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\GFX_INDOC_Char.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\GFX_INDOC_Misc.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\CON_INDOC.lvl")
				
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\corecol.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ingamecol.lvl")
end

function LoadECL()
	--SetAIDifficulty(-3, 3)
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\gth.lvl",
				"gth_inf_rocketeer")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\eclipse.lvl",
				"eclipse_inf_commando",
    			"eclipse_inf_engineer",
    			"eclipse_inf_heavy",
				"eclipse_inf_LOKI",
    			"eclipse_inf_operative",
				"eclipse_inf_trooper",
				"eclipse_inf_vanguard",
				"eclipse_inf_YMIR")
				
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\coreecl.lvl")
end

function LoadRPR()
	--SetAIDifficulty(-3, 3)
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_INDOC_NonStreaming.lvl")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\indoc.lvl",
				"indoc_inf_husk",
				"indoc_inf_abomination",
				"indoc_inf_cannibal",
				"indoc_inf_marauder")
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\col.lvl",
				"col_inf_scion")
				
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\corerpr.lvl")
end

function LoadCER()
	--SetAIDifficulty(-3, 3)
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\cer.lvl",
				"cer_inf_trooper",
				"cer_inf_nemesis",
				"cer_inf_engineer",
				"cer_inf_centurion",
				"cer_inf_phantom")
				
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\corecer.lvl")
end

--[[function ObjectiveSurvival_125tick()
		print("ME5_RandomSides: ObjectiveSurvival_125tick()")
		local ObjectiveSurvivalDebugStr = "ME5_RandomSides: Changing ticket counts to 100 for Survival..."
	if ObjectiveSurvivalHasRan == 1 then
		SetReinforcementCount(1, 125)
		SetReinforcementCount(2, 125)
			print(ObjectiveSurvivalDebugStr)
	else 
		print("ME5_RandomSides: BY THE GODDESS, WHAT ON THESSIA IS HAPPENING")
	end
end]]

function Setup_SSVxGTH_xxs()
		print("ME5_RandomSides: Setup_SSVxGTH_xxs()")
	--Setup_SSVxGTH_xxs = 1
	
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSVGTH_NonStreaming.lvl")
	if not ScriptCB_InMultiplayer() then
		SetupTeams{
		rep = {
			team = REP,
			units = 7,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",2, 3},
			sniper  = { "ssv_inf_infiltrator",1, 3},
			adept = { "ssv_inf_adept",1, 3},
			engineer   = { "ssv_inf_engineer",1, 3},
			sentinel = { "ssv_inf_sentinel",1, 3},
			vanguard = { "ssv_inf_vanguard",1, 3},	
		},
		
		cis = {
			team = CIS,
			units = 7,
			reinforcements = 150,
			soldier  = { "gth_inf_trooper",1, 6},
			assault  = { "gth_inf_rocketeer",1, 4},
			sniper = { "gth_inf_sniper",1, 4},
			engineer = { "gth_inf_machinist",1, 4},
			hunter   = { "gth_inf_hunter",1, 3},
			shock  = { "gth_inf_shock",1, 3},
			destroyer = { "gth_inf_destroyer",1, 2},
			juggernaut = { "gth_inf_juggernaut",1, 2},
		}
		}
	else
		SetupTeams{
		rep = {
			team = REP,
			units = 7,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",2, 3},
			sniper  = { "ssv_inf_infiltrator",1, 3},
			adept = { "ssv_inf_adept",1, 3},
			engineer   = { "ssv_inf_engineer",1, 3},
			sentinel = { "ssv_inf_sentinel",1, 3},
			vanguard = { "ssv_inf_vanguard",1, 3},	
		},
		
		cis = {
			team = CIS,
			units = 7,
			reinforcements = 150,
			soldier  = { "gth_inf_trooper",1, 6},
			assault  = { "gth_inf_rocketeer",1, 4},
			sniper = { "gth_inf_sniper",1, 4},
			engineer = { "gth_inf_machinist",1, 4},
			hunter   = { "gth_inf_hunter",1, 3},
			shock  = { "gth_inf_shock_online",1, 3},
			destroyer = { "gth_inf_destroyer",1, 2},
			juggernaut = { "gth_inf_juggernaut",1, 2},
		}
		}
	end
	
	--[[if not ScriptCB_InMultiplayer() then
		SetHeroClass(CIS, "gth_hero_prime")
	else end]]
end

function Setup_SSVxCOL_xxs()
		print("ME5_RandomSides: Setup_SSVxCOL_xxs()")
	--Setup_SSVxCOL_xxs = 1
	
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSVCOL_NonStreaming.lvl")
	if not ScriptCB_InMultiplayer() then
		SetupTeams{
			rep = {
			team = REP,
			units = 6,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",1, 8},
			sniper  = { "ssv_inf_infiltrator",1, 8},
			adept = { "ssv_inf_adept",1, 8},
			engineer   = { "ssv_inf_engineer",1, 8},
			sentinel = { "ssv_inf_sentinel",1, 8},
			vanguard = { "ssv_inf_vanguard",1, 8},	
		},
		
		cis = {
			team = CIS,
			units = 5,
			reinforcements = 150,
			-- husk  = { "indoc_inf_husk",2, 8},
			soldier  = { "col_inf_drone",2, 25},
			assault  = { "col_inf_assassin",1, 7},
			-- special = { "indoc_inf_abomination",2, 8},
			support  = { "col_inf_guardian",1, 14},
			scion  = { "col_inf_scion",1, 2},
		}
		}
	else
		SetupTeams{
			rep = {
			team = REP,
			units = 6,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",1, 8},
			sniper  = { "ssv_inf_infiltrator",1, 8},
			adept = { "ssv_inf_adept",1, 8},
			engineer   = { "ssv_inf_engineer",1, 8},
			sentinel = { "ssv_inf_sentinel",1, 8},
			vanguard = { "ssv_inf_vanguard",1, 8},	
		},
		
		cis = {
			team = CIS,
			units = 5,
			reinforcements = 150,
			-- husk  = { "indoc_inf_husk",2, 8},
			soldier  = { "col_inf_drone",2, 25},
			assault  = { "col_inf_assassin",1, 7},
			-- special = { "indoc_inf_abomination",2, 8},
			support  = { "col_inf_guardian_online",1, 14},
			scion  = { "col_inf_scion",1, 2},
		}
		}
	end
	
	SetTeamName(ColHuskTeam, CIS)
	SetTeamIcon(ColHuskTeam, "cis_icon")
	SetUnitCount(ColHuskTeam, 2)
	AddUnitClass(ColHuskTeam, "indoc_inf_husk", 1)
	AddUnitClass(ColHuskTeam, "indoc_inf_abomination", 1)
	
	SetTeamAsEnemy(REP,ColHuskTeam)
	SetTeamAsEnemy(ColHuskTeam,REP)
	SetTeamAsFriend(CIS,ColHuskTeam)
	SetTeamAsFriend(ColHuskTeam,CIS)
	
	--SetHeroClass(CIS, "col_hero_harbinger")
end

function Setup_SSVxGTH_xs()
		print("ME5_RandomSides: Setup_SSVxGTH_xs()")
	--Setup_SSVxGTH_xs = 1
	
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSVGTH_NonStreaming.lvl")
	if not ScriptCB_InMultiplayer() then
		SetupTeams{
		rep = {
			team = REP,
			units = 13,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",3, 8},
			sniper  = { "ssv_inf_infiltrator",3, 8},
			adept = { "ssv_inf_adept",3, 8},
			engineer   = { "ssv_inf_engineer",3, 8},
			sentinel = { "ssv_inf_sentinel",3, 8},
			vanguard = { "ssv_inf_vanguard",3, 8},	
		},
		
		cis = {
			team = CIS,
			units = 13,
			reinforcements = 150,
			soldier  = { "gth_inf_trooper",3, 20},
			assault  = { "gth_inf_rocketeer",2, 8},
			sniper = { "gth_inf_sniper",2, 8},
			engineer = { "gth_inf_machinist",1, 8},
			hunter   = { "gth_inf_hunter",2, 6},
			shock  = { "gth_inf_shock",1, 6},
			destroyer = { "gth_inf_destroyer",1, 4},
			juggernaut = { "gth_inf_juggernaut",1, 4},
		}
		}
	else
		SetupTeams{
		rep = {
			team = REP,
			units = 13,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",3, 8},
			sniper  = { "ssv_inf_infiltrator",3, 8},
			adept = { "ssv_inf_adept",3, 8},
			engineer   = { "ssv_inf_engineer",3, 8},
			sentinel = { "ssv_inf_sentinel",3, 8},
			vanguard = { "ssv_inf_vanguard",3, 8},	
		},
		
		cis = {
			team = CIS,
			units = 13,
			reinforcements = 150,
			soldier  = { "gth_inf_trooper",3, 20},
			assault  = { "gth_inf_rocketeer",2, 8},
			sniper = { "gth_inf_sniper",2, 8},
			engineer = { "gth_inf_machinist",1, 8},
			hunter   = { "gth_inf_hunter",2, 6},
			shock  = { "gth_inf_shock_online",1, 6},
			destroyer = { "gth_inf_destroyer",1, 4},
			juggernaut = { "gth_inf_juggernaut",1, 4},
		}
		}
	end
	
	--[[if not ScriptCB_InMultiplayer() then
		SetHeroClass(CIS, "gth_hero_prime")
	else end]]
end

function Setup_SSVxCOL_xs()
		print("ME5_RandomSides: Setup_SSVxCOL_xs()")
	--Setup_SSVxCOL_xs = 1
	
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSVCOL_NonStreaming.lvl")
	if not ScriptCB_InMultiplayer() then
		SetupTeams{
			rep = {
			team = REP,
			units = 7,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",2, 8},
			sniper  = { "ssv_inf_infiltrator",1, 8},
			adept = { "ssv_inf_adept",1, 8},
			engineer   = { "ssv_inf_engineer",1, 8},
			sentinel = { "ssv_inf_sentinel",1, 8},
			vanguard = { "ssv_inf_vanguard",1, 8},	
		},
		
		cis = {
			team = CIS,
			units = 7,
			reinforcements = 150,
			-- husk  = { "indoc_inf_husk",2, 8},
			soldier  = { "col_inf_drone",3, 25},
			assault  = { "col_inf_assassin",2, 7},
			-- special = { "indoc_inf_abomination",2, 8},
			support  = { "col_inf_guardian",1, 14},
			scion  = { "col_inf_scion",1, 2},
		}
		}
	else
		SetupTeams{
			rep = {
			team = REP,
			units = 7,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",3, 8},
			sniper  = { "ssv_inf_infiltrator",3, 8},
			adept = { "ssv_inf_adept",3, 8},
			engineer   = { "ssv_inf_engineer",3, 8},
			sentinel = { "ssv_inf_sentinel",3, 8},
			vanguard = { "ssv_inf_vanguard",3, 8},	
		},
		
		cis = {
			team = CIS,
			units = 7,
			reinforcements = 150,
			-- husk  = { "indoc_inf_husk",2, 8},
			soldier  = { "col_inf_drone",3, 25},
			assault  = { "col_inf_assassin",2, 7},
			-- special = { "indoc_inf_abomination",2, 8},
			support  = { "col_inf_guardian_online",1, 14},
			scion  = { "col_inf_scion",1, 2},
		}
		}
	end
	
	SetTeamName(ColHuskTeam, CIS)
	SetTeamIcon(ColHuskTeam, "cis_icon")
	SetUnitCount(ColHuskTeam, 3)
	AddUnitClass(ColHuskTeam, "indoc_inf_husk", 2)
	AddUnitClass(ColHuskTeam, "indoc_inf_abomination", 1)
	
	SetTeamAsEnemy(REP,ColHuskTeam)
	SetTeamAsEnemy(ColHuskTeam,REP)
	SetTeamAsFriend(CIS,ColHuskTeam)
	SetTeamAsFriend(ColHuskTeam,CIS)
	
	--SetHeroClass(CIS, "col_hero_harbinger")
end

function Setup_SSVxECL_xs()
		print("Load/setup SSV versus ECL - level mode:xs")
	
	--SetTeamAggressiveness(CIS,(0.96))
	--SetTeamAggressiveness(REP,(0.99))
	
	SetupTeams{
	rep = {
		team = REP,
		units = 10,
		reinforcements = 150,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 10,
		reinforcements = 150,
		LOKI = { "eclipse_inf_LOKI",4, 12},
		soldier  = { "eclipse_inf_trooper",6, 10},
		engineer  = { "eclipse_inf_engineer",5, 7},
		adept = { "eclipse_inf_vanguard",4, 6},
		heavy   = { "eclipse_inf_heavy",3, 6},
		operative = { "eclipse_inf_operative",2, 5},
		commando = { "eclipse_inf_commando",1, 3},
		YMIR = { "eclipse_inf_YMIR",1, 2},
	}
	}
	
	-- SetHeroClass(CIS, heroECL)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_GTHxECL_xs()
		print("Load/setup GTH versus ECL - level mode:xs")
	
	--SetTeamAggressiveness(REP,(0.96))
	--SetTeamAggressiveness(CIS,(0.99))
	
	SetupTeams{
	cis = {
		team = CIS,
		units = 13,
		reinforcements = 150,
		soldier  = { "gth_inf_trooper",9, 20},
		assault  = { "gth_inf_rocketeer",3, 8},
		sniper = { "gth_inf_sniper",3, 8},
		engineer = { "gth_inf_machinist",3, 8},
		hunter   = { "gth_inf_hunter",5, 6},
		shock  = { "gth_inf_shock",4, 6},
		destroyer = { "gth_inf_destroyer",2, 4},
		juggernaut = { "gth_inf_juggernaut",1, 4},
	},
	
	imp = {
		team = REP,
		units = 10,
		reinforcements = 150,
		LOKI = { "eclipse_inf_LOKI",4, 12},
		soldier  = { "eclipse_inf_trooper",6, 10},
		engineer  = { "eclipse_inf_engineer",5, 7},
		adept = { "eclipse_inf_vanguard",4, 6},
		heavy   = { "eclipse_inf_heavy",3, 6},
		operative = { "eclipse_inf_operative",2, 5},
		commando = { "eclipse_inf_commando",1, 3},
		YMIR = { "eclipse_inf_YMIR",1, 2},
	}
	}
	
	-- SetHeroClass(CIS, heroECL)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxRPR_xs()
		print("Load/setup SSV versus RPR - level mode:xs")
	
	--SetTeamAggressiveness(REP,(0.99))
	--SetTeamAggressiveness(CIS,(0.96))
	
	SetupTeams{
	rep = {
		team = REP,
		units = 10,
		reinforcements = 150,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 10,
		reinforcements = 150,
		husk  = { "indoc_inf_husk",7, 12},
		soldier  = { "indoc_inf_cannibal",9, 16},
		assault  = { "indoc_inf_marauder",6, 10},
		support = { "indoc_inf_abomination",4, 8},
		scion = { "col_inf_scion",1, 4},
	}
	}
	
	-- SetHeroClass(CIS, heroGTH)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxCER_xs()
		print("Load/setup SSV versus CER - level mode:xs")
	
	--SetTeamAggressiveness(REP,(0.99))
	--SetTeamAggressiveness(CIS,(0.99))
	
	SetupTeams{
	rep = {
		team = REP,
		units = 10,
		reinforcements = 150,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 10,
		reinforcements = 150,
		soldier  = { "cer_inf_trooper",8, 12},
		sniper  = { "cer_inf_nemesis",6, 9},
		engineer = { "cer_inf_engineer",6, 9},
		officer   = { "cer_inf_centurion",5, 8},
		special   = { "cer_inf_phantom",3, 6},
	}
	}
	
	-- SetHeroClass(CIS, heroGTH)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxGTH_sm()
		print("ME5_RandomSides: Setup_SSVxGTH_sm()")
	--Setup_SSVxGTH_sm = 1
	
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSVGTH_NonStreaming.lvl")
	if not ScriptCB_InMultiplayer() then
		SetupTeams{
		rep = {
			team = REP,
			units = 15,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",3, 8},
			sniper  = { "ssv_inf_infiltrator",2, 8},
			adept = { "ssv_inf_adept",3, 8},
			engineer   = { "ssv_inf_engineer",3, 8},
			sentinel = { "ssv_inf_sentinel",2, 8},
			vanguard = { "ssv_inf_vanguard",2, 8},	
		},
		
		cis = {
			team = CIS,
			units = 17,
			reinforcements = 150,
			soldier  = { "gth_inf_trooper",5, 20},
			assault  = { "gth_inf_rocketeer",2, 8},
			sniper = { "gth_inf_sniper",2, 8},
			engineer = { "gth_inf_machinist",1, 9},
			hunter   = { "gth_inf_hunter",3, 7},
			shock  = { "gth_inf_shock",2, 7},
			destroyer = { "gth_inf_destroyer",1, 4},
			juggernaut = { "gth_inf_juggernaut",1, 4},
		}
		}
	else
		SetupTeams{
		rep = {
			team = REP,
			units = 15,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",3, 8},
			sniper  = { "ssv_inf_infiltrator",2, 8},
			adept = { "ssv_inf_adept",3, 8},
			engineer   = { "ssv_inf_engineer",3, 8},
			sentinel = { "ssv_inf_sentinel",2, 8},
			vanguard = { "ssv_inf_vanguard",2, 8},	
		},
		
		cis = {
			team = CIS,
			units = 17,
			reinforcements = 150,
			soldier  = { "gth_inf_trooper",5, 20},
			assault  = { "gth_inf_rocketeer",2, 8},
			sniper = { "gth_inf_sniper",2, 8},
			engineer = { "gth_inf_machinist",1, 9},
			hunter   = { "gth_inf_hunter",3, 7},
			shock  = { "gth_inf_shock_online",2, 7},
			destroyer = { "gth_inf_destroyer",1, 4},
			juggernaut = { "gth_inf_juggernaut",1, 4},
		}
		}
	end
	
	--[[if not ScriptCB_InMultiplayer() then
		SetHeroClass(CIS, "gth_hero_prime")
	else end]]
end

function Setup_SSVxCOL_sm()
		print("ME5_RandomSides: Setup_SSVxCOL_sm()")
	--Setup_SSVxCOL_sm = 1
	
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSVCOL_NonStreaming.lvl")
	if not ScriptCB_InMultiplayer() then
		SetupTeams{
			rep = {
			team = REP,
			units = 15,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",3, 8},
			sniper  = { "ssv_inf_infiltrator",2, 8},
			adept = { "ssv_inf_adept",2, 8},
			engineer   = { "ssv_inf_engineer",3, 8},
			sentinel = { "ssv_inf_sentinel",3, 8},
			vanguard = { "ssv_inf_vanguard",2, 8},	
		},
		
		cis = {
			team = CIS,
			units = 12,
			reinforcements = 150,
			-- husk  = { "indoc_inf_husk",3, 8},
			soldier  = { "col_inf_drone",5, 25},
			assault  = { "col_inf_assassin",4, 7},
			-- special = { "indoc_inf_abomination",3, 8},
			support  = { "col_inf_guardian",2, 14},
			scion  = { "col_inf_scion",1, 2},
		}
		}
	else
		SetupTeams{
			rep = {
			team = REP,
			units = 15,
			reinforcements = 150,
			soldier  = { "ssv_inf_soldier",3, 8},
			sniper  = { "ssv_inf_infiltrator",2, 8},
			adept = { "ssv_inf_adept",2, 8},
			engineer   = { "ssv_inf_engineer",3, 8},
			sentinel = { "ssv_inf_sentinel",3, 8},
			vanguard = { "ssv_inf_vanguard",2, 8},	
		},
		
		cis = {
			team = CIS,
			units = 12,
			reinforcements = 150,
			-- husk  = { "indoc_inf_husk",3, 8},
			soldier  = { "col_inf_drone",5, 25},
			assault  = { "col_inf_assassin",4, 7},
			-- special = { "indoc_inf_abomination",3, 8},
			support  = { "col_inf_guardian_online",2, 14},
			scion  = { "col_inf_scion",1, 2},
		}
		}
	end
	
	SetTeamName(ColHuskTeam, CIS)
	SetTeamIcon(ColHuskTeam, "cis_icon")
	SetUnitCount(ColHuskTeam, 3)
	AddUnitClass(ColHuskTeam, "indoc_inf_husk", 2)
	AddUnitClass(ColHuskTeam, "indoc_inf_abomination", 1)
	
	SetTeamAsEnemy(REP,ColHuskTeam)
	SetTeamAsEnemy(ColHuskTeam,REP)
	SetTeamAsFriend(CIS,ColHuskTeam)
	SetTeamAsFriend(ColHuskTeam,CIS)
	
	--SetHeroClass(CIS, "col_hero_harbinger")
end

function Setup_SSVxECL_sm()
		print("Load/setup SSV versus ECL - level mode:sm")
	
	--SetTeamAggressiveness(CIS,(0.96))
	--SetTeamAggressiveness(REP,(0.99))
	
	SetupTeams{
	rep = {
		team = REP,
		units = 16,
		reinforcements = 150,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 16,
		reinforcements = 150,
		LOKI = { "eclipse_inf_LOKI",4, 12},
		soldier  = { "eclipse_inf_trooper",6, 10},
		engineer  = { "eclipse_inf_engineer",5, 7},
		adept = { "eclipse_inf_vanguard",4, 6},
		heavy   = { "eclipse_inf_heavy",3, 6},
		operative = { "eclipse_inf_operative",2, 5},
		commando = { "eclipse_inf_commando",1, 3},
		YMIR = { "eclipse_inf_YMIR",1, 2},
	}
	}
	
	-- SetHeroClass(CIS, heroECL)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_GTHxECL_sm()
		print("Load/setup GTH versus ECL - level mode:sm")
	
	--SetTeamAggressiveness(REP,(0.96))
	--SetTeamAggressiveness(CIS,(0.99))
	
	SetupTeams{
	cis = {
		team = CIS,
		units = 19,
		reinforcements = 150,
		soldier  = { "gth_inf_trooper",9, 20},
		assault  = { "gth_inf_rocketeer",3, 8},
		sniper = { "gth_inf_sniper",3, 8},
		engineer = { "gth_inf_machinist",3, 9},
		hunter   = { "gth_inf_hunter",5, 7},
		shock  = { "gth_inf_shock",4, 7},
		destroyer = { "gth_inf_destroyer",2, 4},
		juggernaut = { "gth_inf_juggernaut",1, 4},
	},
	
	imp = {
		team = REP,
		units = 16,
		reinforcements = 150,
		LOKI = { "eclipse_inf_LOKI",4, 12},
		soldier  = { "eclipse_inf_trooper",6, 10},
		engineer  = { "eclipse_inf_engineer",5, 7},
		adept = { "eclipse_inf_vanguard",4, 6},
		heavy   = { "eclipse_inf_heavy",3, 6},
		operative = { "eclipse_inf_operative",2, 5},
		commando = { "eclipse_inf_commando",1, 3},
		YMIR = { "eclipse_inf_YMIR",1, 2},
	}
	}
	
	-- SetHeroClass(CIS, heroECL)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxRPR_sm()
		print("Load/setup SSV versus RPR - level mode:sm")
	
	--SetTeamAggressiveness(REP,(0.99))
	--SetTeamAggressiveness(CIS,(0.96))
	
	SetupTeams{
	rep = {
		team = REP,
		units = 16,
		reinforcements = 150,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 16,
		reinforcements = 150,
		husk  = { "indoc_inf_husk",7, 12},
		soldier  = { "indoc_inf_cannibal",9, 16},
		assault  = { "indoc_inf_marauder",6, 10},
		support = { "indoc_inf_abomination",4, 8},
		scion = { "col_inf_scion",1, 4},
	}
	}
	
	-- SetHeroClass(CIS, heroGTH)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxCER_sm()
		print("Load/setup SSV versus CER - level mode:sm")
	
	--SetTeamAggressiveness(REP,(0.99))
	--SetTeamAggressiveness(CIS,(0.99))
	
	SetupTeams{
	rep = {
		team = REP,
		units = 16,
		reinforcements = 150,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 16,
		reinforcements = 150,
		soldier  = { "cer_inf_trooper",8, 12},
		sniper  = { "cer_inf_nemesis",6, 9},
		engineer = { "cer_inf_engineer",6, 9},
		officer   = { "cer_inf_centurion",5, 8},
		special   = { "cer_inf_phantom",3, 6},
	}
	}
	
	-- SetHeroClass(CIS, heroGTH)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxGTH_med()
		print("ME5_RandomSides: Setup_SSVxGTH_med()")
	--Setup_SSVxGTH_med = 1
	ssvEngCnt = 8
	
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSVGTH_NonStreaming.lvl")
	if not ScriptCB_InMultiplayer() then
		SetupTeams{
		rep = {
			team = REP,
			units = 22,
			reinforcements = 175,
			soldier  = { "ssv_inf_soldier",4, 8},
			sniper  = { "ssv_inf_infiltrator",3, 8},
			adept = { "ssv_inf_adept",4, 8},
			engineer   = { "ssv_inf_engineer",4, 8},
			sentinel = { "ssv_inf_sentinel",4, 8},
			vanguard = { "ssv_inf_vanguard",3, 8},	
		},
		
		cis = {
			team = CIS,
			units = 26,
			reinforcements = 175,
			soldier  = { "gth_inf_trooper",7, 20},
			assault  = { "gth_inf_rocketeer",3, 8},
			sniper = { "gth_inf_sniper",3, 8},
			engineer = { "gth_inf_machinist",3, 10},
			hunter   = { "gth_inf_hunter",4, 8},
			shock  = { "gth_inf_shock",3, 8},
			destroyer = { "gth_inf_destroyer",2, 4},
			juggernaut = { "gth_inf_juggernaut",1, 4},
		}
		}
	else
		SetupTeams{
		rep = {
			team = REP,
			units = 22,
			reinforcements = 175,
			soldier  = { "ssv_inf_soldier",4, 8},
			sniper  = { "ssv_inf_infiltrator",3, 8},
			adept = { "ssv_inf_adept",4, 8},
			engineer   = { "ssv_inf_engineer",4, 8},
			sentinel = { "ssv_inf_sentinel",4, 8},
			vanguard = { "ssv_inf_vanguard",3, 8},	
		},
		
		cis = {
			team = CIS,
			units = 26,
			reinforcements = 175,
			soldier  = { "gth_inf_trooper",7, 20},
			assault  = { "gth_inf_rocketeer",3, 8},
			sniper = { "gth_inf_sniper",3, 8},
			engineer = { "gth_inf_machinist",3, 10},
			hunter   = { "gth_inf_hunter",4, 8},
			shock  = { "gth_inf_shock_online",3, 8},
			destroyer = { "gth_inf_destroyer",2, 4},
			juggernaut = { "gth_inf_juggernaut",1, 4},
		}
		}
	end
	
	--[[if not ScriptCB_InMultiplayer() then
		SetHeroClass(CIS, "gth_hero_prime")
	else end]]
	--ObjectiveSurvival_125tick()
end

function Setup_SSVxCOL_med()
		print("ME5_RandomSides: Setup_SSVxCOL_med()")
	--Setup_SSVxCOL_med = 1
	ssvEngCnt = 8
	
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSVCOL_NonStreaming.lvl")
	if not ScriptCB_InMultiplayer() then
		SetupTeams{
		rep = {
			team = REP,
			units = 22,
			reinforcements = 175,
			soldier  = { "ssv_inf_soldier",4, 8},
			sniper  = { "ssv_inf_infiltrator",3, 8},
			adept = { "ssv_inf_adept",4, 8},
			engineer   = { "ssv_inf_engineer",4, 8},
			sentinel = { "ssv_inf_sentinel",4, 8},
			vanguard = { "ssv_inf_vanguard",3, 8},	
		},
		
		cis = {
			team = CIS,
			units = 19,
			reinforcements = 175,
			-- husk  = { "indoc_inf_husk",4, 8},
			soldier  = { "col_inf_drone",9, 25},
			assault  = { "col_inf_assassin",5, 7},
			-- special = { "indoc_inf_abomination",4, 8},
			support  = { "col_inf_guardian",4, 14},
			scion  = { "col_inf_scion",1, 2},
		}
		}
	else
		SetupTeams{
		rep = {
			team = REP,
			units = 22,
			reinforcements = 175,
			soldier  = { "ssv_inf_soldier",4, 8},
			sniper  = { "ssv_inf_infiltrator",3, 8},
			adept = { "ssv_inf_adept",4, 8},
			engineer   = { "ssv_inf_engineer",4, 8},
			sentinel = { "ssv_inf_sentinel",4, 8},
			vanguard = { "ssv_inf_vanguard",3, 8},	
		},
		
		cis = {
			team = CIS,
			units = 19,
			reinforcements = 175,
			-- husk  = { "indoc_inf_husk",4, 8},
			soldier  = { "col_inf_drone",9, 25},
			assault  = { "col_inf_assassin",5, 7},
			-- special = { "indoc_inf_abomination",4, 8},
			support  = { "col_inf_guardian_online",4, 14},
			scion  = { "col_inf_scion",1, 2},
		}
		}
	end
	
	SetTeamName(ColHuskTeam, CIS)
	SetTeamIcon(ColHuskTeam, "cis_icon")
	SetUnitCount(ColHuskTeam, 5)
	AddUnitClass(ColHuskTeam, "indoc_inf_husk", 3)
	AddUnitClass(ColHuskTeam, "indoc_inf_abomination", 2)
	
	SetTeamAsEnemy(REP,ColHuskTeam)
	SetTeamAsEnemy(ColHuskTeam,REP)
	SetTeamAsFriend(CIS,ColHuskTeam)
	SetTeamAsFriend(ColHuskTeam,CIS)
	
	--SetHeroClass(CIS, "col_hero_harbinger")
end

function Setup_SSVxECL_med()
		print("Load/setup SSV versus ECL - level mode:med")
	
	--SetTeamAggressiveness(CIS, 0.96)
	--SetTeamAggressiveness(REP, 0.99)
	
	SetupTeams{
	rep = {
		team = REP,
		units = 24,
		reinforcements = 175,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 24,
		reinforcements = 175,
		LOKI = { "eclipse_inf_LOKI",4, 12},
		soldier  = { "eclipse_inf_trooper",6, 10},
		engineer  = { "eclipse_inf_engineer",5, 7},
		adept = { "eclipse_inf_vanguard",4, 6},
		heavy   = { "eclipse_inf_heavy",3, 6},
		operative = { "eclipse_inf_operative",2, 5},
		commando = { "eclipse_inf_commando",1, 3},
		YMIR = { "eclipse_inf_YMIR",1, 3},
	}
	}
	
	-- SetHeroClass(CIS, heroECL)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_GTHxECL_med()
		print("Load/setup GTH versus ECL - level mode:med")
	
	--SetTeamAggressiveness(REP, 0.96)
	--SetTeamAggressiveness(CIS, 0.99)
	
	SetupTeams{
	cis = {
		team = CIS,
		units = 26,
		reinforcements = 175,
		soldier  = { "gth_inf_trooper",9, 20},
		assault  = { "gth_inf_rocketeer",3, 8},
		sniper = { "gth_inf_sniper",3, 8},
		engineer = { "gth_inf_machinist",3, 10},
		hunter   = { "gth_inf_hunter",5, 8},
		shock  = { "gth_inf_shock",4, 8},
		destroyer = { "gth_inf_destroyer",2, 4},
		juggernaut = { "gth_inf_juggernaut",1, 4},
	},
	
	imp = {
		team = REP,
		units = 24,
		reinforcements = 175,
		LOKI = { "eclipse_inf_LOKI",4, 12},
		soldier  = { "eclipse_inf_trooper",6, 10},
		engineer  = { "eclipse_inf_engineer",5, 7},
		adept = { "eclipse_inf_vanguard",4, 6},
		heavy   = { "eclipse_inf_heavy",3, 6},
		operative = { "eclipse_inf_operative",2, 5},
		commando = { "eclipse_inf_commando",1, 3},
		YMIR = { "eclipse_inf_YMIR",1, 3},
	}
	}
	
	-- SetHeroClass(CIS, heroECL)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxRPR_med()
		print("Load/setup SSV versus RPR - level mode:med")
	
	--SetTeamAggressiveness(REP, 0.99)
	--SetTeamAggressiveness(CIS, 0.96)
	
	SetupTeams{
	rep = {
		team = REP,
		units = 25,
		reinforcements = 175,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 26,
		reinforcements = 175,
		husk  = { "indoc_inf_husk",7, 12},
		soldier  = { "indoc_inf_cannibal",9, 16},
		assault  = { "indoc_inf_marauder",6, 10},
		support = { "indoc_inf_abomination",4, 8},
		scion = { "col_inf_scion",2, 4},
	}
	}
	
	-- SetHeroClass(CIS, heroGTH)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxCER_med()
		print("Load/setup SSV versus CER - level mode:med")
	
	--SetTeamAggressiveness(REP, 0.99)
	--SetTeamAggressiveness(CIS, 0.99)
	
	SetupTeams{
	rep = {
		team = REP,
		units = 25,
		reinforcements = 175,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 25,
		reinforcements = 175,
		soldier  = { "cer_inf_trooper",8, 12},
		sniper  = { "cer_inf_nemesis",6, 9},
		engineer = { "cer_inf_engineer",6, 9},
		officer   = { "cer_inf_centurion",5, 8},
		special   = { "cer_inf_phantom",4, 7},
	}
	}
	
	-- SetHeroClass(CIS, heroGTH)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxGTH_lg()
		print("ME5_RandomSides: Setup_SSVxGTH_lg()")
	--Setup_SSVxGTH_lg = 1
	ssvEngCnt = 8
	
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSVGTH_NonStreaming.lvl")
	if not ScriptCB_InMultiplayer() then
		SetupTeams{
		rep = {
			team = REP,
			units = 29,
			reinforcements = 200,
			soldier  = { "ssv_inf_soldier",5, 8},
			sniper  = { "ssv_inf_infiltrator",5, 8},
			adept = { "ssv_inf_adept",5, 8},
			engineer   = { "ssv_inf_engineer",5, 8},
			sentinel = { "ssv_inf_sentinel",5, 8},
			vanguard = { "ssv_inf_vanguard",4, 8},	
		},
		
		cis = {
			team = CIS,
			units = 30,
			reinforcements = 200,
			soldier  = { "gth_inf_trooper",9, 20},
			assault  = { "gth_inf_rocketeer",3, 8},
			sniper = { "gth_inf_sniper",3, 8},
			engineer = { "gth_inf_machinist",3, 12},
			hunter   = { "gth_inf_hunter",5, 10},
			shock  = { "gth_inf_shock",4, 10},
			destroyer = { "gth_inf_destroyer",2, 4},
			juggernaut = { "gth_inf_juggernaut",1, 4},
		}
		}
	else
		SetupTeams{
		rep = {
			team = REP,
			units = 29,
			reinforcements = 200,
			soldier  = { "ssv_inf_soldier",5, 8},
			sniper  = { "ssv_inf_infiltrator",5, 8},
			adept = { "ssv_inf_adept",5, 8},
			engineer   = { "ssv_inf_engineer",5, 8},
			sentinel = { "ssv_inf_sentinel",5, 8},
			vanguard = { "ssv_inf_vanguard",4, 8},	
		},
		
		cis = {
			team = CIS,
			units = 30,
			reinforcements = 200,
			soldier  = { "gth_inf_trooper",9, 20},
			assault  = { "gth_inf_rocketeer",3, 8},
			sniper = { "gth_inf_sniper",3, 8},
			engineer = { "gth_inf_machinist",3, 12},
			hunter   = { "gth_inf_hunter",5, 10},
			shock  = { "gth_inf_shock_online",4, 10},
			destroyer = { "gth_inf_destroyer",2, 4},
			juggernaut = { "gth_inf_juggernaut",1, 4},
		}
		}
	end
	
	--[[if not ScriptCB_InMultiplayer() then
		SetHeroClass(CIS, "gth_hero_prime")
	else end]]
end

function Setup_SSVxCOL_lg()
		print("ME5_RandomSides: Setup_SSVxCOL_lg()")
	--Setup_SSVxCOL_lg = 1
	ssvEngCnt = 8
	
	--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_SSVCOL_NonStreaming.lvl")
	if not ScriptCB_InMultiplayer() then
		SetupTeams{
		rep = {
			team = REP,
			units = 27,
			reinforcements = 200,
			soldier  = { "ssv_inf_soldier",5, 8},
			sniper  = { "ssv_inf_infiltrator",4, 8},
			adept = { "ssv_inf_adept",5, 8},
			engineer   = { "ssv_inf_engineer",5, 8},
			sentinel = { "ssv_inf_sentinel",4, 8},
			vanguard = { "ssv_inf_vanguard",4, 8},	
		},
		
		cis = {
			team = CIS,
			units = 23,
			reinforcements = 200,
			-- husk  = { "indoc_inf_husk",5, 8},
			soldier  = { "col_inf_drone",10, 25},
			assault  = { "col_inf_assassin",7, 10},
			-- special = { "indoc_inf_abomination",5, 8},
			support  = { "col_inf_guardian",4, 14},
			scion  = { "col_inf_scion",2, 4},
		}
		}
	else
		SetupTeams{
		rep = {
			team = REP,
			units = 27,
			reinforcements = 200,
			soldier  = { "ssv_inf_soldier",5, 8},
			sniper  = { "ssv_inf_infiltrator",4, 8},
			adept = { "ssv_inf_adept",5, 8},
			engineer   = { "ssv_inf_engineer",5, 8},
			sentinel = { "ssv_inf_sentinel",4, 8},
			vanguard = { "ssv_inf_vanguard",4, 8},	
		},
		
		cis = {
			team = CIS,
			units = 23,
			reinforcements = 200,
			-- husk  = { "indoc_inf_husk",5, 8},
			soldier  = { "col_inf_drone",10, 25},
			assault  = { "col_inf_assassin",7, 10},
			-- special = { "indoc_inf_abomination",5, 8},
			support  = { "col_inf_guardian_online",4, 14},
			scion  = { "col_inf_scion",2, 4},
		}
		}
	end
	
	SetTeamName(ColHuskTeam, CIS)
	SetTeamIcon(ColHuskTeam, "cis_icon")
	SetUnitCount(ColHuskTeam, 7)
	AddUnitClass(ColHuskTeam, "indoc_inf_husk", 4)
	AddUnitClass(ColHuskTeam, "indoc_inf_abomination", 3)
	
	SetTeamAsEnemy(REP,ColHuskTeam)
	SetTeamAsEnemy(ColHuskTeam,REP)
	SetTeamAsFriend(CIS,ColHuskTeam)
	SetTeamAsFriend(ColHuskTeam,CIS)
	
	--SetHeroClass(CIS, "col_hero_harbinger")
end

function Setup_SSVxECL_lg()
		print("Load/setup SSV versus ECL - level mode:lg")
	
	--SetTeamAggressiveness(CIS,(0.96))
	--SetTeamAggressiveness(REP,(0.99))
	
	SetupTeams{
	rep = {
		team = REP,
		units = 30,
		reinforcements = 200,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 27,
		reinforcements = 200,
		LOKI = { "eclipse_inf_LOKI",4, 12},
		soldier  = { "eclipse_inf_trooper",6, 10},
		engineer  = { "eclipse_inf_engineer",5, 7},
		adept = { "eclipse_inf_vanguard",4, 6},
		heavy   = { "eclipse_inf_heavy",3, 6},
		operative = { "eclipse_inf_operative",2, 5},
		commando = { "eclipse_inf_commando",1, 3},
		YMIR = { "eclipse_inf_YMIR",1, 3},
	}
	}
	
	-- SetHeroClass(CIS, heroECL)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_GTHxECL_lg()
		print("Load/setup GTH versus ECL - level mode:lg")
	
	--SetTeamAggressiveness(REP,(0.96))
	--SetTeamAggressiveness(CIS,(0.99))
	
	SetupTeams{
	cis = {
		team = CIS,
		units = 30,
		reinforcements = 200,
		soldier  = { "gth_inf_trooper",9, 20},
		assault  = { "gth_inf_rocketeer",3, 8},
		sniper = { "gth_inf_sniper",3, 8},
		engineer = { "gth_inf_machinist",3, 12},
		hunter   = { "gth_inf_hunter",5, 10},
		shock  = { "gth_inf_shock",4, 10},
		destroyer = { "gth_inf_destroyer",2, 4},
		juggernaut = { "gth_inf_juggernaut",1, 4},
	},
	
	imp = {
		team = REP,
		units = 27,
		reinforcements = 200,
		LOKI = { "eclipse_inf_LOKI",4, 12},
		soldier  = { "eclipse_inf_trooper",6, 10},
		engineer  = { "eclipse_inf_engineer",5, 7},
		adept = { "eclipse_inf_vanguard",4, 6},
		heavy   = { "eclipse_inf_heavy",3, 6},
		operative = { "eclipse_inf_operative",2, 5},
		commando = { "eclipse_inf_commando",1, 3},
		YMIR = { "eclipse_inf_YMIR",1, 3},
	}
	}
	
	-- SetHeroClass(CIS, heroECL)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxRPR_lg()
		print("Load/setup SSV versus RPR - level mode:lg")
	
	--SetTeamAggressiveness(REP,(0.99))
	--SetTeamAggressiveness(CIS,(0.96))
	
	SetupTeams{
	rep = {
		team = REP,
		units = 31,
		reinforcements = 200,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 32,
		reinforcements = 200,
		husk  = { "indoc_inf_husk",7, 12},
		soldier  = { "indoc_inf_cannibal",9, 16},
		assault  = { "indoc_inf_marauder",6, 10},
		support = { "indoc_inf_abomination",4, 8},
		scion = { "col_inf_scion",2, 4},
	}
	}
	
	-- SetHeroClass(CIS, heroGTH)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxCER_lg()
		print("Load/setup SSV versus CER - level mode:lg")
	
	--SetTeamAggressiveness(REP,(0.99))
	--SetTeamAggressiveness(CIS,(0.99))
	
	SetupTeams{
	rep = {
		team = REP,
		units = 32,
		reinforcements = 200,
		soldier  = { "ssv_inf_soldier",3, 8},
		sniper  = { "ssv_inf_infiltrator",3, 8},
		adept = { "ssv_inf_adept",3, 8},
		engineer   = { "ssv_inf_engineer",3, 8},
		sentinel = { "ssv_inf_sentinel",3, 8},
		vanguard = { "ssv_inf_vanguard",3, 8},	
	},
	
	imp = {
		team = CIS,
		units = 32,
		reinforcements = 200,
		soldier  = { "cer_inf_trooper",8, 12},
		sniper  = { "cer_inf_nemesis",6, 9},
		engineer = { "cer_inf_engineer",6, 9},
		officer   = { "cer_inf_centurion",5, 8},
		special   = { "cer_inf_phantom",5, 8},
	}
	}
	
	-- SetHeroClass(CIS, heroGTH)
	-- SetHeroClass(REP, heroSSV)
end

function Setup_SSVxSUN_spa()
	SetupTeams{
	rep = {
		team = REP,
		units = 32,
		reinforcements = -1,
		pilot    = { "ssv_inf_pilot",32},
		
	},
	cis = {
		team = CIS,
		units = 32,
		reinforcements = -1,
		pilot    = { "ssv_inf_pilot",32},
	}
	}
end

function DecideShepClass()
	if ME5_ShepardClass == 0 then
		BroShepClass = math.random(1,6)
			print("ME5_RandomSides: Deciding BroShep class...")
		if BroShepClass == 1 then
				print("ME5_RandomSides: Deciding BroShep class... SOLDIER")
			SSVHeroClass = "ssv_hero_shepard_soldier"
		elseif BroShepClass == 2 then
				print("ME5_RandomSides: Deciding BroShep class... INFILTRATOR")
			SSVHeroClass = "ssv_hero_shepard_infiltrator"
		elseif BroShepClass == 3 then
				print("ME5_RandomSides: Deciding BroShep class... ENGINEER")
			SSVHeroClass = "ssv_hero_shepard_engineer"
		elseif BroShepClass == 4 then
				print("ME5_RandomSides: Deciding BroShep class... ADEPT")
			SSVHeroClass = "ssv_hero_shepard_adept"
		elseif BroShepClass == 5 then
				print("ME5_RandomSides: Deciding BroShep class... SENTINEL")
			SSVHeroClass = "ssv_hero_shepard_sentinel"
		elseif BroShepClass == 6 then
				print("ME5_RandomSides: Deciding BroShep class... VANGUARD")
			SSVHeroClass = "ssv_hero_shepard_vanguard"
		end
	elseif ME5_ShepardClass == 1 then
			print("ME5_RandomSides: Deciding BroShep class... SOLDIER")
		SSVHeroClass = "ssv_hero_shepard_soldier"
	elseif ME5_ShepardClass == 2 then
			print("ME5_RandomSides: Deciding BroShep class... INFILTRATOR")
		SSVHeroClass = "ssv_hero_shepard_infiltrator"
	elseif ME5_ShepardClass == 3 then
			print("ME5_RandomSides: Deciding BroShep class... ENGINEER")
		SSVHeroClass = "ssv_hero_shepard_engineer"
	elseif ME5_ShepardClass == 4 then
			print("ME5_RandomSides: Deciding BroShep class... ADEPT")
		SSVHeroClass = "ssv_hero_shepard_adept"
	elseif ME5_ShepardClass == 5 then
			print("ME5_RandomSides: Deciding BroShep class... SENTINEL")
		SSVHeroClass = "ssv_hero_shepard_sentinel"
	elseif ME5_ShepardClass == 6 then
			print("ME5_RandomSides: Deciding BroShep class... VANGUARD")
		SSVHeroClass = "ssv_hero_shepard_vanguard"
	end
	
end

function DecideSSVHeroClass()
	--DecideSSVHeroClass = math.random(1,4)
		print("ME5_RandomSides: Deciding SSV hero class...")
	--if DecideSSVHeroClass == 1 then
			print("ME5_RandomSides: Deciding SSV hero class... SHEPARD")
		DecideShepClass()
	--[[elseif DecideSSVHeroClass == 2 then
			print("ME5_RandomSides: Deciding SSV hero class... SAMARA")
		SetHeroClass(REP, "ssv_hero_samara")
	elseif DecideSSVHeroClass == 3 then
			print("ME5_RandomSides: Deciding SSV hero class... JACK")
		SetHeroClass(REP, "ssv_hero_jack")
	elseif DecideSSVHeroClass == 4 then
			print("ME5_RandomSides: Deciding SSV hero class... LEGION")
		SetHeroClass(REP, "ssv_hero_legion")
	else
	end]]
end

function DecideGTHHeroClass()
		print("ME5_RandomSides: Deciding GTH hero class...")
	GTHHeroClass = "gth_hero_prime"
end

function DecideCOLHeroClass()
	--DecideSSVHeroClass = math.random(1,4)
		print("ME5_RandomSides: Deciding COL hero class...")
	COLHeroClass = "col_hero_harbinger"
end

function HuskTeam_COL()
	SupportTeamSSV = 3;
end

function SupportTeams_GTH()
	SupportTeamGTH1 = 4;
end

function HuskTeam_COLxGTH()
	HuskTeam_COL()
	SupportTeams_GTH()
end

function SupportTeamSetup_SSV()
	SetTeamName(3, "SupportSSV")
	SetTeamIcon(3, "rep_icon")
	SetUnitCount(3, 8)
	AddUnitClass(3, "weap_tech_combatdrone_ssv_rigged", 8)
	
	SetTeamAsFriend(REP,3)
	SetTeamAsFriend(3,REP)
	SetTeamAsEnemy(CIS,3)
	SetTeamAsEnemy(3,CIS)
end

function SupportTeamSetup_GTH()
	SetTeamName(4, "SupportGTH1")
	SetTeamIcon(4, "cis_icon")
	SetUnitCount(4, 1)
	AddUnitClass(4, "weap_tech_combatdrone_gth_rigged", 1)
	
	SetTeamAsFriend(CIS,4)
	SetTeamAsFriend(4,CIS)
	SetTeamAsEnemy(REP,4)
	SetTeamAsEnemy(4,REP)
end

function SupportTeamSetup_SSVxGTH()
	SupportTeamSetup_SSV()
	SupportTeamSetup_GTH()
end

function Drones_SSV()
	-- Setup the team that will spawn in ScriptInit(), include the SetTeamAsFriend() stuff
	-- Add this code into ScriptPostLoad() once for each team that can spawn stuff (changing a couple of variables each time)
	-- Add an AIGoal for the spawned team somewhere in ScriptPostLoad() so the spawned character will actually do something
	
	TroopSpawnerWeapon = "weap_tech_combatdrone_ssv"

	OnCharacterDispenseControllableTeam(
		function(character,controlled)
			if GetEntityClass(controlled) == GetEntityClassPtr(TroopSpawnerWeapon) then
				local SupportSSV = 3
				local teamSize = GetTeamSize(SupportSSV)
				--SupportGoal1a = AddAIGoal(SupportSSV, "Follow", 100, 0)
				--SupportGoal1b = AddAIGoal(SupportSSV, "Defend", 300, 0)
				SupportGoal1c = AddAIGoal(SupportSSV, "Deathmatch", 500)
				for i = 0, 0 do		-- for i = 0, teamSize-1 do
					local characterIndex = GetTeamMember(SupportSSV, i)
					local charUnit = GetCharacterUnit(characterIndex)
					if not charUnit then
						local destination = GetEntityMatrix(GetCharacterUnit(character))
						SpawnCharacter(characterIndex,destination)
					end
				end
			end
		end,
	REP
	)
end

function Drones_GTH()
	
end

function Drones_SSVxGTH()
	Drones_SSV()
	Drones_GTH()
end

function OpenMusicStreams()
	if MusicVariation == 1 then
			print("ME5_RandomSides: Loading Music Variation 01")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_01_Streaming.lvl")
		OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_01_Streaming.lvl", "ME5n_music_01")
		
		--local musicVar = OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_01_Streaming.lvl", "ME5n_music_01")
		--AudioStreamAppendSegments("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_h_Streaming.lvl", "ME5n_music_h", musicVar)
	elseif MusicVariation == 2 then
			print("ME5_RandomSides: Loading Music Variation 02")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_02_Streaming.lvl")
		OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_02_Streaming.lvl", "ME5n_music_02")
	elseif MusicVariation == 3 then
			print("ME5_RandomSides: Loading Music Variation 03")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_03_Streaming.lvl")
		OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_03_Streaming.lvl", "ME5n_music_03")
	elseif MusicVariation == 4 then
			print("ME5_RandomSides: Loading Music Variation 04")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_04_Streaming.lvl")
		OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_04_Streaming.lvl", "ME5n_music_04")
	elseif MusicVariation == 5 then
			print("ME5_RandomSides: Loading Music Variation 05")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_05_Streaming.lvl")
		OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_05_Streaming.lvl", "ME5n_music_05")
	elseif MusicVariation == 6 then
			print("ME5_RandomSides: Loading Music Variation 06")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_06_Streaming.lvl")
		OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_06_Streaming.lvl", "ME5n_music_06")
	elseif MusicVariation == 7 then
			print("ME5_RandomSides: Loading Music Variation 07")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_07_Streaming.lvl")
		OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_07_Streaming.lvl", "ME5n_music_07")
	elseif MusicVariation == 8 then
			print("ME5_RandomSides: Loading Music Variation 08")
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_08_Streaming.lvl")
		OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_08_Streaming.lvl", "ME5n_music_08")
	else
			print("ME5_RandomSides: Error! No Music Variation is decided!")
		--ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_Streaming.lvl")
		--OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_Streaming.lvl", "ME5n_music")
	end
		print("ME5_RandomSides: Loading hero music")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_MUS_h_Streaming.lvl", "ME5n_music_h")
end

function Music01()
	MusicVariation = 1
	
	OpenMusicStreams()
	
	SetAmbientMusic(REP, 1.0, "ssv_amb_01_start",  0,1)
	SetAmbientMusic(REP, 0.9, "ssv_amb_01_mid",    1,1)
	SetAmbientMusic(REP, 0.3, "ssv_amb_01_end",    2,1)
	SetAmbientMusic(CIS, 1.0, "ssv_amb_01_start",  0,1)
	SetAmbientMusic(CIS, 0.9, "ssv_amb_01_mid",    1,1)
	SetAmbientMusic(CIS, 0.3, "ssv_amb_01_end",    2,1)
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music01_CTF()
	MusicVariation = 1
	
	OpenMusicStreams()
	
	SetAmbientMusic(REP, 1.0, "ssv_amb_01_ctf",  0,1)
	SetAmbientMusic(REP, 0.6, "ssv_amb_01_ctf",    1,1)
	SetAmbientMusic(REP, 0.3, "ssv_amb_01_ctf",    2,1)
	SetAmbientMusic(CIS, 1.0, "ssv_amb_01_ctf",  0,1)
	SetAmbientMusic(CIS, 0.6, "ssv_amb_01_ctf",    1,1)
	SetAmbientMusic(CIS, 0.3, "ssv_amb_01_ctf",    2,1)
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music02()
	MusicVariation = 2
	
	OpenMusicStreams()
	DecideMus02StartVar = math.random(1,3)
	DecideMus02MidVar = math.random(1,3)
	DecideMus02EndVar = math.random(1,2)
	
	if DecideMus02StartVar == 1 then
			print("ME5_RandomSides: Deciding Music02Start variation... Choosing THE ATTACK")
		Mus02Start = "ssv_amb_02a_start"
	elseif DecideMus02StartVar == 2 then
			print("ME5_RandomSides: Deciding Music02Start variation... Choosing THE NORMANDY ATTACKED")
		Mus02Start = "ssv_amb_02b_start"
	elseif DecideMus02StartVar == 3 then
			print("ME5_RandomSides: Deciding Music02Start variation... Choosing CRASH LANDING")
		Mus02Start = "ssv_amb_02c_start"
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music02Start variation is loaded! D: :runaway:")
		Mus02Start = "ssv_amb_02_start"
	end
	
	if DecideMus02MidVar == 1 then
			print("ME5_RandomSides: Deciding Music02Mid variation... Choosing THE ATTACK")
		Mus02Mid = "ssv_amb_02a_mid"
	elseif DecideMus02MidVar == 2 then
			print("ME5_RandomSides: Deciding Music02Mid variation... Choosing THE NORMANDY ATTACKED")
		Mus02Mid = "ssv_amb_02b_mid"
	elseif DecideMus02MidVar == 3 then
			print("ME5_RandomSides: Deciding Music02Mid variation... Choosing CRASH LANDING")
		Mus02Mid = "ssv_amb_02c_mid"
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music02Mid variation is loaded! D: :runaway:")
		Mus02Mid = "ssv_amb_02_mid"
	end
	
	if DecideMus02EndVar == 1 then
			print("ME5_RandomSides: Deciding Music02End variation... Choosing THE ATTACK")
		Mus02End = "ssv_amb_02a_end"
	elseif DecideMus02EndVar == 2 then
			print("ME5_RandomSides: Deciding Music02End variation... Choosing JUMP DRIVE")
		Mus02End = "ssv_amb_02b_end"
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music02End variation is loaded! D: :runaway:")
		Mus02End = "ssv_amb_02_end"
	end
	
	SetAmbientMusic(REP, 1.0, Mus02Start,  0,1)
	SetAmbientMusic(REP, 0.9, Mus02Mid,    1,1)
	SetAmbientMusic(REP, 0.3, Mus02End,    2,1)
	SetAmbientMusic(CIS, 1.0, Mus02Start,  0,1)
	SetAmbientMusic(CIS, 0.9, Mus02Mid,    1,1)
	SetAmbientMusic(CIS, 0.3, Mus02End,    2,1)
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music02_CTF()
	MusicVariation = 2
	
	OpenMusicStreams()
	--[[DecideMus02StartVar = math.random(1,3)
	DecideMus02MidVar = math.random(1,3)
	DecideMus02EndVar = math.random(1,2)
	
	if DecideMus02StartVar == 1 then
			print("ME5_RandomSides: Deciding Music02Start variation... Choosing THE ATTACK")
		Mus02Start = "ssv_amb_02a_start"
	elseif DecideMus02StartVar == 2 then
			print("ME5_RandomSides: Deciding Music02Start variation... Choosing THE NORMANDY ATTACKED")
		Mus02Start = "ssv_amb_02b_start"
	elseif DecideMus02StartVar == 3 then
			print("ME5_RandomSides: Deciding Music02Start variation... Choosing CRASH LANDING")
		Mus02Start = "ssv_amb_02c_start"
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music02Start variation is loaded! D: :runaway:")
		Mus02Start = "ssv_amb_02_start"
	end
	
	if DecideMus02MidVar == 1 then
			print("ME5_RandomSides: Deciding Music02Mid variation... Choosing THE ATTACK")
		Mus02Mid = "ssv_amb_02a_mid"
	elseif DecideMus02MidVar == 2 then
			print("ME5_RandomSides: Deciding Music02Mid variation... Choosing THE NORMANDY ATTACKED")
		Mus02Mid = "ssv_amb_02b_mid"
	elseif DecideMus02MidVar == 3 then
			print("ME5_RandomSides: Deciding Music02Mid variation... Choosing CRASH LANDING")
		Mus02Mid = "ssv_amb_02c_mid"
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music02Mid variation is loaded! D: :runaway:")
		Mus02Mid = "ssv_amb_02_mid"
	end
	
	if DecideMus02EndVar == 1 then
			print("ME5_RandomSides: Deciding Music02End variation... Choosing THE ATTACK")
		Mus02End = "ssv_amb_02a_end"
	elseif DecideMus02EndVar == 2 then
			print("ME5_RandomSides: Deciding Music02End variation... Choosing JUMP DRIVE")
		Mus02End = "ssv_amb_02b_end"
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music02End variation is loaded! D: :runaway:")
		Mus02End = "ssv_amb_02_end"
	end]]
	
	SetAmbientMusic(REP, 1.0, "ssv_amb_02_ctf",  0,1)
	SetAmbientMusic(REP, 0.6, "ssv_amb_02_ctf",    1,1)
	SetAmbientMusic(REP, 0.3, "ssv_amb_02_ctf",    2,1)
	SetAmbientMusic(CIS, 1.0, "ssv_amb_02_ctf",  0,1)
	SetAmbientMusic(CIS, 0.6, "ssv_amb_02_ctf",    1,1)
	SetAmbientMusic(CIS, 0.3, "ssv_amb_02_ctf",    2,1)
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music03()
	MusicVariation = 3
	
	OpenMusicStreams()
	
	SetAmbientMusic(REP, 1.0, "ssv_amb_03_start",  0,1)
	SetAmbientMusic(REP, 0.9, "ssv_amb_03_mid",    1,1)
	SetAmbientMusic(REP, 0.3, "ssv_amb_03_end",    2,1)
	SetAmbientMusic(CIS, 1.0, "ssv_amb_03_start",  0,1)
	SetAmbientMusic(CIS, 0.9, "ssv_amb_03_mid",    1,1)
	SetAmbientMusic(CIS, 0.3, "ssv_amb_03_end",    2,1)
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music03_CTF()
	MusicVariation = 3
	
	OpenMusicStreams()
	
	SetAmbientMusic(REP, 1.0, "ssv_amb_03_ctf",  0,1)
	SetAmbientMusic(REP, 0.6, "ssv_amb_03_ctf",    1,1)
	SetAmbientMusic(REP, 0.3, "ssv_amb_03_ctf",    2,1)
	SetAmbientMusic(CIS, 1.0, "ssv_amb_03_ctf",  0,1)
	SetAmbientMusic(CIS, 0.6, "ssv_amb_03_ctf",    1,1)
	SetAmbientMusic(CIS, 0.3, "ssv_amb_03_ctf",    2,1)
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music04()
	MusicVariation = 4
	
	OpenMusicStreams()
	DecideMus04Var = math.random(1,6)
	
	if DecideMus04Var == 1 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing SAMARA")
		SetAmbientMusic(REP, 1.0, "ssv_amb_04a_start",  0,1)
		SetAmbientMusic(REP, 0.8, "ssv_amb_04a_mid",    1,1)
		SetAmbientMusic(REP, 0.35, "ssv_amb_04a_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_04a_start",  0,1)
		SetAmbientMusic(CIS, 0.8, "ssv_amb_04a_mid",    1,1)
		SetAmbientMusic(CIS, 0.35, "ssv_amb_04a_end",    2,1)
	elseif DecideMus04Var == 2 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing GRUNT")
		SetAmbientMusic(REP, 1.0, "ssv_amb_04b_start",  0,1)
		SetAmbientMusic(REP, 0.8, "ssv_amb_04b_mid",    1,1)
		SetAmbientMusic(REP, 0.35, "ssv_amb_04b_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_04b_start",  0,1)
		SetAmbientMusic(CIS, 0.8, "ssv_amb_04b_mid",    1,1)
		SetAmbientMusic(CIS, 0.35, "ssv_amb_04b_end",    2,1)
	elseif DecideMus04Var == 3 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing TALI")
		SetAmbientMusic(REP, 1.0, "ssv_amb_04c_start",  0,1)
		SetAmbientMusic(REP, 0.8, "ssv_amb_04c_mid",    1,1)
		SetAmbientMusic(REP, 0.35, "ssv_amb_04c_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_04c_start",  0,1)
		SetAmbientMusic(CIS, 0.8, "ssv_amb_04c_mid",    1,1)
		SetAmbientMusic(CIS, 0.35, "ssv_amb_04c_end",    2,1)
	elseif DecideMus04Var == 4 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing INFILTRATION")
		SetAmbientMusic(REP, 1.0, "ssv_amb_04d_start",  0,1)
		SetAmbientMusic(REP, 0.8, "ssv_amb_04d_mid",    1,1)
		SetAmbientMusic(REP, 0.35, "ssv_amb_04d_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_04d_start",  0,1)
		SetAmbientMusic(CIS, 0.8, "ssv_amb_04d_mid",    1,1)
		SetAmbientMusic(CIS, 0.35, "ssv_amb_04d_end",    2,1)
	elseif DecideMus04Var == 5 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing THANE")
		SetAmbientMusic(REP, 1.0, "ssv_amb_04e_start",  0,1)
		SetAmbientMusic(REP, 0.85, "ssv_amb_04e_mid",    1,1)
		SetAmbientMusic(REP, 0.4, "ssv_amb_04e_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_04e_start",  0,1)
		SetAmbientMusic(CIS, 0.8, "ssv_amb_04e_mid",    1,1)
		SetAmbientMusic(CIS, 0.35, "ssv_amb_04e_end",    2,1)
	elseif DecideMus04Var == 6 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing JACK")
		SetAmbientMusic(REP, 1.0, "ssv_amb_04f_start",  0,1)
		SetAmbientMusic(REP, 0.85, "ssv_amb_04f_mid",    1,1)
		SetAmbientMusic(REP, 0.4, "ssv_amb_04f_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_04f_start",  0,1)
		SetAmbientMusic(CIS, 0.85, "ssv_amb_04f_mid",    1,1)
		SetAmbientMusic(CIS, 0.4, "ssv_amb_04f_end",    2,1)
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music04 variation is loaded! D: :runaway:")
		SetAmbientMusic(REP, 1.0, "ssv_amb_04_start",  0,1)
		SetAmbientMusic(REP, 0.8, "ssv_amb_04_mid",    1,1)
		SetAmbientMusic(REP, 0.35, "ssv_amb_04_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_04_start",  0,1)
		SetAmbientMusic(CIS, 0.8, "ssv_amb_04_mid",    1,1)
		SetAmbientMusic(CIS, 0.35, "ssv_amb_04_end",    2,1)
	end
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music04_CTF()
	MusicVariation = 4
	
	OpenMusicStreams()
	--[[DecideMus04Var = math.random(1,6)
	
	if DecideMus04Var == 1 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing SAMARA")
		music04_start = "ssv_amb_04a_start"
		music04_mid = "ssv_amb_04a_mid"
		music04_end = "ssv_amb_04a_end"
	elseif DecideMus04Var == 2 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing GRUNT")
		music04_start = "ssv_amb_04b_start"
		music04_mid = "ssv_amb_04b_mid"
		music04_end = "ssv_amb_04b_end"
	elseif DecideMus04Var == 3 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing TALI")
		music04_start = "ssv_amb_04a_start"
		music04_mid = "ssv_amb_04c_mid"
		music04_end = "ssv_amb_04c_end"
	elseif DecideMus04Var == 4 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing INFILTRATION")
		music04_start = "ssv_amb_04d_start"
		music04_mid = "ssv_amb_04d_mid"
		music04_end = "ssv_amb_04d_end"
	elseif DecideMus04Var == 5 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing THANE")
		music04_start = "ssv_amb_04e_start"
		music04_mid = "ssv_amb_04e_mid"
		music04_end = "ssv_amb_04e_end"
	elseif DecideMus04Var == 6 then
			print("ME5_RandomSides: Deciding Music04 variation... Choosing JACK")
		music04_start = "ssv_amb_04f_start"
		music04_mid = "ssv_amb_04f_mid"
		music04_end = "ssv_amb_04f_end"
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music04 variation is loaded! D: :runaway:")
		music04_start = "ssv_amb_04_start"
		music04_mid = "ssv_amb_04_mid"
		music04_end = "ssv_amb_04_end"
	end]]
	
	SetAmbientMusic(REP, 1.0, "ssv_amb_04_ctf",  0,1)
	SetAmbientMusic(REP, 0.6, "ssv_amb_04_ctf",    1,1)
	SetAmbientMusic(REP, 0.3, "ssv_amb_04_ctf",    2,1)
	SetAmbientMusic(CIS, 1.0, "ssv_amb_04_ctf",  0,1)
	SetAmbientMusic(CIS, 0.6, "ssv_amb_04_ctf",    1,1)
	SetAmbientMusic(CIS, 0.3, "ssv_amb_04_ctf",    2,1)
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music05()
	MusicVariation = 5
	
	OpenMusicStreams()
	DecideMus05Var = math.random(1,4)
	
	if DecideMus05Var == 1 then
			print("ME5_RandomSides: Deciding Music05 variation... Choosing THE LONG WALK")
		SetAmbientMusic(REP, 1.0, "ssv_amb_05a_start",  0,1)
		SetAmbientMusic(REP, 0.65, "ssv_amb_05a_mid",    1,1)
		SetAmbientMusic(REP, 0.4, "ssv_amb_05a_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_05a_start",  0,1)
		SetAmbientMusic(CIS, 0.65, "ssv_amb_05a_mid",    1,1)
		SetAmbientMusic(CIS, 0.4, "ssv_amb_05a_end",    2,1)
	elseif DecideMus05Var == 2 then
			print("ME5_RandomSides: Deciding Music05 variation... Choosing COLLECTOR FEVER")
		SetAmbientMusic(REP, 1.0, "ssv_amb_05b_start",  0,1)
		SetAmbientMusic(REP, 0.9, "ssv_amb_05b_mid",    1,1)
		SetAmbientMusic(REP, 0.4, "ssv_amb_05b_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_05b_start",  0,1)
		SetAmbientMusic(CIS, 0.9, "ssv_amb_05b_mid",    1,1)
		SetAmbientMusic(CIS, 0.4, "ssv_amb_05b_end",    2,1)
	elseif DecideMus05Var == 3 then
			print("ME5_RandomSides: Deciding Music05 variation... Choosing PARAGON LOST")
		SetAmbientMusic(REP, 1.0, "ssv_amb_05c_start",  0,1)
		SetAmbientMusic(REP, 0.9, "ssv_amb_05c_mid",    1,1)
		SetAmbientMusic(REP, 0.55, "ssv_amb_05c_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_05c_start",  0,1)
		SetAmbientMusic(CIS, 0.9, "ssv_amb_05c_mid",    1,1)
		SetAmbientMusic(CIS, 0.55, "ssv_amb_05c_end",    2,1)
	elseif DecideMus05Var == 4 then
			print("ME5_RandomSides: Deciding Music05 variation... Choosing MAHAVID MINES SUITE")
		SetAmbientMusic(REP, 1.0, "ssv_amb_05d_start",  0,1)
		SetAmbientMusic(REP, 0.85, "ssv_amb_05d_mid",    1,1)
		SetAmbientMusic(REP, 0.3, "ssv_amb_05d_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_05d_start",  0,1)
		SetAmbientMusic(CIS, 0.85, "ssv_amb_05d_mid",    1,1)
		SetAmbientMusic(CIS, 0.3, "ssv_amb_05d_end",    2,1)
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music05 variation is loaded! D: :runaway:")
		SetAmbientMusic(REP, 1.0, "ssv_amb_05a_start",  0,1)
		SetAmbientMusic(REP, 0.65, "ssv_amb_05a_mid",    1,1)
		SetAmbientMusic(REP, 0.4, "ssv_amb_05a_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_05a_start",  0,1)
		SetAmbientMusic(CIS, 0.65, "ssv_amb_05a_mid",    1,1)
		SetAmbientMusic(CIS, 0.4, "ssv_amb_05a_end",    2,1)
	end
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music05_CTF()
	MusicVariation = 5
	
	OpenMusicStreams()
	--[[DecideMus05Var = math.random(1,4)
	
	if DecideMus05Var == 1 then
			print("ME5_RandomSides: Deciding Music05 variation... Choosing THE LONG WALK")
		music05_start = "ssv_amb_05a_start"
		music05_mid = "ssv_amb_05a_mid"
		music05_end = "ssv_amb_05a_end"
	elseif DecideMus05Var == 2 then
			print("ME5_RandomSides: Deciding Music05 variation... Choosing COLLECTOR FEVER")
		music05_start = "ssv_amb_05b_start"
		music05_mid = "ssv_amb_05b_mid"
		music05_end = "ssv_amb_05b_end"
	elseif DecideMus05Var == 3 then
			print("ME5_RandomSides: Deciding Music05 variation... Choosing PARAGON LOST")
		music05_start = "ssv_amb_05c_start"
		music05_mid = "ssv_amb_05c_mid"
		music05_end = "ssv_amb_05c_end"
	elseif DecideMus05Var == 3 then
			print("ME5_RandomSides: Deciding Music05 variation... Choosing MAHAVID MINES SUITE")
		music05_start = "ssv_amb_05d_start"
		music05_mid = "ssv_amb_05d_mid"
		music05_end = "ssv_amb_05d_end"
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music05 variation is loaded! D: :runaway:")
		music05_start = "ssv_amb_05_start"
		music05_mid = "ssv_amb_05_mid"
		music05_end = "ssv_amb_05_end"
	end]]
	
	SetAmbientMusic(REP, 1.0, "ssv_amb_05_ctf",  0,1)
	SetAmbientMusic(REP, 0.6, "ssv_amb_05_ctf",    1,1)
	SetAmbientMusic(REP, 0.3, "ssv_amb_05_ctf",    2,1)
	SetAmbientMusic(CIS, 1.0, "ssv_amb_05_ctf",  0,1)
	SetAmbientMusic(CIS, 0.6, "ssv_amb_05_ctf",    1,1)
	SetAmbientMusic(CIS, 0.3, "ssv_amb_05_ctf",    2,1)
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music06()
	MusicVariation = 6
	
	OpenMusicStreams()
	DecideMus06Var = math.random(1,2)
	
	if DecideMus06Var == 1 then
			print("ME5_RandomSides: Deciding Music06 variation... Choosing OVERLORD")
		SetAmbientMusic(REP, 1.0, "ssv_amb_06a_start",  0,1)
		SetAmbientMusic(REP, 0.75, "ssv_amb_06a_mid",    1,1)
		SetAmbientMusic(REP, 0.5, "ssv_amb_06a_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_06a_start",  0,1)
		SetAmbientMusic(CIS, 0.75, "ssv_amb_06a_mid",    1,1)
		SetAmbientMusic(CIS, 0.5, "ssv_amb_06a_end",    2,1)
	elseif DecideMus06Var == 2 then
			print("ME5_RandomSides: Deciding Music06 variation... Choosing SHADOW BROKER")
		SetAmbientMusic(REP, 1.0, "ssv_amb_06b_start",  0,1)
		SetAmbientMusic(REP, 0.9, "ssv_amb_06b_mid",    1,1)
		SetAmbientMusic(REP, 0.5, "ssv_amb_06b_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_06b_start",  0,1)
		SetAmbientMusic(CIS, 0.9, "ssv_amb_06b_mid",    1,1)
		SetAmbientMusic(CIS, 0.5, "ssv_amb_06b_end",    2,1)
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music06 variation is loaded! D: :runaway:")
		SetAmbientMusic(REP, 1.0, "ssv_amb_06_start",  0,1)
		SetAmbientMusic(REP, 0.7, "ssv_amb_06_mid",    1,1)
		SetAmbientMusic(REP, 0.5, "ssv_amb_06_end",    2,1)
		SetAmbientMusic(CIS, 1.0, "ssv_amb_06_start",  0,1)
		SetAmbientMusic(CIS, 0.7, "ssv_amb_06_mid",    1,1)
		SetAmbientMusic(CIS, 0.5, "ssv_amb_06_end",    2,1)
	end
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music06_CTF()
	MusicVariation = 6
	
	OpenMusicStreams()
	--[[DecideMus06Var = math.random(1,2)
	
	if DecideMus05Var == 1 then
			print("ME5_RandomSides: Deciding Music06 variation... Choosing OVERLORD")
		music06_start = "ssv_amb_06a_start"
		music06_mid = "ssv_amb_06a_mid"
		music06_end = "ssv_amb_06a_end"
	elseif DecideMus05Var == 2 then
			print("ME5_RandomSides: Deciding Music06 variation... Choosing SHADOW BROKER")
		music06_start = "ssv_amb_06b_start"
		music06_mid = "ssv_amb_06b_mid"
		music06_end = "ssv_amb_06b_end"
	else
			print("ME5_RandomSides: Uh oh! Incorrect Music06 variation is loaded! D: :runaway:")
		music06_start = "ssv_amb_06_start"
		music06_mid = "ssv_amb_06_mid"
		music06_end = "ssv_amb_06_end"
	end]]
	
	SetAmbientMusic(REP, 1.0, "ssv_amb_06_ctf",  0,1)
	SetAmbientMusic(REP, 0.6, "ssv_amb_06_ctf",    1,1)
	SetAmbientMusic(REP, 0.3, "ssv_amb_06_ctf",    2,1)
	SetAmbientMusic(CIS, 1.0, "ssv_amb_06_ctf",  0,1)
	SetAmbientMusic(CIS, 0.6, "ssv_amb_06_ctf",    1,1)
	SetAmbientMusic(CIS, 0.3, "ssv_amb_06_ctf",    2,1)
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music07()
	MusicVariation = 7
	
	OpenMusicStreams()
	
	SetAmbientMusic(REP, 1.0, "ssv_amb_07_start",  0,1)
	SetAmbientMusic(REP, 0.75, "ssv_amb_07_mid",    1,1)
	SetAmbientMusic(REP, 0.25, "ssv_amb_07_end",    2,1)
	SetAmbientMusic(CIS, 1.0, "ssv_amb_07_start",  0,1)
	SetAmbientMusic(CIS, 0.75, "ssv_amb_07_mid",    1,1)
	SetAmbientMusic(CIS, 0.25, "ssv_amb_07_end",    2,1)
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function Music08()
	MusicVariation = 8
	
	OpenMusicStreams()
	
	SetAmbientMusic(REP, 1.0, "ssv_amb_08_start",  0,1)
	SetAmbientMusic(REP, 0.7, "ssv_amb_08_mid",    1,1)
	SetAmbientMusic(REP, 0.3, "ssv_amb_08_end",    2,1)
	SetAmbientMusic(CIS, 1.0, "ssv_amb_08_start",  0,1)
	SetAmbientMusic(CIS, 0.7, "ssv_amb_08_mid",    1,1)
	SetAmbientMusic(CIS, 0.3, "ssv_amb_08_end",    2,1)
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
end

function SSVWorldVO()
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_vo_Streaming.lvl", "vo_streaming")
	
	SetBleedingVoiceOver(REP, REP, "ssv_adm_com_report_us_bleeding", 1)
	SetBleedingVoiceOver(REP, CIS, "ssv_adm_com_report_enemy_bleeding",   1)
	
	SetLowReinforcementsVoiceOver(REP, REP, "ssv_adm_com_report_defeat_imm", .1, 1)
	SetLowReinforcementsVoiceOver(REP, CIS, "ssv_adm_com_report_victory_imm", .1, 1)
	
	SetOutOfBoundsVoiceOver(REP, "ssv_adm_com_report_hiatus")
end

function GTHWorldVO()
	--OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_GTH_Streaming.lvl", "gth_vo_streaming")
	
	SetBleedingVoiceOver(CIS, REP, "gth_ann_com_report_enemy_bleeding",   1)
	SetBleedingVoiceOver(CIS, CIS, "gth_ann_com_report_us_bleeding", 1)
	
	SetOutOfBoundsVoiceOver(CIS, "gth_ann_com_report_hiatus")
end

function COLWorldVO()
	--OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\SFL_COL_Streaming.lvl", "col_vo_streaming")
end

function SoundFX()
	if not ScriptCB_InMultiplayer() then
		if ME5_SideVar == 0 then
			if RandomSide == 1 then
				SSVWorldVO()
				GTHWorldVO()
			elseif RandomSide == 2 then
				SSVWorldVO()
				COLWorldVO()
			end
		elseif ME5_SideVar == 1 then
			SSVWorldVO()
			GTHWorldVO()
		elseif ME5_SideVar == 2 then
			SSVWorldVO()
			COLWorldVO()
		else end
	else
		if onlineSideVar == 1 then
			SSVWorldVO()
			GTHWorldVO()
		elseif onlineSideVar == 2 then
			SSVWorldVO()
			COLWorldVO()
		else end
	end
	
	ScriptCB_SetSpawnDisplayGain(0.35, 1.0) -- 0.5, 2.5
	ScriptCB_SetDopplerFactor(3.0)
	
	ScaleSoundParameter("weapons",	"Gain", 0.82)
	ScaleSoundParameter("weapons_sniper",	"Gain", 1.0)
	ScaleSoundParameter("unit_weapon",	"Gain", 0.8)
	ScaleSoundParameter("Ordnance",	"Gain", 0.84)
	ScaleSoundParameter("Ordnance_large",	"Gain", 1.0)
	ScaleSoundParameter("Ordnance_grenade",	"Gain", 0.8)
	ScaleSoundParameter("Explosion",	"Gain", 0.9)
	ScaleSoundParameter("vehicles",	"Gain", 0.8)
	ScaleSoundParameter("body_movement",	"Gain", 0.8)
	ScaleSoundParameter("vehicle_foley",	"Gain", 0.8)
	ScaleSoundParameter("Collision",	"Gain", 0.8)
	ScaleSoundParameter("props",	"Gain", 0.88)
	ScaleSoundParameter("ambientenv",	"Gain", 0.8)
	ScaleSoundParameter("ssv_vo",	"Gain", 0.7)
	ScaleSoundParameter("gth_vo",	"Gain", 0.8)
	ScaleSoundParameter("col_vo",	"Gain", 0.8)
	ScaleSoundParameter("ssv_inf_pain_vo",	"Gain", 0.80)
	ScaleSoundParameter("gth_inf_pain_vo",	"Gain", 0.65)
	ScaleSoundParameter("col_inf_pain_vo",	"Gain", 0.75)
	--ScaleSoundParameter("Music",	"Gain", 0.9)
	if isModMap == 1 then
		ScaleSoundParameter("ambientenv",	"Gain", 0.95)
	else
		ScaleSoundParameter("ambientenv",	"Gain", 0.45)
	end
	
	SetSoundEffect("ScopeDisplayAmbient",  "me5_sniper_scope_ambient")
    SetSoundEffect("ScopeDisplayZoomIn",  "me5_sniper_scope_zoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "me5_sniper_scope_zoomout")
    --SetSoundEffect("WeaponUnableSelect",  "com_weap_inf_weaponchange_null")
    --SetSoundEffect("WeaponModeUnableSelect",  "com_weap_inf_modechange_null")
    SetSoundEffect("SpawnDisplayUnitChange",       "me5_shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept",       "me5_shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "me5_shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "me5_shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack",             "me5_shell_menu_exit")
	
	-- Create a text document in the folder I mentioned and name it "TESTwhat.txt"

		--[[local testfile = assert(io.open("TESTwhat.txt", "r"))
		local testioinput = testfile:read("*all")
		testfile:close()
		print("ZeroEngineSuckageLevel: " .. testioinput)]]
end

function PostInitStuff()
		print("ME5_RandomSides: PostInitStuff()")
		local PostInitStuffDebug = "ME5_RandomSides: Changing ticket counts for ObjectiveSurvival..."
	if ObjectiveSurvivalHasRan == 1 then
		if Setup_SSVxGTH_sm == 1 or Setup_SSVxCOL_sm == 1 or Setup_SSVxGTH_xs == 1 or Setup_SSVxCOL_xs == 1 or Setup_SSVxGTH_xxs == 1 then
				print(PostInitStuffDebug)
			SetReinforcementCount(1, 100)
			SetReinforcementCount(2, 100)
		elseif Setup_SSVxGTH_med == 1 or Setup_SSVxCOL_med == 1 then
				print(PostInitStuffDebug)
			SetReinforcementCount(1, 125)
			SetReinforcementCount(2, 125)
		elseif Setup_SSVxGTH_lg == 1 or Setup_SSVxCOL_lg == 1 then
				print(PostInitStuffDebug)
			SetReinforcementCount(1, 150)
			SetReinforcementCount(2, 150)
		else
			print("ME5_RandomSides: BY THE GODDESS, WHAT ON THESSIA IS HAPPENING")
		end
	else 
		print("ME5_RandomSides: BY THE GODDESS, WHAT ON THESSIA IS HAPPENING")
	end
end



	print("ME5_RandomSides: Exited")

-- myTeamConfig = {
    -- rep = {
        -- team = REP,
        -- units = 32,
        -- reinforcements = -1,
        -- pilot    = { "rep_inf_ep3_pilot",26},
        -- marine   = { "rep_inf_ep3_marine",6},
    -- },
    -- cis = {
        -- team = CIS,
        -- units = 32,
        -- reinforcements = -1,
        -- pilot    = { "cis_inf_pilot",26},
        -- marine   = { "cis_inf_marine",6},
    -- }
-- }

-- function ScriptInit()
    
    -- SetupUnits()
    -- SetupTeams(myTeamConfig)

    -- -- do any pool allocations, custom loading here
    -- if myScriptInit then
        -- myScriptInit()
        -- myScriptInit = nil
    -- end

-- end