RandomSide = math.random(1,3)
--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--

-- load the gametype script
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("ME5_RandomSides")

    --  Empire Attacking (attacker is always #1)
    REP = 2
    CIS = 1
    --  These variables do not change
    ATT = 1
    DEF = 2


---------------------------------------------------------------------------
-- FUNCTION:    ScriptInit
-- PURPOSE:     This function is only run once
-- INPUT:
-- OUTPUT:
-- NOTES:       The name, 'ScriptInit' is a chosen convention, and each
--              mission script must contain a version of this function, as
--              it is called from C to start the mission.
---------------------------------------------------------------------------

function ScriptPostLoad()
	SoundEvent_SetupTeams( REP, 'rep', CIS, 'cis' )
	
	AddDeathRegion("fall")
    EnableSPHeroRules()
    
    
--CP SETUP for CONQUEST
    --SetObjectTeam("CP3", 1)
    
   KillObject("CP7OBJ")
   KillObject("shieldgen")
   KillObject("CP7OBJ")
   KillObject("hangarcp")
   KillObject("enemyspawn")
   KillObject("enemyspawn2")
   KillObject("echoback2")
   KillObject("echoback1")
   KillObject("shield")	
   DisableBarriers("conquestbar")
   DisableBarriers("bombbar")
   
  SetProperty("ship", "MaxHealth", 1e+37)
  SetProperty("ship", "CurHealth", 1e+37)
  SetProperty("ship2", "MaxHealth", 1e+37)
  SetProperty("ship2", "CurHealth", 1e+37)
  SetProperty("ship3", "MaxHealth", 1e+37)
  SetProperty("ship3", "CurHealth", 1e+37)
    
    

    ctf = ObjectiveOneFlagCTF:New{teamATT = 1, teamDEF = 2,
                           textATT = "game.modes.1flag", textDEF = "game.modes.1flag2", hideCPs = true, multiplayerRules = true, 
                           captureLimit = 5, flag = "flag", flagIcon = "flag_icon", 
                           flagIconScale = 3.0, homeRegion = "HomeRegion",
                           captureRegionATT = "Team2Capture", captureRegionDEF = "Team1Capture",
                           capRegionMarkerATT = "hud_objective_icon_circle", capRegionMarkerDEF = "hud_objective_icon_circle",
                           capRegionMarkerScaleATT = 3.0, capRegionMarkerScaleDEF = 3.0}             
                           
    ctf:Start()
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			music01 = "ssv_amb_03_start"
			music02 = "ssv_amb_03_mid"
			music03 = "ssv_amb_03_end"
			musicTimerValue = 180
		elseif RandomSide == 2 then
			music01 = "ssv_amb_04_start"
			music02 = "ssv_amb_04_mid"
			music03 = "ssv_amb_04_end"
			musicTimerValue = 240
		elseif RandomSide == 3 then
			music01 = "ssv_amb_06_start"
			music02 = "ssv_amb_06_mid"
			music03 = "ssv_amb_06_end"
			musicTimerValue = 185
		end
	else
		music01 = "ssv_amb_03_start"
		music02 = "ssv_amb_03_mid"
		music03 = "ssv_amb_03_end"
		musicTimerValue = 180
	end
	
	ScriptCB_PlayInGameMusic(music01)
	
	CreateTimer("music_timer")
		SetTimerValue("music_timer", musicTimerValue)
		StartTimer("music_timer")
		ShowTimer("music_timer")
		OnTimerElapse(
			function(timer)
				RandomMusic = math.random(1,3)
				
				if RandomMusic == 1 then
						print("execute music variation 1")
					ScriptCB_PlayInGameMusic(music01)
				elseif RandomMusic == 2 then
						print("execute music variation 2")
					ScriptCB_PlayInGameMusic(music02)
				elseif RandomMusic == 3 then
						print("execute music variation 3")
					ScriptCB_PlayInGameMusic(music03)
				end
				
				SetTimerValue("music_timer", musicTimerValue)
				StartTimer("music_timer")
			end,
			"music_timer"
		)
	
end

function ScriptInit()
	StealArtistHeap(1280*1024)
    -- Designers, these two lines *MUST* be first.
    SetPS2ModelMemory(4000000)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;hot1")
	PreLoadStuff()


    SetMaxFlyHeight(70)
    SetMaxPlayerFlyHeight(70)
--    SetGroundFlyerMap(1);

    ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl;ME5n")
    ReadDataFile("sound\\hot.lvl;hot1gcw")
    ReadDataFile("SIDE\\tur.lvl",
					"tur_bldg_hoth_dishturret",
					"tur_bldg_hoth_lasermortar")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\me5tur.lvl",
					"tur_bldg_mturret")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			LoadSSV()
			LoadGTH()
			Setup_SSVxGTH_sm()
			DecideSSVHeroClass()
					print("Load/setup SSV versus GTH")
					
		elseif RandomSide == 2 then
			LoadSSV()
			LoadECL()
			Setup_SSVxECL_sm()
			DecideSSVHeroClass()
					print("Load/setup SSV versus ECL")
			
		elseif RandomSide == 3 then
			LoadSSV()
			LoadGTH()
			LoadECL()
			Setup_GTHxECL_sm() -- Setup_GTHxECL_lg()
					print("Load/setup GTH versus ECL")
					
		end
	else
		LoadSSV()
		LoadGTH()
		Setup_SSVxGTH_sm()
			print("decide ssv hero::adept")
		SetHeroClass(REP, "ssv_hero_shepard_adept")
				print("Load/setup SSV versus GTH")
				
	end
    
   
    --  Level Stats
    ClearWalkers()
    SetMemoryPoolSize("EntityWalker", 0)
    AddWalkerType(0, 0) -- 0 droidekas
    AddWalkerType(1, 0) -- 6 atsts with 1 leg pairs each
    AddWalkerType(2, 0) -- 2 atats with 2 leg pairs each
    
    local weaponCnt = 260
    SetMemoryPoolSize("Aimer", 50)
    SetMemoryPoolSize("AmmoCounter", weaponCnt)
    SetMemoryPoolSize("BaseHint", 300)
    SetMemoryPoolSize("EnergyBar", weaponCnt)
    SetMemoryPoolSize("EntityCloth", 44)
    SetMemoryPoolSize("EntityLight", 240)
    SetMemoryPoolSize("EntityFlyer", 6)
    SetMemoryPoolSize("EntitySoundStream", 5)
    SetMemoryPoolSize("EntitySoundStatic", 13)
    SetMemoryPoolSize("FlagItem", 1)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix", 90)
    SetMemoryPoolSize("MountedTurret", 50)
    SetMemoryPoolSize("Music", 89)
    SetMemoryPoolSize("Navigator", 40)
    SetMemoryPoolSize("Obstacle", 400)
    SetMemoryPoolSize("OrdnanceTowCable", 40) -- !!!! need +4 extra for wrapped/fallen cables !!!!
    SetMemoryPoolSize("PathNode", 180)
    SetMemoryPoolSize("RedOmniLight", 250)
    SetMemoryPoolSize("SoldierAnimation", 313)
    SetMemoryPoolSize("TreeGridStack", 350)
    SetMemoryPoolSize("UnitAgent", 46)
    SetMemoryPoolSize("UnitController", 46)
    SetMemoryPoolSize("Weapon", weaponCnt)

	ReadDataFile("HOT\\hot1.lvl", "hoth_ctf")
    --ReadDataFile("tan\\tan1.lvl", "tan1_obj")
    SetSpawnDelay(15.0, 0.25)
    SetDenseEnvironment("false")
    SetDefenderSnipeRange(170)
    AddDeathRegion("Death")


    --  Sound Stats
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5n_music")
    OpenAudioStream("sound\\hot.lvl",  "hot1gcw")
    OpenAudioStream("sound\\hot.lvl",  "hot1gcw")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")

	SetBleedingVoiceOver(REP, REP, "ssv_adm_com_report_us_bleeding", 1)
	SetBleedingVoiceOver(REP, CIS, "ssv_adm_com_report_enemy_bleeding",   1)
    SetBleedingVoiceOver(CIS, REP, "cis_off_com_report_enemy_losing",   1)
    SetBleedingVoiceOver(CIS, CIS, "cis_off_com_report_us_overwhelmed", 1)
    
    SetLowReinforcementsVoiceOver(REP, REP, "rep_off_defeat_im", .1, 1)
    SetLowReinforcementsVoiceOver(REP, CIS, "rep_off_victory_im", .1, 1)
    SetLowReinforcementsVoiceOver(CIS, CIS, "cis_off_defeat_im", .1, 1)
    SetLowReinforcementsVoiceOver(CIS, REP, "cis_off_victory_im", .1, 1)    

    SetOutOfBoundsVoiceOver(REP, "ssv_adm_com_report_hiatus")
    SetOutOfBoundsVoiceOver(1, "cisleaving")

	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			SSVWorldVO()
			GTHWorldVO()
		elseif RandomSide == 2 then
			SSVWorldVO()
		elseif RandomSide == 3 then
			GTHWorldVO()
		end
	else
		SSVWorldVO()
		GTHWorldVO()
	end
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
	
	SoundFX()


    --  Camera Stats
    --Hoth
    --Hangar
    AddCameraShot(0.944210, 0.065541, 0.321983, -0.022350, -500.489838, 0.797472, -68.773849)
    --Shield Generator
    AddCameraShot(0.371197, 0.008190, -0.928292, 0.020482, -473.384155, -17.880533, 132.126801)
    --Battlefield
    AddCameraShot(0.927083, 0.020456, -0.374206, 0.008257, -333.221558, 0.676043, -14.027348)


end
