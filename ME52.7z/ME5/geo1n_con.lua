RandomSide = math.random(1,3)
--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--

-- load the gametype script
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ME5_RandomSides")

--  REP Attacking (attacker is always #1)
    REP = 1;
    CIS = 2;
	CD1 = 3;
    --  These variables do not change
    ATT = 1;
    DEF = 2;
---------------------------------------------------------------------------
-- FUNCTION:    ScriptInit
-- PURPOSE:     This function is only run once
-- INPUT:
-- OUTPUT:
-- NOTES:       The name, 'ScriptInit' is a chosen convention, and each
--              mission script must contain a version of this function, as
--              it is called from C to start the mission.
---------------------------------------------------------------------------

function ScriptPostLoad()
	AddAIGoal(3, "Deathmatch", 100)
    cp1 = CommandPost:New{name = "cp1"}
    cp2 = CommandPost:New{name = "cp2"}
    cp3 = CommandPost:New{name = "cp3"}
    cp4 = CommandPost:New{name = "cp4"}
    cp6 = CommandPost:New{name = "cp6"}
    cp7 = CommandPost:New{name = "cp7"}
    cp8 = CommandPost:New{name = "cp8"}
    
    --This sets up the actual objective.  This needs to happen after cp's are defined
    conquest = ObjectiveConquest:New{teamATT = ATT, teamDEF = DEF, text = "level.geo1.objectives.conquest", multiplayerRules = true}
    
    --This adds the CPs to the objective.  This needs to happen after the objective is set up
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp6)
    conquest:AddCommandPost(cp7)
    conquest:AddCommandPost(cp8)
    
    conquest:Start()
    
    EnableSPHeroRules()
    
    AddDeathRegion("deathregion")
    AddDeathRegion("deathregion2")
    AddDeathRegion("deathregion3")
    AddDeathRegion("deathregion4")
    AddDeathRegion("deathregion5")
	
	SetProperty("cp1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp2", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp3", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp4", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp6", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp7", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp8", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp2", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp3", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp4", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp6", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp7", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp8", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp4", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp7", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp8", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp4", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp6", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp7", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp8", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			
			SetProperty("cp1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp3", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp4", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp6", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp7", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp8", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp3", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp4", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp6", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp7", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp8", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp2", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp3", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp4", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp6", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp7", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp8", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp2", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp3", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp4", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp6", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp7", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp8", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
		elseif RandomSide == 2 then
			herosupport = AIHeroSupport:New{AIATTHeroHealth = 4000, AIDEFHeroHealth = 4000, gameMode = "NonConquest",}
			herosupport:SetHeroClass(CIS, "col_hero_harbinger")
			herosupport:AddSpawnCP("cp1","cp1_spawn")
			herosupport:AddSpawnCP("cp2","cp2_spawn")
			herosupport:AddSpawnCP("cp3","cp3_spawn")
			herosupport:AddSpawnCP("cp4","cp4_spawn")
			herosupport:AddSpawnCP("cp6","cp6_spawn")
			herosupport:AddSpawnCP("cp7","cp7_spawn")
			herosupport:AddSpawnCP("cp8","cp8_spawn")
			herosupport:Start()
			
			SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp4", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp7", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp8", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp4", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp6", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp7", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp8", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		elseif RandomSide == 3 then
			SetProperty("cp1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp4", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp7", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp8", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp2", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp3", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp4", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp6", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp7", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp8", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
		end
	else
		SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp4", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp6", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp7", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp8", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp4", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp6", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp7", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp8", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
	end
    
end
 
function ScriptInit()
    StealArtistHeap(800*1024)
    -- Designers, these two lines *MUST* be first.
    SetPS2ModelMemory(3500000)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;geo1")
	PreLoadStuff()

    SetTeamAggressiveness(CIS, 1.0)
    SetTeamAggressiveness(REP, 1.0)

    SetMemoryPoolSize("Music", 40)
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\geo.lvl;geo1cw")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\me5tur.lvl",
					"tur_bldg_mturret")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
				print("Random 1")
			LoadSSV()
			LoadGTH()
			Setup_SSVxGTH_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus GTH")
				
		elseif RandomSide == 2 then
				print("Random 2")
			LoadSSV()
			LoadCOL()
			Setup_SSVxCOL_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus COL")
				
		elseif RandomSide == 3 then
				print("Random 3")
			LoadSSV()
			LoadECL()
			Setup_SSVxECL_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus ECL")
				
		end
	else
		LoadSSV()
		LoadCOL()
		Setup_SSVxCOL_lg()
			print("decide ssv hero::soldier")
		SetHeroClass(REP, "ssv_hero_shepard_soldier")
		SetHeroClass(CIS, "col_hero_harbinger")
				print("Load/setup SSV versus COL")
			
	end
	
    --  Level Stats

    ClearWalkers()
    -- SetMemoryPoolSize("EntityWalker", -1)
    AddWalkerType(0, 0) -- 8 droidekas (special case: 0 leg pairs)
    AddWalkerType(2, 4) -- 2 spider walkers with 2 leg pairs each
    AddWalkerType(3, 0) -- 2 attes with 3 leg pairs each
    local weaponcnt = 240
    SetMemoryPoolSize("Aimer", 50)
    SetMemoryPoolSize("AmmoCounter", weaponcnt)
    SetMemoryPoolSize("BaseHint", 100)
    SetMemoryPoolSize("CommandWalker", 1)
    SetMemoryPoolSize("EnergyBar", weaponcnt)
    SetMemoryPoolSize("EntityFlyer", 6)
    SetMemoryPoolSize("EntityHover", 16)
    SetMemoryPoolSize("EntityLight", 50)
    SetMemoryPoolSize("EntitySoundStream", 4)
    SetMemoryPoolSize("MountedTurret", 15)
    SetMemoryPoolSize("Navigator", 50)
    SetMemoryPoolSize("Obstacle", 450)
    SetMemoryPoolSize("PathFollower", 50)
    SetMemoryPoolSize("PathNode", 100)
	SetMemoryPoolSize("SoldierAnimation", 274)
    SetMemoryPoolSize("TreeGridStack", 300)
    SetMemoryPoolSize("UnitAgent", 50)
    SetMemoryPoolSize("UnitController", 50)
    SetMemoryPoolSize("Weapon", weaponcnt)

    SetSpawnDelay(10.0, 0.25)

    ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ME5\\geo1.lvl", "geo1_conquest")

    SetDenseEnvironment("false")
    SetMinFlyHeight(-65)
    SetMaxFlyHeight(50)
    SetMaxPlayerFlyHeight(50)



    --  Birdies
    --SetNumBirdTypes(1)
    --SetBirdType(0.0,10.0,"dragon")
    --SetBirdFlockMinHeight(90.0)

    --  Sound
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5n_music")
    OpenAudioStream("sound\\geo.lvl",  "geo1cw")
    OpenAudioStream("sound\\geo.lvl",  "geo1cw")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")

    if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			Music03()
			
			SSVWorldVO()
			GTHWorldVO()
		elseif RandomSide == 2 then
			Music05()
			
			SSVWorldVO()
		elseif RandomSide == 3 then
			Music03()
			
			SSVWorldVO()
		end
	else
		Music05()
		
		SSVWorldVO()
	end
	
	SoundFX()


    --ActivateBonus(CIS, "SNEAK_ATTACK")
    --ActivateBonus(REP, "SNEAK_ATTACK")

    SetAttackingTeam(ATT)

    --Opening Satalite Shot
    --Geo
    --Mountain
    AddCameraShot(0.996091, 0.085528, -0.022005, 0.001889, -6.942698, -59.197201, 26.136919)
    --Wrecked Ship
    AddCameraShot(0.906778, 0.081875, -0.411906, 0.037192, 26.373968, -59.937874, 122.553581)
    --War Room  
    --AddCameraShot(0.994219, 0.074374, 0.077228, -0.005777, 90.939568, -49.293945, -69.571136)
end

