RandomSide = math.random(1,6)
--DecideShepClass = math.random(1,6)
--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("ME5_RandomSides")

function ScriptPostLoad()
        --This defines the CPs.  These need to happen first
    cp1 = CommandPost:New{name = "cp1"}
    cp2 = CommandPost:New{name = "cp2"}
    cp3 = CommandPost:New{name = "cp3"}

	cp6 = CommandPost:New{name = "cp6"}
	cp7 = CommandPost:New{name = "cp7"}
	cp8 = CommandPost:New{name = "cp8"}

    
    --This sets up the actual objective.  This needs to happen after cp's are defined
    conquest = ObjectiveConquest:New{teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true}
    
    --This adds the CPs to the objective.  This needs to happen after the objective is set up
	conquest:AddCommandPost(cp1)
	conquest:AddCommandPost(cp2)
	conquest:AddCommandPost(cp3)

	conquest:AddCommandPost(cp6)
	conquest:AddCommandPost(cp7)
	conquest:AddCommandPost(cp8)
	
	--[[if RandomSide < 4 then
		-- This sets up the AI hero script
		if not ScriptCB_InMultiplayer() then   
			herosupport = AIHeroSupport:New{AIATTHeroHealth = 3500,	gameMode = "NonConquest",}
			herosupport:SetHeroClass(REP, "ssv_hero_shepard")
			herosupport:AddSpawnCP("cp1","CP1_SpawnPath")
			herosupport:AddSpawnCP("cp2","CP2_SpawnPath")
			herosupport:AddSpawnCP("cp3","CP3_SpawnPath")
			herosupport:AddSpawnCP("cp6","CP6_SpawnPath")
			herosupport:AddSpawnCP("cp7","CP9SpawnPath")
			herosupport:AddSpawnCP("cp8","CP8SpawnPath")
			herosupport:Start()
			else
		end
	end]]
	
	SetProperty("cp1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp2", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp3", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp6", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp7", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp8", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp2", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp3", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp6", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp7", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp8", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			--[[herosupport = AIHeroSupport:New{AIATTHeroHealth = 3500,	gameMode = "NonConquest",}
			herosupport:SetHeroClass(REP, "ssv_hero_shepard")
			herosupport:AddSpawnCP("cp1","CP1_SpawnPath")
			herosupport:AddSpawnCP("cp2","CP2_SpawnPath")
			herosupport:AddSpawnCP("cp3","CP3_SpawnPath")
			herosupport:AddSpawnCP("cp6","CP6_SpawnPath")
			herosupport:AddSpawnCP("cp7","CP9SpawnPath")
			herosupport:AddSpawnCP("cp8","CP8SpawnPath")
			herosupport:Start()]]
			
			SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp7", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp8", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp6", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp7", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp8", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			
			SetProperty("cp1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp3", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp6", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp7", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp8", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp3", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp6", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp7", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp8", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp2", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp3", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp6", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp7", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp8", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp2", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp3", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp6", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp7", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp8", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
		elseif RandomSide == 2 then
			herosupport = AIHeroSupport:New{AIATTHeroHealth = 4000, AIDEFHeroHealth = 4000, gameMode = "NonConquest",}
			herosupport:SetHeroClass(CIS, "col_hero_harbinger")
			herosupport:AddSpawnCP("cp1","CP1_SpawnPath")
			herosupport:AddSpawnCP("cp2","CP2_SpawnPath")
			herosupport:AddSpawnCP("cp3","CP3_SpawnPath")
			herosupport:AddSpawnCP("cp6","CP6_SpawnPath")
			herosupport:AddSpawnCP("cp7","CP9SpawnPath")
			herosupport:AddSpawnCP("cp8","CP8SpawnPath")
			herosupport:Start()
			
			SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp7", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp8", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp6", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp7", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp8", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		elseif RandomSide == 3 then
			--[[herosupport = AIHeroSupport:New{AIATTHeroHealth = 3500,	gameMode = "NonConquest",}
			herosupport:SetHeroClass(REP, "ssv_hero_shepard")
			herosupport:AddSpawnCP("cp1","CP1_SpawnPath")
			herosupport:AddSpawnCP("cp2","CP2_SpawnPath")
			herosupport:AddSpawnCP("cp3","CP3_SpawnPath")
			herosupport:AddSpawnCP("cp6","CP6_SpawnPath")
			herosupport:AddSpawnCP("cp7","CP9SpawnPath")
			herosupport:AddSpawnCP("cp8","CP8SpawnPath")
			herosupport:Start()]]
			
			SetProperty("cp1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp7", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp8", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp2", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp3", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp6", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp7", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp8", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
		elseif RandomSide == 4 then
			SetProperty("cp1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp3", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp6", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp7", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp8", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp3", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp6", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp7", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp8", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp2", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp3", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp6", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp7", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp8", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp2", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp3", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp6", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp7", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp8", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
		end
	else
		SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp6", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp7", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp8", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp6", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp7", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp8", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
	end

conquest:Start()
  AddAIGoal(1, "conquest", 1000)
 AddAIGoal(2, "conquest", 1000)
 AddAIGoal(3, "conquest", 1000)
EnableSPHeroRules()    
	
end

---------------------------------------------------------------------------
-- FUNCTION:    ScriptInit
-- PURPOSE:     This function is only run once
-- INPUT:
-- OUTPUT:
-- NOTES:       The name, 'ScriptInit' is a chosen convention, and each
--              mission script must contain a version of this function, as
--              it is called from C to start the mission.
---------------------------------------------------------------------------


function ScriptInit()
    -- Designers, these two lines *MUST* be first!
    StealArtistHeap(256*1024)
    SetPS2ModelMemory(2097152 + 65536 * 10)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;tat2")
	PreLoadStuff()

    --  Republic Attacking (attacker is always #1)
	REP = 1
	CIS = 2
	DES = 3
	--  These variables do not change
	ATT = 1
	DEF = 2
	
    SetMaxFlyHeight(40)
	SetMaxPlayerFlyHeight(40) 
    
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\tat.lvl;tat2cw")
	ReadDataFile("SIDE\\tur.lvl", 
					"tur_bldg_laser",
					"tur_bldg_tat_barge")    
	ReadDataFile("SIDE\\des.lvl",
					"tat_inf_jawa")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\me5tur.lvl",
					"tur_bldg_mturret")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			LoadSSV()
			LoadGTH()
			Setup_SSVxGTH_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus GTH")
					
		elseif RandomSide == 2 then
			LoadSSV()
			LoadCOL()
			Setup_SSVxCOL_lg()
			DecideSSVHeroClass()
			SetHeroClass(CIS, "col_hero_harbinger")
					print("Load/setup SSV versus COL")
			
		elseif RandomSide == 3 then
			LoadSSV()
			LoadECL()
			Setup_SSVxECL_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus ECL")
			
		elseif RandomSide == 4 then
			LoadSSV()
			LoadGTH()
			LoadECL()
			Setup_GTHxECL_lg()
					print("Load/setup GTH versus ECL")
			
		elseif RandomSide == 5 then
			LoadSSV()
			LoadRPR()
			Setup_SSVxRPR_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus RPR")
					
		elseif RandomSide == 6 then
			LoadSSV()
			LoadCER()
			Setup_SSVxCER_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus CER")
				
		end
	else
		LoadSSV()
		LoadCOL()
		Setup_SSVxCOL_lg()
			print("decide ssv hero::legion")
		SetHeroClass(REP, "ssv_hero_legion")
		SetHeroClass(CIS, "col_hero_harbinger")
				print("Load/setup SSV versus COL")
		
	end
	
	-- SetHeroClass(REP, "ssv_hero_shepard_vanguard")
	
	-- Jawas --------------------------
	SetTeamName (3, "locals")
	AddUnitClass (3, "tat_inf_jawa", 7)
	SetUnitCount (3, 7)
	SetTeamAsFriend(3,ATT)
	SetTeamAsFriend(3,DEF)
	SetTeamAsFriend(ATT,3)
	SetTeamAsFriend(DEF,3)
	-----------------------------------

    --  Level Stats
    ClearWalkers()
    AddWalkerType(0, 0) -- special -> droidekas
    AddWalkerType(1, 0) -- 1x2 (1 pair of legs)
    AddWalkerType(2, 0) -- 2x2 (2 pairs of legs)
    AddWalkerType(3, 0) -- 3x2 (3 pairs of legs)
    
    local weaponCnt = 230
    SetMemoryPoolSize("Aimer", 23)
    SetMemoryPoolSize("AmmoCounter", weaponCnt)
    SetMemoryPoolSize("BaseHint", 325)
    SetMemoryPoolSize("EnergyBar", weaponCnt)
    SetMemoryPoolSize("EntityCloth", 19)
	SetMemoryPoolSize("EntityFlyer", 6) -- to account for rocket upgrade
    SetMemoryPoolSize("EntityHover", 1)
    SetMemoryPoolSize("EntitySoundStream", 2)
    SetMemoryPoolSize("EntitySoundStatic", 43)
    SetMemoryPoolSize("MountedTurret", 20)
    SetMemoryPoolSize("Navigator", 50)
    SetMemoryPoolSize("Obstacle", 667)
    SetMemoryPoolSize("PathFollower", 50)
    SetMemoryPoolSize("PathNode", 256)
	SetMemoryPoolSize("SoldierAnimation", 382)
    SetMemoryPoolSize("TreeGridStack", 325)
    SetMemoryPoolSize("UnitAgent", 50)
    SetMemoryPoolSize("UnitController", 50)
    SetMemoryPoolSize("Weapon", weaponCnt)

    SetSpawnDelay(10.0, 0.25)
    ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ME5\\tat2.lvl", "tat2_con")
    SetDenseEnvironment("false")


    --  Sound Stats
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\Sound\\ME5.lvl",  "ME5n_music")
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\Sound\\ME5.lvl",  "TAT_ambiance")
    OpenAudioStream("sound\\tat.lvl",  "tat2")
    OpenAudioStream("sound\\tat.lvl",  "tat2")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")

	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			Music01()
			
			SSVWorldVO()
			GTHWorldVO()
		elseif RandomSide == 2 then
			Music05()
			
			SSVWorldVO()
		elseif RandomSide == 3 then
			Music01()
			
			SSVWorldVO()
		elseif RandomSide == 4 then
			Music04()
			
			GTHWorldVO()
		elseif RandomSide == 5 then
			Music08()
			
			SSVWorldVO()
		elseif RandomSide == 6 then
			Music07()
			
			SSVWorldVO()
		end
	else
		Music05()
		
		SSVWorldVO()
	end
	
	SoundFX()


    SetAttackingTeam(ATT)

    --  Camera Stats
    --Tat2 Mos Eisley
	AddCameraShot(0.974338, -0.222180, 0.035172, 0.008020, -82.664650, 23.668301, 43.955681);
	AddCameraShot(0.390197, -0.089729, -0.893040, -0.205362, 23.563562, 12.914885, -101.465561);
	AddCameraShot(0.169759, 0.002225, -0.985398, 0.012916, 126.972809, 4.039628, -22.020613);
	AddCameraShot(0.677453, -0.041535, 0.733016, 0.044942, 97.517807, 4.039628, 36.853477);
	AddCameraShot(0.866029, -0.156506, 0.467299, 0.084449, 7.685640, 7.130688, -10.895234);
end


