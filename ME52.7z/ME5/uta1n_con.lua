RandomSide = math.random(1,5)
--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("ME5_RandomSides")

	CIS = 1;
	REP = 2;
	CD1 = 3;
--  These variables do not change
    ATT = 1;
    DEF = 2;
----------------------------------------------------------------------
-- FUNCTION:    ScriptInit
-- PURPOSE:     This function is only run once
-- INPUT:
-- OUTPUT:
-- NOTES:       The name, 'ScriptInit' is a chosen convention, and each
--              mission script must contain a version of this function, as
--              it is called from C to start the mission.
---------------------------------------------------------------------------
function ScriptPostLoad()

    EnableSPHeroRules()
    
    --CP SETUP for CONQUEST

    cp1 = CommandPost:New{name = "CON_CP1"}
    cp2 = CommandPost:New{name = "con_CP1a"}
    cp3 = CommandPost:New{name = "CON_CP2"}
    cp4 = CommandPost:New{name = "CON_CP5"}
    cp5 = CommandPost:New{name = "CON_CP6"}
	cp6 = CommandPost:New{name = "CON_CP7"}

    conquest = ObjectiveConquest:New{teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true}
    
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)
	
    conquest:Start()
    DisableBarriers("Barrier445");
	
	SetProperty("CON_CP1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("con_CP1a", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CON_CP2", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CON_CP5", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CON_CP6", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CON_CP7", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CON_CP1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("con_CP1a", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CON_CP2", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CON_CP5", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CON_CP6", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CON_CP7", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			SetProperty("CON_CP1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("con_CP1a", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("CON_CP2", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("CON_CP5", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("CON_CP6", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("CON_CP7", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("CON_CP1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("con_CP1a", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("CON_CP2", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("CON_CP5", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("CON_CP6", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("CON_CP7", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			
			SetProperty("CON_CP1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("con_CP1a", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("CON_CP2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("CON_CP5", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("CON_CP6", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("CON_CP7", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("CON_CP1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("con_CP1a", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("CON_CP2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("CON_CP5", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("CON_CP6", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("CON_CP7", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("CON_CP1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("CON_CP1a", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("CON_CP2", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("CON_CP5", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("CON_CP6", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("CON_CP7", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("CON_CP1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("CON_CP1a", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("CON_CP2", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("CON_CP5", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("CON_CP6", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("CON_CP7", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
		elseif RandomSide == 2 then
			herosupport = AIHeroSupport:New{AIATTHeroHealth = 4000, AIDEFHeroHealth = 4000, gameMode = "NonConquest",}
			herosupport:SetHeroClass(CIS, "col_hero_harbinger")
			herosupport:AddSpawnCP("con_cp1","con_cp1spawn")
			herosupport:AddSpawnCP("con_cp1a","con_cp1aspawn")
			herosupport:AddSpawnCP("con_cp2","con_cp2spawn")
			herosupport:AddSpawnCP("con_cp5","con_cp5spawn")
			herosupport:AddSpawnCP("con_cp6","con_cp6spawn")
			herosupport:AddSpawnCP("con_cp7","con_cp7_spawn")
			herosupport:Start()
			
			SetProperty("CON_CP1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("con_CP1a", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("CON_CP2", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("CON_CP5", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("CON_CP6", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("CON_CP7", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("CON_CP1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("con_CP1a", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("CON_CP2", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("CON_CP5", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("CON_CP6", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("CON_CP7", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		elseif RandomSide == 3 then
			SetProperty("CON_CP1", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("con_CP1a", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("CON_CP2", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("CON_CP5", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("CON_CP6", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("CON_CP7", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("CON_CP1", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("con_CP1a", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("CON_CP2", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("CON_CP5", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("CON_CP6", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("CON_CP7", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
		elseif RandomSide == 4 then
			SetProperty("CON_CP1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("con_CP1a", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("CON_CP2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("CON_CP5", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("CON_CP6", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("CON_CP7", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("CON_CP1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("con_CP1a", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("CON_CP2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("CON_CP5", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("CON_CP6", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("CON_CP7", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("CON_CP1", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("CON_CP1a", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("CON_CP2", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("CON_CP5", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("CON_CP6", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("CON_CP7", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("CON_CP1", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("CON_CP1a", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("CON_CP2", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("CON_CP5", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("CON_CP6", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("CON_CP7", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
		end
	else
		SetProperty("CON_CP1", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("con_CP1a", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("CON_CP2", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("CON_CP5", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("CON_CP6", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("CON_CP7", "VO_Rep_CisCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("CON_CP1", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
		SetProperty("con_CP1a", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
		SetProperty("CON_CP2", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
		SetProperty("CON_CP5", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
		SetProperty("CON_CP6", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
		SetProperty("CON_CP7", "VO_Rep_CisLost", "ssv_adm_com_report_eclLost_commandpost")
	end
	
 end
 
 
function ScriptInit()
    -- Designers, these two lines *MUST* be first!
    StealArtistHeap(1228*1024)
    SetPS2ModelMemory(4380000)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;uta1")
	PreLoadStuff()	

    --  Republic Attacking (attacker is always #1)
   
    SetTeamAggressiveness(REP, 0.95)
    SetTeamAggressiveness(CIS, 0.95)
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\uta.lvl;uta1cw")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\me5tur.lvl",
					"tur_bldg_mturret")

    if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			LoadSSV()
			LoadGTH()
			Setup_SSVxGTH_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus GTH")
				
		elseif RandomSide == 2 then
			LoadSSV()
			LoadCOL()
			Setup_SSVxCOL_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus COL")
				
		elseif RandomSide == 3 then
			LoadSSV()
			LoadECL()
			Setup_SSVxECL_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus ECL")
				
		elseif RandomSide == 4 then
			LoadSSV()
			LoadGTH()
			LoadECL()
			Setup_GTHxECL_med()
					print("Load/setup GTH versus ECL")
					
		elseif RandomSide == 5 then
			LoadSSV()
			LoadCER()
			Setup_SSVxCER_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus CER")
		end
	else
		LoadSSV()
		LoadECL()
		Setup_SSVxECL_med()
			print("decide ssv hero::sentinel")
		SetHeroClass(REP, "ssv_hero_sentinel")
				print("Load/setup SSV versus ECL")
			
	end

    --  Level Stats
    ClearWalkers()
    AddWalkerType(0, 0)     -- droidekas
    AddWalkerType(1, 0) -- ATRTa (special case: 0 leg pairs)
    local weaponCnt = 220
    SetMemoryPoolSize("Aimer", 36)
    SetMemoryPoolSize("AmmoCounter", weaponCnt)
    SetMemoryPoolSize("BaseHint", 200)
    SetMemoryPoolSize("Combo::DamageSample", 610)
    SetMemoryPoolSize("EnergyBar", weaponCnt)
    SetMemoryPoolSize("EntityHover",6)
    SetMemoryPoolSize("EntityLight", 60)
    SetMemoryPoolSize("EntityFlyer", 8)
    SetMemoryPoolSize("EntitySoundStream", 8)
    SetMemoryPoolSize("EntitySoundStatic", 27)
    SetMemoryPoolSize("MountedTurret", 10)
    SetMemoryPoolSize("Navigator", 40)
    SetMemoryPoolSize("Obstacle", 400)
    SetMemoryPoolSize("PathFollower", 40)
    SetMemoryPoolSize("PathNode", 150)
	SetMemoryPoolSize("SoldierAnimation", 230)
    SetMemoryPoolSize("TentacleSimulator", 0)
    SetMemoryPoolSize("TreeGridStack", 225)
    SetMemoryPoolSize("UnitAgent", 40)
    SetMemoryPoolSize("UnitController", 40)
    SetMemoryPoolSize("Weapon", weaponCnt)
    
    SetSpawnDelay(10.0, 0.25)
    ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ME5\\uta1.lvl", "uta1_Conquest")
    AddDeathRegion("deathregion")
    SetDenseEnvironment("false")
	SetMaxFlyHeight(29.5)
	SetMaxPlayerFlyHeight(29.5)


    --  Sound Stats
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5n_music")
    OpenAudioStream("sound\\uta.lvl",  "uta1")
    OpenAudioStream("sound\\uta.lvl",  "uta1")
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")

    if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			Music04()
			
			SSVWorldVO()
			GTHWorldVO()
		elseif RandomSide == 2 then
			Music02()
			
			SSVWorldVO()
		elseif RandomSide == 3 then
			Music04()
			
			SSVWorldVO()
		elseif RandomSide == 4 then
			Music04()
			
			GTHWorldVO()
		elseif RandomSide == 5 then
			Music07()
			
			SSVWorldVO()
		end
	else
		Music04()
		
		SSVWorldVO()
	end
	
	SoundFX()

--  Camera Stats - Utapau: Sinkhole
	AddCameraShot(-0.428091, 0.045649, -0.897494, -0.095703, 162.714951, 45.857063, 40.647118)
	AddCameraShot(-0.194861, -0.001600, -0.980796, 0.008055, -126.179787, 16.113789, 70.012894);
	AddCameraShot(-0.462548, -0.020922, -0.885442, 0.040050, -16.947638, 4.561796, 156.926956);
	AddCameraShot(0.995310, 0.024582, -0.093535, 0.002310, 38.288612, 4.561796, 243.298508);
	AddCameraShot(0.827070, 0.017093, 0.561719, -0.011609, -24.457638, 8.834146, 296.544586);
	AddCameraShot(0.998875, 0.004912, -0.047174, 0.000232, -45.868237, 2.978215, 216.217880);


end


