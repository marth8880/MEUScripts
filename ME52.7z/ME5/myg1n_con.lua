--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--

-- load the gametype script --
ScriptCB_DoFile("ObjectiveConquest") 
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ME5_RandomSides")

    --  Republic Attacking (attacker is always #1)
    REP = 1;
    CIS = 2;
	CD1 = 3;
    --  These variables do not change
    ATT = 1;
    DEF = 2;
    
---------------------------------------------------------------------------
-- FUNCTION:    ScriptInit
-- PURPOSE:     This function is only run once
-- INPUT:
-- OUTPUT:
-- NOTES:       The name, 'ScriptInit' is a chosen convention, and each
--              mission script must contain a version of this function, as
--              it is called from C to start the mission.
---------------------------------------------------------------------------
 function ScriptPostLoad()
 
    DisableBarriers("dropship")
    DisableBarriers("shield_03")
    DisableBarriers("shield_02")
    DisableBarriers("shield_01")
    DisableBarriers("ctf")
    DisableBarriers("ctf1")
    DisableBarriers("ctf2")
    DisableBarriers("ctf3")
    DisableBarriers("coresh1")

    EnableSPHeroRules()
    
    cp1 = CommandPost:New{name = "CP1_CON"}
    cp2 = CommandPost:New{name = "CP2_CON"}
    --cp3 = CommandPost:New{name = "CP3_CON"}
    cp4 = CommandPost:New{name = "CP4_CON"}
    cp5 = CommandPost:New{name = "CP5_CON"}
    cp7 = CommandPost:New{name = "CP7_CON"}
    --cp8 = CommandPost:New{name = "CP8_CON"}
    
    conquest = ObjectiveConquest:New{teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true}
	
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    --conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp7)
    --conquest:AddCommandPost(cp8)
    
    conquest:Start()
	
	SetProperty("CP1_CON", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP2_CON", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP4_CON", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP5_CON", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP7_CON", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP1_CON", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP2_CON", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP4_CON", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP5_CON", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP7_CON", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP1_CON", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
	SetProperty("CP2_CON", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
	SetProperty("CP4_CON", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
	SetProperty("CP5_CON", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
	SetProperty("CP7_CON", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
	SetProperty("CP1_CON", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
	SetProperty("CP2_CON", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
	SetProperty("CP4_CON", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
	SetProperty("CP5_CON", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
	SetProperty("CP7_CON", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
	
	SetProperty("CP1_CON", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
	SetProperty("CP2_CON", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
	SetProperty("CP4_CON", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
	SetProperty("CP5_CON", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
	SetProperty("CP7_CON", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
	SetProperty("CP1_CON", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
	SetProperty("CP2_CON", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
	SetProperty("CP4_CON", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
	SetProperty("CP5_CON", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
	SetProperty("CP7_CON", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
	SetProperty("CP1_CON", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
	SetProperty("CP2_CON", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
	SetProperty("CP4_CON", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
	SetProperty("CP5_CON", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
	SetProperty("CP7_CON", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
	SetProperty("CP1_CON", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
	SetProperty("CP2_CON", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
	SetProperty("CP4_CON", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
	SetProperty("CP5_CON", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
	SetProperty("CP7_CON", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
    
end
 
function ScriptInit()
    -- Designers, these two lines *MUST* be first!
    StealArtistHeap(2048 * 1024)
    SetPS2ModelMemory(4000000)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;myg1")
	PreLoadStuff()

	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\myg.lvl;myg1cw")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\me5tur.lvl",
					"tur_bldg_mturret")
	
	LoadSSV()
	LoadGTH()
	Setup_SSVxGTH_med()
	if not ScriptCB_InMultiplayer() then
		DecideSSVHeroClass()
	else
			print("decide ssv hero::sentinel")
		SetHeroClass(REP, "ssv_hero_shepard_sentinel")
	end
			print("Load/setup SSV versus GTH")

    --  Level Stats
    ClearWalkers()
    AddWalkerType(0, 0)
    AddWalkerType(2, 0)
    local weaponCnt = 230
    SetMemoryPoolSize("Aimer", 60)
    SetMemoryPoolSize("AmmoCounter", weaponCnt)
    SetMemoryPoolSize("BaseHint", 250)
    SetMemoryPoolSize("EnergyBar", weaponCnt)
	SetMemoryPoolSize("EntityCloth", 19)
    SetMemoryPoolSize("EntityHover", 7)
    SetMemoryPoolSize("EntityFlyer", 6)
    SetMemoryPoolSize("EntitySoundStream", 1)
    SetMemoryPoolSize("EntitySoundStatic", 76)
    SetMemoryPoolSize("MountedTurret", 20)
    SetMemoryPoolSize("Navigator", 50)
    SetMemoryPoolSize("Obstacle", 500)
    SetMemoryPoolSize("PathNode", 256)
	SetMemoryPoolSize("SoldierAnimation", 313)
    SetMemoryPoolSize("TreeGridStack", 275)
    SetMemoryPoolSize("UnitAgent", 50)
    SetMemoryPoolSize("UnitController", 50)
    SetMemoryPoolSize("Weapon", weaponCnt)
    
    SetSpawnDelay(10.0, 0.25)
    ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ME5\\myg1.lvl", "myg1_conquest")
    SetDenseEnvironment("false")
    AddDeathRegion("deathregion")
    SetMaxFlyHeight(20)
    SetMaxPlayerFlyHeight(20)

    --  Sound Stats
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5n_music")
    OpenAudioStream("sound\\myg.lvl",  "myg1")
    OpenAudioStream("sound\\myg.lvl",  "myg1")
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")
	
	Music03()
	
	SSVWorldVO()
	GTHWorldVO()
	
	SoundFX()


        --Camera Shizzle--
        
        -- Collector Shot
    AddCameraShot(0.008315, 0.000001, -0.999965, 0.000074, -64.894348, 5.541570, 201.711090);
	AddCameraShot(0.633584, -0.048454, -0.769907, -0.058879, -171.257629, 7.728924, 28.249359);
	AddCameraShot(-0.001735, -0.000089, -0.998692, 0.051092, -146.093109, 4.418306, -167.739212);
	AddCameraShot(0.984182, -0.048488, 0.170190, 0.008385, 1.725611, 8.877428, 88.413887);
	AddCameraShot(0.141407, -0.012274, -0.986168, -0.085598, -77.743042, 8.067328, 42.336128);
	AddCameraShot(0.797017, 0.029661, 0.602810, -0.022434, -45.726467, 7.754435, -47.544712);
	AddCameraShot(0.998764, 0.044818, -0.021459, 0.000963, -71.276566, 4.417432, 221.054550);
end


