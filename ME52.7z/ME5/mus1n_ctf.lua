RandomSide = math.random(1,6)
--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--

ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ME5_RandomSides")

--  Republic Attacking (attacker is always #1)
    REP = 1;
    CIS = 2;
	CD1 = 3;
    --  These variables do not change
    ATT = 1;
    DEF = 2;
 
 --PostLoad, this is all done after all loading, etc.
function ScriptPostLoad()
     PlayAnimRise()
    UnblockPlanningGraphArcs("Connection74")
        DisableBarriers("1")
    DisableBarriers("BALCONEY")
    DisableBarriers("bALCONEY2")
    DisableBarriers("hallway_f")
    DisableBarriers("hackdoor")
    DisableBarriers("outside")
     
    OnObjectRespawnName(PlayAnimRise, "DingDong");
    OnObjectKillName(PlayAnimDrop, "DingDong");
 --Capture the Flag for stand-alone multiplayer
                -- These set the flags geometry names.
                --GeometryName sets the geometry when hte flag is on the ground
                --CarriedGeometryName sets the geometry that appears over a player's head that is carrying the flag
        SetProperty("FLAG1", "GeometryName", "com_icon_republic_flag")
        SetProperty("FLAG1", "CarriedGeometryName", "com_icon_republic_flag_carried")
        SetProperty("FLAG2", "GeometryName", "com_icon_cis_flag")
        SetProperty("FLAG2", "CarriedGeometryName", "com_icon_cis_flag_carried")

                --This makes sure the flag is colorized when it has been dropped on the ground
        SetClassProperty("com_item_flag", "DroppedColorize", 1)
    SoundEvent_SetupTeams( REP, 'rep', CIS, 'cis' )
    --This is all the actual ctf objective setup
    ctf = ObjectiveCTF:New{teamATT = ATT, teamDEF = DEF, captureLimit = 5,  textATT = "game.modes.ctf", textDEF = "game.modes.ctf2",  multiplayerRules = true}
    ctf:AddFlag{name = "FLAG1", homeRegion = "FLAG1_HOME", captureRegion = "FLAG2_HOME",
                capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3.0, 
                icon = "", mapIcon = "flag_icon", mapIconScale = 3.0}
    ctf:AddFlag{name = "FLAG2", homeRegion = "FLAG2_HOME", captureRegion = "FLAG1_HOME",
                capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3.0, 
                icon = "", mapIcon = "flag_icon", mapIconScale = 3.0}
    ctf:Start()
    EnableSPHeroRules()
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			music01 = "ssv_amb_06_start"
			music02 = "ssv_amb_06_mid"
			music03 = "ssv_amb_06_end"
			musicTimerValue = 185
		elseif RandomSide == 2 then
			music01 = "ssv_amb_02_start"
			music02 = "ssv_amb_02_mid"
			music03 = "ssv_amb_02_end"
			musicTimerValue = 120
		elseif RandomSide == 3 then
			music01 = "ssv_amb_04_start"
			music02 = "ssv_amb_04_mid"
			music03 = "ssv_amb_04_end"
			musicTimerValue = 240
		elseif RandomSide == 4 then
			music01 = "ssv_amb_04_start"
			music02 = "ssv_amb_04_mid"
			music03 = "ssv_amb_04_end"
			musicTimerValue = 240
		elseif RandomSide == 5 then
			music01 = "ssv_amb_08_start"
			music02 = "ssv_amb_08_mid"
			music03 = "ssv_amb_08_end"
			musicTimerValue = 180
		elseif RandomSide == 6 then
			music01 = "ssv_amb_06_start"
			music02 = "ssv_amb_06_mid"
			music03 = "ssv_amb_06_end"
			musicTimerValue = 185
		end
	else
		music01 = "ssv_amb_06_start"
		music02 = "ssv_amb_06_mid"
		music03 = "ssv_amb_06_end"
		musicTimerValue = 185
	end
	
	ScriptCB_PlayInGameMusic(music01)
	
	CreateTimer("music_timer")
		SetTimerValue("music_timer", musicTimerValue)
		StartTimer("music_timer")
		ShowTimer("music_timer")
		OnTimerElapse(
			function(timer)
				RandomMusic = math.random(1,3)
				
				if RandomMusic == 1 then
						print("execute music variation 1")
					ScriptCB_PlayInGameMusic(music01)
				elseif RandomMusic == 2 then
						print("execute music variation 2")
					ScriptCB_PlayInGameMusic(music02)
				elseif RandomMusic == 3 then
						print("execute music variation 3")
					ScriptCB_PlayInGameMusic(music03)
				end
				
				SetTimerValue("music_timer", musicTimerValue)
				StartTimer("music_timer")
			end,
			"music_timer"
		)
	
 end
 --START BRIDGEWORK!

-- OPEN
function PlayAnimDrop()
      PauseAnimation("lava_bridge_raise");    
      RewindAnimation("lava_bridge_drop");
      PlayAnimation("lava_bridge_drop");
        
    -- prevent the AI from running across it
    BlockPlanningGraphArcs("Connection82");
    BlockPlanningGraphArcs("Connection83");
    EnableBarriers("Bridge");
    
end
-- CLOSE
function PlayAnimRise()
      PauseAnimation("lava_bridge_drop");
      RewindAnimation("lava_bridge_raise");
      PlayAnimation("lava_bridge_raise");
            

        -- allow the AI to run across it
    UnblockPlanningGraphArcs("Connection82");
    UnblockPlanningGraphArcs("Connection83");
    DisableBarriers("Bridge");
 end


function ScriptInit()
StealArtistHeap(128*1024)
	-- Designers, these two lines *MUST* be first!
	SetPS2ModelMemory(3600000)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;mus1")
	PreLoadStuff()
	
    SetTeamAggressiveness(REP, 0.95)
    SetTeamAggressiveness(CIS, 0.95)
    AISnipeSuitabilityDist(30)
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\mus.lvl;mus1cw")

	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			LoadSSV()
			LoadGTH()
			Setup_SSVxGTH_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus GTH")
				
		elseif RandomSide == 2 then
			LoadSSV()
			LoadCOL()
			Setup_SSVxCOL_med()
			DecideSSVHeroClass()
			SetHeroClass(CIS, "col_hero_harbinger")
					print("Load/setup SSV versus COL")
				
		elseif RandomSide == 3 then
			LoadSSV()
			LoadECL()
			Setup_SSVxECL_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus ECL")
				
		elseif RandomSide == 4 then
			LoadSSV()
			LoadGTH()
			LoadECL()
			Setup_GTHxECL_med()
					print("Load/setup GTH versus ECL")
		
		elseif RandomSide == 5 then
			LoadSSV()
			LoadRPR()
			Setup_SSVxRPR_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus RPR")
		
		elseif RandomSide == 6 then
			LoadSSV()
			LoadCER()
			Setup_SSVxCER_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus CER")
		end
	else
		LoadSSV()
		LoadCER()
		Setup_SSVxCER_med()
			print("decide ssv hero::jack")
		SetHeroClass(REP, "ssv_hero_jack")
				print("Load/setup SSV versus CER")
			
	end
    
    ClearWalkers()
    SetMemoryPoolSize("Aimer", 0)
    SetMemoryPoolSize("EntityFlyer", 4)
    SetMemoryPoolSize("EntityCloth", 19)
    SetMemoryPoolSize("EntitySoundStatic", 133)
    SetMemoryPoolSize("MountedTurret", 0)
    SetMemoryPoolSize("Obstacle", 290)

    SetSpawnDelay(10.0, 0.25)
    SetDenseEnvironment("false")
    --AddDeathRegion("Sarlac01")
        SetMaxFlyHeight(84.16)
SetMaxPlayerFlyHeight(90)
    AISnipeSuitabilityDist(30)
    SetMemoryPoolSize("FlagItem", 2) 
    
    ReadDataFile("mus\\mus1.lvl", "MUS1_CTF")
     
    --  Sound Stats
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5n_music")
    OpenAudioStream("sound\\mus.lvl",  "mus1")
    OpenAudioStream("sound\\mus.lvl",  "mus1")
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")

	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			SSVWorldVO()
			GTHWorldVO()
		elseif RandomSide == 2 then
			SSVWorldVO()
		elseif RandomSide == 3 then
			SSVWorldVO()
		elseif RandomSide == 4 then
			GTHWorldVO()
		elseif RandomSide == 5 then
			SSVWorldVO()
		elseif RandomSide == 6 then
			SSVWorldVO()
		end
	else
		SSVWorldVO()
	end
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
	
	SoundFX()


   	AddCameraShot(0.446393, -0.064402, -0.883371, -0.127445, -93.406929, 72.953865, -35.479401);
	
	AddCameraShot(-0.297655, 0.057972, -0.935337, -0.182169, -2.384067, 71.165306, 18.453350);
	
	AddCameraShot(0.972488, -0.098362, 0.210097, 0.021250, -42.577881, 69.453072, 4.454691);
	
	AddCameraShot(0.951592, -0.190766, -0.236300, -0.047371, -44.607018, 77.906273, 113.228661);
	
	AddCameraShot(0.841151, -0.105984, 0.526154, 0.066295, 109.567764, 77.906273, 7.873035);
	
	AddCameraShot(0.818472, -0.025863, 0.573678, 0.018127, 125.781593, 61.423031, 9.809184);
	
	AddCameraShot(-0.104764, 0.000163, -0.994496, -0.001550, -13.319855, 70.673264, 63.436607);
	
	AddCameraShot(0.971739, 0.102058, 0.211692, -0.022233, -5.680069, 68.543945, 57.904160);
	
	AddCameraShot(0.178437, 0.004624, -0.983610, 0.025488, -66.947433, 68.543945, 6.745875);

    AddCameraShot(-0.400665, 0.076364, -0896894, -0.170941, 96.201210, 79.913033, -58.604382)
end




