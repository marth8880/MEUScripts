RandomSide = math.random(1,5)
--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--

-- load the gametype script
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ME5_RandomSides")

--  Republic Attacking (attacker is always #1)
REP = 1;
CIS = 2;
CD1 = 3;

--  These variables do not change
ATT = 1;
DEF = 2;

---------------------------------------------------------------------------
-- FUNCTION:    ScriptInit
-- PURPOSE:     This function is only run once
-- INPUT:
-- OUTPUT:
-- NOTES:       The name, 'ScriptInit' is a chosen convention, and each
--              mission script must contain a version of this function, as
--              it is called from C to start the mission.
---------------------------------------------------------------------------

 function ScriptPostLoad()
        --This defines the CPs.  These need to happen first
    cp1 = CommandPost:New{name = "cp1-1"}
    cp2 = CommandPost:New{name = "cp2-1"}
    cp3 = CommandPost:New{name = "cp3-1"}
    cp4 = CommandPost:New{name = "cp4-1"}
    cp5 = CommandPost:New{name = "cp5-1"}
    cp6 = CommandPost:New{name = "cp6-1"}

    
    --This sets up the actual objective.  This needs to happen after cp's are defined
    conquest = ObjectiveConquest:New{teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true}
    
    --This adds the CPs to the objective.  This needs to happen after the objective is set up
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)

conquest:Start()   
    EnableSPHeroRules()
	
	SetProperty("cp1-1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp2-1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp3-1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp4-1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp5-1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp6-1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp1-1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp2-1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp3-1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp4-1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp5-1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp6-1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			SetProperty("cp1-1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp2-1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp3-1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp4-1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp5-1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp6-1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp1-1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp2-1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp3-1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp4-1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp5-1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp6-1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			
			SetProperty("cp1-1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp2-1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp3-1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp4-1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp5-1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp6-1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp1-1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp2-1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp3-1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp4-1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp5-1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp6-1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp1-1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp2-1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp3-1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp4-1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp5-1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp6-1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp1-1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp2-1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp3-1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp4-1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp5-1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp6-1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
		elseif RandomSide == 2 then
			herosupport = AIHeroSupport:New{AIATTHeroHealth = 4000, AIDEFHeroHealth = 4000, gameMode = "NonConquest",}
			herosupport:SetHeroClass(CIS, "col_hero_harbinger")
			herosupport:AddSpawnCP("cp1-1","cp1spawn")
			herosupport:AddSpawnCP("cp2-1","cp2spawn")
			herosupport:AddSpawnCP("cp3-1","cp3spawn")
			herosupport:AddSpawnCP("cp4-1","cp4spawn")
			herosupport:AddSpawnCP("cp5-1","cp5spawn")
			herosupport:AddSpawnCP("cp6-1","cp6-1_spawn")
			herosupport:Start()
			
			SetProperty("cp1-1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp2-1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp3-1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp4-1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp5-1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp6-1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp1-1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp2-1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp3-1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp4-1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp5-1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp6-1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		elseif RandomSide == 3 then
			SetProperty("cp1-1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp2-1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp3-1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp4-1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp5-1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp6-1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp1-1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp2-1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp3-1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp4-1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp5-1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp6-1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
		end
	else
		print("no cp voiceover change")
	end
    
end

function ScriptInit()
	StealArtistHeap(132*1024)
    -- Designers, these two lines *MUST* be first.
    SetPS2ModelMemory(3200000)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;fel1")
	PreLoadStuff()

    SetMemoryPoolSize("Music", 39)


    SetMaxFlyHeight(53)
    SetMaxPlayerFlyHeight (53)
    
    SetAttackingTeam(ATT)
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\fel.lvl;fel1cw")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\me5tur.lvl",
					"tur_bldg_mturret")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			LoadSSV()
			LoadGTH()
			Setup_SSVxGTH_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus GTH")
				
		elseif RandomSide == 2 then
			LoadSSV()
			LoadCOL()
			Setup_SSVxCOL_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus COL")
				
		elseif RandomSide == 3 then
			LoadSSV()
			LoadECL()
			Setup_SSVxECL_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus ECL")
				
		elseif RandomSide == 4 then
			LoadSSV()
			LoadRPR()
			Setup_SSVxRPR_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus RPR")
					
		elseif RandomSide == 5 then
			LoadSSV()
			LoadCER()
			Setup_SSVxCER_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus CER")
				
		end
	else
		LoadSSV()
		LoadRPR()
		Setup_SSVxRPR_lg()
			print("decide ssv hero::infiltrator")
		SetHeroClass(REP, "ssv_hero_shepard_infiltrator")
				print("Load/setup SSV versus RPR")
			
	end


    --  Level Stats 
    ClearWalkers()
    -- AddWalkerType(0, 8)
    --AddWalkerType(5, 2) -- 2 attes with 2 leg pairs each
    --AddWalkerType(3, 1) -- 3 acklays with 3 leg pairs each
    -- AddWalkerType(1, 2)
    -- AddWalkerType(0, 4)
    local weaponCnt = 260
    SetMemoryPoolSize("Aimer", 20)
    SetMemoryPoolSize("AmmoCounter", weaponCnt)
    SetMemoryPoolSize("BaseHint", 200)
    SetMemoryPoolSize("EnergyBar", weaponCnt)
    SetMemoryPoolSize("EntityHover", 3)
    SetMemoryPoolSize("EntityFlyer", 6)
    SetMemoryPoolSize("EntitySoundStream", 1)
    SetMemoryPoolSize("EntitySoundStatic", 0)
    SetMemoryPoolSize("EntityWalker", 5)
    SetMemoryPoolSize("MountedTurret", 15)
    SetMemoryPoolSize("Obstacle", 400)
    SetMemoryPoolSize("PathNode", 512)
	SetMemoryPoolSize("SoldierAnimation", 230)
    SetMemoryPoolSize("TreeGridStack", 280)
    SetMemoryPoolSize("Weapon", weaponCnt)
    
    SetSpawnDelay(10.0, 0.25)
    ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ME5\\fel1.lvl", "fel1_conquest")
    SetDenseEnvironment("false")
    SetAIViewMultiplier(0.65)
    --AddDeathRegion("Sarlac01")

    --  Birdies
    SetNumBirdTypes(1)
    SetBirdType(0,1.0,"bird")
    

    --  Sound Stats
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5n_music")
    OpenAudioStream("sound\\fel.lvl",  "fel1")
    OpenAudioStream("sound\\fel.lvl",  "fel1")
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")

    if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			Music03()
			
			SSVWorldVO()
		elseif RandomSide == 2 then
			Music05()
			
			SSVWorldVO()
		elseif RandomSide == 3 then
			Music01()
			
			SSVWorldVO()
		elseif RandomSide == 4 then
			Music08()
			
			SSVWorldVO()
		elseif RandomSide == 5 then
			Music07()
			
			SSVWorldVO()
		end
	else
		Music08()
		
		SSVWorldVO()
	end
	
	SoundFX()



    --  Camera Stats
    AddCameraShot(0.896307, -0.171348, -0.401716, -0.076796, -116.306931, 31.039505, 20.757469)
    AddCameraShot(0.909343, -0.201967, -0.355083, -0.078865, -116.306931, 31.039505, 20.757469)
    AddCameraShot(0.543199, 0.115521, -0.813428, 0.172990, -108.378189, 13.564240, -40.644150)
    AddCameraShot(0.970610, 0.135659, 0.196866, -0.027515, -3.214346, 11.924586, -44.687294)
    AddCameraShot(0.346130, 0.046311, -0.928766, 0.124267, 87.431061, 20.881388, 13.070729)
    AddCameraShot(0.468084, 0.095611, -0.860724, 0.175812, 18.063482, 19.360580, 18.178158)



end


