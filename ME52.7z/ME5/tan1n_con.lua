--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--

-- load the gametype script
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ME5_RandomSides")

--  Republic Attacking (attacker is always #1)
    REP = 1;
    CIS = 2;
	CD1 = 3;
    --  These variables do not change
    ATT = 1;
    DEF = 2;

---------------------------------------------------------------------------
-- FUNCTION:    ScriptInit
-- PURPOSE:     This function is only run once
-- INPUT:
-- OUTPUT:
-- NOTES:       The name, 'ScriptInit' is a chosen convention, and each
--              mission script must contain a version of this function, as
--              it is called from C to start the mission.
---------------------------------------------------------------------------
function ScriptPostLoad()

    AddDeathRegion("turbinedeath")
    
    KillObject("blastdoor")
    DisableBarriers("barracks")
    DisableBarriers("liea")
    SetMapNorthAngle(180)
    
-- Turbine Stuff -- 
    BlockPlanningGraphArcs("turbine")
    OnObjectKillName(destturbine, "turbineconsole")
    OnObjectRespawnName(returbine, "turbineconsole")
    
    
    cp4 = CommandPost:New{name = "CP4CON"}
    cp5 = CommandPost:New{name = "CP5CON"}
    cp6 = CommandPost:New{name = "CP6CON"}
    cp7 = CommandPost:New{name = "CP7CON"}
    
    conquest = ObjectiveConquest:New{teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true}
    
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)
    conquest:AddCommandPost(cp7)
    
    conquest:Start()
    
    EnableSPHeroRules()
	
	if not ScriptCB_InMultiplayer() then
		herosupport = AIHeroSupport:New{AIATTHeroHealth = 4000, AIDEFHeroHealth = 4000, gameMode = "NonConquest",}
		herosupport:SetHeroClass(CIS, "col_hero_harbinger")
		herosupport:AddSpawnCP("CP4CON","cp4path")
		herosupport:AddSpawnCP("CP5CON","cp5path")
		herosupport:AddSpawnCP("CP6CON","cp6path")
		herosupport:AddSpawnCP("CP7CON","CP7SPAWNPATH")
		herosupport:Start()
	else
	end
	
	SetProperty("CP4CON", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP5CON", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP6CON", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP7CON", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP4CON", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP5CON", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP6CON", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP7CON", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	
	SetProperty("CP4CON", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
	SetProperty("CP5CON", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
	SetProperty("CP6CON", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
	SetProperty("CP7CON", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
	SetProperty("CP4CON", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
	SetProperty("CP5CON", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
	SetProperty("CP6CON", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
	SetProperty("CP7CON", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
    
   --Setup Timer-- 

    timeConsole = CreateTimer("timeConsole")

    SetTimerValue(timeConsole, 0.3)

    StartTimer(timeConsole)
    OnTimerElapse(
        function(timer)
            SetProperty("turbineconsole", "CurHealth", GetObjectHealth("turbineconsole") + 1)
            DestroyTimer(timer)
        end,
    timeConsole
    )

    
end

function destturbine()
    UnblockPlanningGraphArcs("turbine")
    PauseAnimation("Turbine Animation")
    RemoveRegion("turbinedeath")
--    SetProperty("woodr", "CurHealth", 15)
end

function returbine()
    BlockPlanningGraphArcs("turbine")
    PlayAnimation("Turbine Animation")
    AddDeathRegion("turbinedeath")
--    SetProperty("woodr", "CurHealth", 15)
end

function ScriptInit()
    -- Designers, these two lines *MUST* be first!
    StealArtistHeap(840000)
    SetPS2ModelMemory(4990000)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;tan1")
	PreLoadStuff()
    SetWorldExtents(1064.5)
	
	-- This sets the agressiveness for each team.
	--SetTeamAggressiveness(CIS,(0.99))
	SetTeamAggressiveness(REP,(0.99))
	
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\tan.lvl;tan1cw")
	
	LoadSSV()
	LoadCOL()
	Setup_SSVxCOL_med()
	if not ScriptCB_InMultiplayer() then
		DecideSSVHeroClass()
	else
			print("decide ssv hero::engineer")
		SetHeroClass(REP, "ssv_hero_shepard_engineer")
		SetHeroClass(CIS, "col_hero_harbinger")
	end
			print("Load/setup SSV versus COL")

    --  Level Stats
    ClearWalkers()
    AddWalkerType(0, 0)  -- number of droidekas

     local weaponCnt = 177
     local guyCnt = 50
     SetMemoryPoolSize ("Aimer", 17)
     SetMemoryPoolSize ("AmmoCounter", weaponCnt)
     SetMemoryPoolSize ("BaseHint", 250)
     SetMemoryPoolSize ("EnergyBar", weaponCnt)
     SetMemoryPoolSize ("EntityCloth", 18)
     SetMemoryPoolSize ("EntitySoundStream", 14)
     SetMemoryPoolSize ("EntitySoundStatic", 45)
     SetMemoryPoolSize ("EntityFlyer", 6)
     SetMemoryPoolSize ("MountedTurret", 2)
	 SetMemoryPoolSize ("Music", 72)
     SetMemoryPoolSize ("Navigator", guyCnt)
     SetMemoryPoolSize ("Obstacle", 250)
     SetMemoryPoolSize ("PathFollower", guyCnt)
     SetMemoryPoolSize ("PathNode", 384)
	 SetMemoryPoolSize ("SoldierAnimation", 249)
     SetMemoryPoolSize ("SoundspaceRegion", 15)
     SetMemoryPoolSize ("TentacleSimulator", 0)
     SetMemoryPoolSize ("TreeGridStack", 150)
     SetMemoryPoolSize ("UnitAgent", guyCnt)
     SetMemoryPoolSize ("UnitController", guyCnt)
     SetMemoryPoolSize ("Weapon", weaponCnt)

     
  --  SetMemoryPoolSize("Obstacle", 182)
  --
    SetSpawnDelay(10.0, 0.25)
    ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ME5\\tan1.lvl", "tan1_conquest")
    SetDenseEnvironment("false")
    AISnipeSuitabilityDist(30)
    --AddDeathRegion("Sarlac01")
    -- SetMaxFlyHeight(90)
    -- SetMaxPlayerFlyHeight(90)

    --  Sound Stats
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5n_music")
    OpenAudioStream("sound\\tan.lvl",  "tan1")
    OpenAudioStream("sound\\tan.lvl",  "tan1")
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")

	SSVWorldVO()
	
	Music02()
	
	SoundFX()


    --  Camera Stats
    AddCameraShot(0.233199, -0.019441, -0.968874, -0.080771, -240.755920, 11.457644, 105.944176);
    AddCameraShot(-0.395561, 0.079428, -0.897092, -0.180135, -264.022278, 6.745873, 122.715752);
    AddCameraShot(0.546703, -0.041547, -0.833891, -0.063371, -309.709900, 5.168304, 145.334381);

end


