RandomSide = math.random(1,6)
--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--

ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("ME5_RandomSides")

--  These variables do not change
ATT = 1
DEF = 2

--  Republic Attacking (attacker is always #1)
CIS = ATT
REP = DEF

--PostLoad, this is all done after all loading, etc.
function ScriptPostLoad()
	--Switch the flag appearance(s) for CW vs GCW
    SetProperty("ctf_flag1", "GeometryName", "com_icon_cis_flag")
    SetProperty("ctf_flag1", "CarriedGeometryName", "com_icon_cis_flag_carried")

    SetProperty("ctf_flag2", "GeometryName", "com_icon_republic_flag")
    SetProperty("ctf_flag2", "CarriedGeometryName", "com_icon_republic_flag_carried")
	
	--Set up all the CTF objective stuff 
	ctf = ObjectiveCTF:New{teamATT = ATT, teamDEF = DEF, captureLimit = 5,	textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", multiplayerRules = true, hideCPs = true}
	ctf:AddFlag{name = "ctf_flag1", homeRegion = "flag1_home", captureRegion = "flag2_home",
			capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3.0, 
			icon = "", mapIcon = "flag_icon", mapIconScale = 3.0}
	ctf:AddFlag{name = "ctf_flag2", homeRegion = "flag2_home", captureRegion = "flag1_home",
			capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3.0, 
			icon = "", mapIcon = "flag_icon", mapIconScale = 3.0}

	SoundEvent_SetupTeams( 1, 'cis', 2, 'rep' )

	ctf:Start()
	
	KillObject("CP1")
	KillObject("CP2")
	KillObject("CP3")
	KillObject("CP4")
	KillObject("CP5")
	KillObject("CP6")
	KillObject("CP7")
	KillObject("CP8")
	
	AddAIGoal(3, "Deathmatch", 1000)
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			music01 = "ssv_amb_03_start"
			music02 = "ssv_amb_03_mid"
			music03 = "ssv_amb_03_end"
			musicTimerValue = 180
		elseif RandomSide == 2 then
			music01 = "ssv_amb_05_start"
			music02 = "ssv_amb_05_mid"
			music03 = "ssv_amb_05_end"
			musicTimerValue = 130
		elseif RandomSide == 3 then
			music01 = "ssv_amb_04_start"
			music02 = "ssv_amb_04_mid"
			music03 = "ssv_amb_04_end"
			musicTimerValue = 240
		elseif RandomSide == 4 then
			music01 = "ssv_amb_04_start"
			music02 = "ssv_amb_04_mid"
			music03 = "ssv_amb_04_end"
			musicTimerValue = 240
		elseif RandomSide == 5 then
			music01 = "ssv_amb_08_start"
			music02 = "ssv_amb_08_mid"
			music03 = "ssv_amb_08_end"
			musicTimerValue = 180
		elseif RandomSide == 6 then
			music01 = "ssv_amb_07_start"
			music02 = "ssv_amb_07_mid"
			music03 = "ssv_amb_07_end"
			musicTimerValue = 150
		end
	else
		music01 = "ssv_amb_05_start"
		music02 = "ssv_amb_05_mid"
		music03 = "ssv_amb_05_end"
		musicTimerValue = 130
	end
	
	ScriptCB_PlayInGameMusic(music01)
	
	CreateTimer("music_timer")
		SetTimerValue("music_timer", musicTimerValue)
		StartTimer("music_timer")
		ShowTimer("music_timer")
		OnTimerElapse(
			function(timer)
				RandomMusic = math.random(1,3)
				
				if RandomMusic == 1 then
						print("execute music variation 1")
					ScriptCB_PlayInGameMusic(music01)
				elseif RandomMusic == 2 then
						print("execute music variation 2")
					ScriptCB_PlayInGameMusic(music02)
				elseif RandomMusic == 3 then
						print("execute music variation 3")
					ScriptCB_PlayInGameMusic(music03)
				end
				
				SetTimerValue("music_timer", musicTimerValue)
				StartTimer("music_timer")
			end,
			"music_timer"
		)
	
end

---------------------------------------------------------------------------
-- FUNCTION:    ScriptInit
-- PURPOSE:     This function is only run once
-- INPUT:
-- OUTPUT:
-- NOTES:       The name, 'ScriptInit' is a chosen convention, and each
--              mission script must contain a version of this function, as
--              it is called from C to start the mission.
---------------------------------------------------------------------------

function ScriptInit()
    -- Designers, these two lines *MUST* be first!
    StealArtistHeap(2048*1024)
    SetPS2ModelMemory(2097152 + 65536 * 6)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;tat2")
	PreLoadStuff()
	
    SetMaxFlyHeight(40)
	SetMaxPlayerFlyHeight(40) 
    
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\tat.lvl;tat2cw")
	ReadDataFile("SIDE\\tur.lvl", 
					"tur_bldg_laser",
					"tur_bldg_tat_barge")    
	ReadDataFile("SIDE\\des.lvl",
					"tat_inf_jawa")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\me5tur.lvl",
					"tur_bldg_mturret")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			LoadSSV()
			LoadGTH()
			Setup_SSVxGTH_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus GTH")
					
		elseif RandomSide == 2 then
			LoadSSV()
			LoadCOL()
			Setup_SSVxCOL_lg()
			DecideSSVHeroClass()
			SetHeroClass(CIS, "col_hero_harbinger")
					print("Load/setup SSV versus COL")
			
		elseif RandomSide == 3 then
			LoadSSV()
			LoadECL()
			Setup_SSVxECL_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus ECL")
			
		elseif RandomSide == 4 then
			LoadSSV()
			LoadGTH()
			LoadECL()
			Setup_GTHxECL_lg()
					print("Load/setup GTH versus ECL")
			
		elseif RandomSide == 5 then
			LoadSSV()
			LoadRPR()
			Setup_SSVxRPR_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus RPR")
					
		elseif RandomSide == 6 then
			LoadSSV()
			LoadCER()
			Setup_SSVxCER_lg()
			DecideSSVHeroClass()
					print("Load/setup SSV versus CER")
				
		end
	else
		LoadSSV()
		LoadCOL()
		Setup_SSVxCOL_lg()
			print("decide ssv hero::legion")
		SetHeroClass(REP, "ssv_hero_legion")
		SetHeroClass(CIS, "col_hero_harbinger")
				print("Load/setup SSV versus COL")
		
	end
	
	-- SetHeroClass(REP, "ssv_hero_shepard_vanguard")
	
	-- Jawas --------------------------
	SetTeamName (3, "locals")
	AddUnitClass (3, "tat_inf_jawa", 7)
	SetUnitCount (3, 7)
	SetTeamAsFriend(3,ATT)
	SetTeamAsFriend(3,DEF)
	SetTeamAsFriend(ATT,3)
	SetTeamAsFriend(DEF,3)
	-----------------------------------

    --  Level Stats
    ClearWalkers()
    AddWalkerType(0, 3) -- special -> droidekas
    AddWalkerType(1, 0) -- 1x2 (1 pair of legs)
    AddWalkerType(2, 0) -- 2x2 (2 pairs of legs)
    AddWalkerType(3, 0) -- 3x2 (3 pairs of legs)
    local weaponCnt = 230
    SetMemoryPoolSize("Aimer", 30)
    SetMemoryPoolSize("AmmoCounter", weaponCnt)
    SetMemoryPoolSize("BaseHint", 325)
    SetMemoryPoolSize("EnergyBar", weaponCnt)
    SetMemoryPoolSize("EntityCloth", 20)
	SetMemoryPoolSize("EntityFlyer", 6) -- to account for rocket upgrade
	SetMemoryPoolSize("EntitySoundStream", 2)
    SetMemoryPoolSize("EntitySoundStatic", 43)
    SetMemoryPoolSize("FlagItem", 2)
    SetMemoryPoolSize("MountedTurret", 20)
    SetMemoryPoolSize("Navigator", 50)
    SetMemoryPoolSize("Obstacle", 664)
    SetMemoryPoolSize("PathFollower", 50)
    SetMemoryPoolSize("PathNode", 256)
    SetMemoryPoolSize("SoldierAnimation", 405)
    SetMemoryPoolSize("TentacleSimulator", 0)
    SetMemoryPoolSize("TreeGridStack", 325)
    SetMemoryPoolSize("Weapon", weaponCnt)

    SetSpawnDelay(10.0, 0.25)
    ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ME5\\tat2.lvl", "tat2_ctf")
    SetDenseEnvironment("false")


    --  Sound Stats
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\Sound\\ME5.lvl",  "ME5n_music")
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\Sound\\ME5.lvl",  "TAT_ambiance")
    OpenAudioStream("sound\\tat.lvl",  "tat2")
    OpenAudioStream("sound\\tat.lvl",  "tat2")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")

	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			SSVWorldVO()
			GTHWorldVO()
		elseif RandomSide == 2 then
			SSVWorldVO()
		elseif RandomSide == 3 then
			SSVWorldVO()
		elseif RandomSide == 4 then
			GTHWorldVO()
		elseif RandomSide == 5 then
			SSVWorldVO()
		elseif RandomSide == 6 then
			SSVWorldVO()
		end
	else
		SSVWorldVO()
	end
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
	
	SoundFX()


    SetAttackingTeam(ATT)

    --  Camera Stats
    --Tat2 Mos Eisley
	AddCameraShot(0.974338, -0.222180, 0.035172, 0.008020, -82.664650, 23.668301, 43.955681);
	AddCameraShot(0.390197, -0.089729, -0.893040, -0.205362, 23.563562, 12.914885, -101.465561);
	AddCameraShot(0.169759, 0.002225, -0.985398, 0.012916, 126.972809, 4.039628, -22.020613);
	AddCameraShot(0.677453, -0.041535, 0.733016, 0.044942, 97.517807, 4.039628, 36.853477);
	AddCameraShot(0.866029, -0.156506, 0.467299, 0.084449, 7.685640, 7.130688, -10.895234);
end


