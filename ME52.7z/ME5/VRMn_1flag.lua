-- RandomLayout = math.random(1,2)
--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--

-- load the gametype script
Conquest = ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ME5_RandomSides")
ScriptCB_DoFile("ME5_MapFunctions")
	
	--  REP Attacking (attacker is always #1)
    REP = 1;
    CIS = 2;
	-- CD1 = 3;
    --  These variables do not change
    ATT = REP;
    DEF = CIS;

function ScriptPostLoad()
	
	
	SoundEvent_SetupTeams( CIS, 'cis', REP, 'rep' )
	
	print("start 1flag objective")
    --This sets up the actual objective.  This needs to happen after cp's are defined
    ctf = ObjectiveOneFlagCTF:New{teamATT = 1, teamDEF = 2,
                           textATT = "game.modes.1flag", textDEF = "game.modes.1flag2",
                           captureLimit = 5, flag = "flag1", flagIcon = "flag_icon", 
                           flagIconScale = 3.0, homeRegion = "homeregion1",
                           captureRegionATT = "team1_capture1", captureRegionDEF = "team2_capture1",
                           capRegionMarkerATT = "hud_objective_icon_circle", capRegionMarkerDEF = "hud_objective_icon_circle",
                           capRegionMarkerScaleATT = 3.0, capRegionMarkerScaleDEF = 3.0, multiplayerRules = true}
    ctf:Start()
	print("end 1flag objective")
    
    EnableSPHeroRules()
	
	AddAIGoal(1, "Defend", 70, "team1_capture1")
	AddAIGoal(2, "Defend", 70, "team2_capture1")
	AddAIGoal(1, "Defend", 40, "flag_null_defend")
	AddAIGoal(2, "Defend", 40, "flag_null_defend")
	
	
	--This defines the CPs.  These need to happen first
	-- if RandomLayout == 1 then
		--[[KillObject("cp1_2")
		KillObject("cp2_2")
		KillObject("cp3_2")
		KillObject("cp4_2")
		KillObject("cp5_2")]]
		
		VRM_DisableBarriers1()
		
		--[[cp1 = CommandPost:New{name = "cp1_1"}
		cp2 = CommandPost:New{name = "cp2_1"}
		cp3 = CommandPost:New{name = "cp3_1"}
		cp4 = CommandPost:New{name = "cp4_1"}
		cp5 = CommandPost:New{name = "cp5_1"}]]
		
		--[[print("DEBUG::501 A.I. goals - layout 1")
		ClearAIGoals(1)
		AddAIGoal(ATT, "Conquest", 100)
		AddAIGoal(ATT, "Defend", 20, "cp1_1")
		AddAIGoal(ATT, "Defend", 20, "cp2_1")
		AddAIGoal(ATT, "Defend", 20, "cp3_1")
		AddAIGoal(ATT, "Defend", 20, "cp4_1")
		AddAIGoal(ATT, "Defend", 20, "cp5_1")
		
		ClearAIGoals(2)
		AddAIGoal(DEF, "Conquest", 100)
		AddAIGoal(DEF, "Defend", 20, "cp1_1")
		AddAIGoal(DEF, "Defend", 20, "cp2_1")
		AddAIGoal(DEF, "Defend", 20, "cp3_1")
		AddAIGoal(DEF, "Defend", 20, "cp4_1")
		AddAIGoal(DEF, "Defend", 20, "cp5_1")]]
		
	--[[elseif RandomLayout == 2 then
		KillObject("cp1_1")
		KillObject("cp2_1")
		KillObject("cp3_1")
		KillObject("cp4_1")
		KillObject("cp5_1")
		
		VRM_DisableBarriers1()
		
		cp1 = CommandPost:New{name = "cp1_2"}
		cp2 = CommandPost:New{name = "cp2_2"}
		cp3 = CommandPost:New{name = "cp3_2"}
		cp4 = CommandPost:New{name = "cp4_2"}
		cp5 = CommandPost:New{name = "cp5_2"}
		
		--[[print("DEBUG::501 A.I. goals - layout 2")
		ClearAIGoals(1)
		AddAIGoal(ATT, "Conquest", 100)
		AddAIGoal(ATT, "Defend", 20, "cp1_2")
		AddAIGoal(ATT, "Defend", 20, "cp2_2")
		AddAIGoal(ATT, "Defend", 20, "cp3_2")
		AddAIGoal(ATT, "Defend", 20, "cp4_2")
		AddAIGoal(ATT, "Defend", 20, "cp5_2")
		
		ClearAIGoals(2)
		AddAIGoal(DEF, "Conquest", 100)
		AddAIGoal(DEF, "Defend", 20, "cp1_2")
		AddAIGoal(DEF, "Defend", 20, "cp2_2")
		AddAIGoal(DEF, "Defend", 20, "cp3_2")
		AddAIGoal(DEF, "Defend", 20, "cp4_2")
		AddAIGoal(DEF, "Defend", 20, "cp5_2")]]
		
	end]]
	
	
	--[[ClearAIGoals(1)
	ClearAIGoals(2)
	AddAIGoal(1, "Conquest", 1000)
	AddAIGoal(2, "Conquest", 1000)]]
	
	-- AddDeathRegion("deathregion01")
	
	--[[if RandomLayout == 1 then
		SetProperty("cp1_1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
		SetProperty("cp2_1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
		SetProperty("cp3_1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
		SetProperty("cp4_1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
		SetProperty("cp5_1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
		SetProperty("cp1_1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
		SetProperty("cp2_1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
		SetProperty("cp3_1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
		SetProperty("cp4_1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
		SetProperty("cp5_1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	elseif RandomLayout == 2 then
		SetProperty("cp1_2", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
		SetProperty("cp2_2", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
		SetProperty("cp3_2", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
		SetProperty("cp4_2", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
		SetProperty("cp5_2", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
		SetProperty("cp1_2", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
		SetProperty("cp2_2", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
		SetProperty("cp3_2", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
		SetProperty("cp4_2", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
		SetProperty("cp5_2", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	end]]
	
	ScriptCB_PlayInGameMusic("ssv_amb_06_start")
	
	CreateTimer("music_timer")
		SetTimerValue("music_timer", 185)
		StartTimer("music_timer")
		ShowTimer("music_timer")
		OnTimerElapse(
			function(timer)
				RandomMusic = math.random(1,3)
				
				if RandomMusic == 1 then
						print("execute music variation 1")
					ScriptCB_PlayInGameMusic("ssv_amb_06_start")
				elseif RandomMusic == 2 then
						print("execute music variation 2")
					ScriptCB_PlayInGameMusic("ssv_amb_06_mid")
				elseif RandomMusic == 3 then
						print("execute music variation 3")
					ScriptCB_PlayInGameMusic("ssv_amb_06_end")
				end
				
				SetTimerValue("music_timer", 185)
				StartTimer("music_timer")
			end,
			"music_timer"
		)
	
end


---------------------------------------------------------------------------
-- FUNCTION:    ScriptInit
-- PURPOSE:     This function is only run once
-- INPUT:
-- OUTPUT:
-- NOTES:       The name, 'ScriptInit' is a chosen convention, and each
--              mission script must contain a version of this function, as
--              it is called from C to start the mission.
---------------------------------------------------------------------------
function ScriptInit()
    
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\vrm1.lvl")
	PreLoadStuff()
	
	SetTeamAggressiveness(REP,(1.00))
	SetTeamAggressiveness(CIS,(1.00))
    
   
    SetMaxFlyHeight(30)
    SetMaxPlayerFlyHeight (30)
    
    SetMemoryPoolSize ("ClothData",20)
    SetMemoryPoolSize ("Combo",50)              -- should be ~ 2x number of jedi classes
    SetMemoryPoolSize ("Combo::State",650)      -- should be ~12x #Combo
    SetMemoryPoolSize ("Combo::Transition",650) -- should be a bit bigger than #Combo::State
    SetMemoryPoolSize ("Combo::Condition",650)  -- should be a bit bigger than #Combo::State
    SetMemoryPoolSize ("Combo::Attack",550)     -- should be ~8-12x #Combo
    SetMemoryPoolSize ("Combo::DamageSample",6000)  -- should be ~8-12x #Combo::Attack
    SetMemoryPoolSize ("Combo::Deflect",100)     -- should be ~1x #combo  
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\kas.lvl;kas2cw")
	
	LoadSSV()
	LoadGTH()
	Setup_SSVxGTH_xs()
	if not ScriptCB_InMultiplayer() then
		DecideSSVHeroClass()
	else
			print("decide ssv hero::infiltrator")
		SetHeroClass(REP, "ssv_hero_shepard_infiltrator")
	end
			print("Load/setup SSV versus GTH")
		
	SetAIDifficulty(-3, 4)
	
	
    --  Level Stats
    --  ClearWalkers()
    AddWalkerType(0, 0) -- special -> droidekas
    AddWalkerType(1, 0) -- 1x2 (1 pair of legs)
    AddWalkerType(2, 0) -- 2x2 (2 pairs of legs)
    AddWalkerType(3, 0) -- 3x2 (3 pairs of legs)
    local weaponCnt = 1024
    SetMemoryPoolSize("Aimer", 75)
    SetMemoryPoolSize("AmmoCounter", weaponCnt)
    SetMemoryPoolSize("BaseHint", 1024)
    SetMemoryPoolSize("EnergyBar", weaponCnt)
	SetMemoryPoolSize("EntityCloth", 32)
	SetMemoryPoolSize("EntityFlyer", 32)
    SetMemoryPoolSize("EntityHover", 32)
    SetMemoryPoolSize("EntityLight", 200)
    SetMemoryPoolSize("EntitySoundStream", 4)
    SetMemoryPoolSize("EntitySoundStatic", 32)
	SetMemoryPoolSize("FlagItem", 1)
	SetMemoryPoolSize("FLEffectObject::OffsetMatrix", 122)
    SetMemoryPoolSize("MountedTurret", 32)
	SetMemoryPoolSize("Navigator", 128)
    SetMemoryPoolSize("Obstacle", 1024)
	SetMemoryPoolSize("PathNode", 1024)
	SetMemoryPoolSize("SoldierAnimation", 230)
    SetMemoryPoolSize("SoundSpaceRegion", 64)
    SetMemoryPoolSize("TreeGridStack", 1024)
	SetMemoryPoolSize("UnitAgent", 128)
	SetMemoryPoolSize("UnitController", 128)
	SetMemoryPoolSize("Weapon", weaponCnt)
    
    SetSpawnDelay(10.0, 0.25)
    --ReadDataFile("dc:VRM\\VRM.lvl", "VRM_conquest")
	-- if RandomLayout == 1 then
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ME5\\VRM.lvl", "VRM_1flag1")
		
	--[[elseif RandomLayout == 2 then
		ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ME5\\VRM.lvl", "VRM_conquest2")
		
	end]]
	SetDenseEnvironment("true")




    --  Sound

    voiceSlow = OpenAudioStream("sound\\global.lvl", "rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "cis_unit_vo_slow", voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", voiceSlow)
    
    voiceQuick = OpenAudioStream("sound\\global.lvl", "rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl", "cis_unit_vo_quick", voiceQuick)
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5n_music")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5_ambiance")
    OpenAudioStream("sound\\kas.lvl",  "kas")
    OpenAudioStream("sound\\kas.lvl",  "kas")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")

    SSVWorldVO()
    GTHWorldVO()
	
	SetVictoryMusic(REP, "ssv_amb_01_victory")
	SetDefeatMusic (REP, "ssv_amb_01_defeat")
	SetVictoryMusic(CIS, "ssv_amb_01_victory")
	SetDefeatMusic (CIS, "ssv_amb_01_defeat")
	
	SoundFX()


--OpeningSatelliteShot
	AddCameraShot(0.993613, -0.112590, -0.007516, -0.000852, -144.671204, 12.469149, 105.698982);
	AddCameraShot(0.003597, -0.000253, -0.997521, -0.070274, -144.042343, 12.469149, 64.159500);
	AddCameraShot(0.583016, -0.093302, -0.796945, -0.127537, -190.497482, 12.469149, 81.069817);
	AddCameraShot(0.615988, -0.086602, 0.775356, 0.109007, -97.931252, 12.469149, 71.429901);
	AddCameraShot(0.900297, -0.099467, -0.421196, -0.046535, -191.081924, 12.469149, 159.755737);
	AddCameraShot(0.943805, -0.094135, 0.315250, 0.031443, -95.917686, 12.469149, 164.284882);
	AddCameraShot(0.039136, -0.004479, -0.992743, -0.113616, -145.351196, 12.469149, 7.593871);
end

