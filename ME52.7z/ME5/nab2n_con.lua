RandomSide = math.random(1,6)
--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--

-- load the gametype script
    Conquest = ScriptCB_DoFile("ObjectiveConquest")
    ScriptCB_DoFile("setup_teams") 
	ScriptCB_DoFile("ME5_RandomSides")

--  Empire Attacking (attacker is always #1)
    CIS = 1
    REP = 2
    GAR = 3
--  These variables do not change
    ATT = 1
    DEF = 2
    
 ---------------------------------------------------------------------------
 -- FUNCTION:    ScriptInit
 -- PURPOSE:     This function is only run once
 -- INPUT:
 -- OUTPUT:
 -- NOTES:       The name, 'ScriptInit' is a chosen convention, and each
 --              mission script must contain a version of this function, as
 --              it is called from C to start the mission.
 ---------------------------------------------------------------------------
function ScriptPostLoad()
	DisableBarriers("cambar1")
	DisableBarriers("cambar2")
	DisableBarriers("cambar3")
	DisableBarriers("turbar1")
	DisableBarriers("turbar2")
	DisableBarriers("turbar3")
	DisableBarriers("camveh")
    SetMapNorthAngle(180, 1)
    AddAIGoal (GAR, "Deathmatch", 100)
 
	AICanCaptureCP("CP1", GAR, false)
	AICanCaptureCP("CP2", GAR, false)
	AICanCaptureCP("CP3", GAR, false)
	AICanCaptureCP("CP4", GAR, false)
	AICanCaptureCP("CP5", GAR, false)
	AICanCaptureCP("CP6", GAR, false)
   
    --This defines the CPs.  These need to happen first
    cp1 = CommandPost:New{name = "CP1"}
    cp2 = CommandPost:New{name = "CP2"}
    cp3 = CommandPost:New{name = "CP3"}
    cp4 = CommandPost:New{name = "CP4"}
    cp5 = CommandPost:New{name = "CP5"}
    cp6 = CommandPost:New{name = "CP6"}
    
    --This sets up the actual objective.  This needs to happen after cp's are defined
    conquest = ObjectiveConquest:New{teamATT = ATT, teamDEF = DEF, 
                                     textATT = "game.modes.con", 
                                     textDEF = "game.modes.con2",
                                     multiplayerRules = true}
    
    --This adds the CPs to the objective.  This needs to happen after the objective is set up
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)
  
  
    
    conquest:Start()   
    EnableSPHeroRules()
	
	SetProperty("CP1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP2", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP3", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP4", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP5", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP6", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("CP1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP2", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP3", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP4", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP5", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("CP6", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp4", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp5", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp4", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp5", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp6", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			
			SetProperty("cp1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp3", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp4", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp5", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp6", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp3", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp4", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp5", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp6", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp2", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp3", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp4", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp5", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp6", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp2", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp3", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp4", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp5", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp6", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
		elseif RandomSide == 2 then
			herosupport = AIHeroSupport:New{AIATTHeroHealth = 4000, AIDEFHeroHealth = 4000, gameMode = "NonConquest",}
			herosupport:SetHeroClass(CIS, "col_hero_harbinger")
			herosupport:AddSpawnCP("cp1","cp1spawn")
			herosupport:AddSpawnCP("cp2","cp2spawn")
			herosupport:AddSpawnCP("cp3","cp3spawn")
			herosupport:AddSpawnCP("cp4","cp4spawn")
			herosupport:AddSpawnCP("cp5","cp5spawn")
			herosupport:AddSpawnCP("cp6","cp6spawn")
			herosupport:Start()
			
			SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp4", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp5", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp4", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp5", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp6", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		elseif RandomSide == 3 then
			SetProperty("cp1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp4", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp5", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp2", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp3", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp4", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp5", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp6", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
		elseif RandomSide == 4 then			
			SetProperty("cp1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp3", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp4", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp5", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp6", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp3", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp4", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp5", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp6", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp1", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp2", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp3", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp4", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp5", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp6", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp1", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("cp2", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("cp3", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("cp4", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("cp5", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("cp6", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
		end
	else
		SetProperty("cp1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
		SetProperty("cp2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
		SetProperty("cp3", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
		SetProperty("cp4", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
		SetProperty("cp5", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
		SetProperty("cp6", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
		SetProperty("cp1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
		SetProperty("cp2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
		SetProperty("cp3", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
		SetProperty("cp4", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
		SetProperty("cp5", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
		SetProperty("cp6", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
		SetProperty("cp1", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
		SetProperty("cp2", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
		SetProperty("cp3", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
		SetProperty("cp4", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
		SetProperty("cp5", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
		SetProperty("cp6", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
		SetProperty("cp1", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
		SetProperty("cp2", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
		SetProperty("cp3", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
		SetProperty("cp4", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
		SetProperty("cp5", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
		SetProperty("cp6", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
	end
	
end

function ScriptInit()
    StealArtistHeap(1200*1024)
    -- Designers, these two lines *MUST* be first!
    SetPS2ModelMemory(3100000)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;nab2")
	PreLoadStuff()
	
    ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\nab.lvl;nab2cw")
    ReadDataFile("SIDE\\tur.lvl", 
                "tur_bldg_laser")
				
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			LoadSSV()
			LoadGTH()
			Setup_SSVxGTH_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus GTH")
					
		elseif RandomSide == 2 then
			LoadSSV()
			LoadCOL()
			Setup_SSVxCOL_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus COL")
			
		elseif RandomSide == 3 then
			LoadSSV()
			LoadECL()
			Setup_SSVxECL_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus ECL")
			
		elseif RandomSide == 4 then
			LoadSSV()
			LoadGTH()
			LoadECL()
			Setup_GTHxECL_med()
					print("Load/setup GTH versus ECL")
			
		elseif RandomSide == 5 then
			LoadSSV()
			LoadRPR()
			Setup_SSVxRPR_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus RPR")
					
		elseif RandomSide == 6 then
			LoadSSV()
			LoadCER()
			Setup_SSVxCER_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus CER")
		end
	else
		LoadSSV()
		LoadGTH()
		LoadECL()
		Setup_GTHxECL_med()
				print("Load/setup GTH versus ECL")
		
	end

    
--    SetTeamAsEnemy(GAR, ATT)
--    SetTeamAsEnemy(ATT, GAR)
--       
--    
--    SetTeamAsFriend(GAR, DEF)
--    SetTeamAsFriend(DEF, GAR)

    --  Level Stats
    ClearWalkers()
    AddWalkerType(0, 0) -- 8 droidekas with 0 leg pairs each
    AddWalkerType(1, 0) -- ATSTs
    local weaponCnt = 220
    SetMemoryPoolSize("Aimer", 50)
    SetMemoryPoolSize("AmmoCounter", weaponCnt)
    SetMemoryPoolSize("BaseHint", 128)
    SetMemoryPoolSize("EnergyBar", weaponCnt)
    SetMemoryPoolSize("EntityCloth", 18)
    SetMemoryPoolSize("EntitySoundStream", 1)
    SetMemoryPoolSize("EntitySoundStatic", 44)
    SetMemoryPoolSize("EntityHover", 4)
    SetMemoryPoolSize("MountedTurret", 11)
    SetMemoryPoolSize("Navigator", 40)
    SetMemoryPoolSize("Obstacle", 450)
    SetMemoryPoolSize("PathFollower", 40)
    SetMemoryPoolSize("PathNode", 200)
    SetMemoryPoolSize("TreeGridStack", 400)
    SetMemoryPoolSize("UnitAgent", 40)
    SetMemoryPoolSize("UnitController", 40)
    SetMemoryPoolSize("Weapon", weaponCnt)
	SetMemoryPoolSize("EntityFlyer", 6)   
    
    SetSpawnDelay(10.0, 0.25)
    ReadDataFile("NAB\\nab2.lvl","naboo2_Conquest")
    SetDenseEnvironment("true")
    --AddDeathRegion("Water")
    AddDeathRegion("Waterfall")
    SetMaxFlyHeight(25)
    SetMaxPlayerFlyHeight (25)

    

    --  Sound
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5n_music")
    -- OpenAudioStream("sound\\global.lvl",  "global_vo_quick")
    -- OpenAudioStream("sound\\global.lvl",  "global_vo_slow")
    OpenAudioStream("sound\\nab.lvl",  "nab2")
    OpenAudioStream("sound\\nab.lvl",  "nab2")
    OpenAudioStream("sound\\nab.lvl",  "nab2_emt")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")

    if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			Music04()
			
			SSVWorldVO()
			GTGWorldVO()
		elseif RandomSide == 2 then
			Music05()
			
			SSVWorldVO()
		elseif RandomSide == 3 then
			Music04()
			
			SSVWorldVO()
		elseif RandomSide == 4 then
			Music04()
			
			GTHWorldVO()
		elseif RandomSide == 5 then
			Music08()
			
			SSVWorldVO()
		elseif RandomSide == 6 then
			Music07()
			
			SSVWorldVO()
		end
	else
		Music04()
		
		GTHWorldVO()
	end
	
	SoundFX()
	
	
    --  Camera Stats
    --Nab2 Theed
    --Palace
    AddCameraShot(0.038177, -0.005598, -0.988683, -0.144973, -0.985535, 18.617458, -123.316505);
    AddCameraShot(0.993106, -0.109389, 0.041873, 0.004612, 6.576932, 24.040697, -25.576218);
    AddCameraShot(0.851509, -0.170480, 0.486202, 0.097342, 158.767715, 22.913860, -0.438658);
    AddCameraShot(0.957371, -0.129655, -0.255793, -0.034641, 136.933548, 20.207420, 99.608246);
    AddCameraShot(0.930364, -0.206197, 0.295979, 0.065598, 102.191856, 22.665434, 92.389435);
    AddCameraShot(0.997665, -0.068271, 0.002086, 0.000143, 88.042351, 13.869274, 93.643898);
    AddCameraShot(0.968900, -0.100622, 0.224862, 0.023352, 4.245263, 13.869274, 97.208542);
    AddCameraShot(0.007091, -0.000363, -0.998669, -0.051089, -1.309990, 16.247049, 15.925866);
    AddCameraShot(-0.274816, 0.042768, -0.949121, -0.147705, -55.505108, 25.990822, 86.987534);
    AddCameraShot(0.859651, -0.229225, 0.441156, 0.117634, -62.493008, 31.040747, 117.995369);
    AddCameraShot(0.703838, -0.055939, 0.705928, 0.056106, -120.401054, 23.573559, -15.484946);
    AddCameraShot(0.835474, -0.181318, -0.506954, -0.110021, -166.314774, 27.687098, -6.715797);
    AddCameraShot(0.327573, -0.024828, -0.941798, -0.071382, -109.700180, 15.415476, -84.413605);
    AddCameraShot(-0.400505, 0.030208, -0.913203, -0.068878, 82.372711, 15.415476, -42.439548);
    
    end

