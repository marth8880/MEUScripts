RandomSide = math.random(1,4)
--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("ME5_RandomSides")

---------------------------------------------------------------------------
-- ScriptPostLoad
---------------------------------------------------------------------------
function ScriptPostLoad()
	cp1 = CommandPost:New{name = "cp1"}
	cp2 = CommandPost:New{name = "cp2"}
	cp3 = CommandPost:New{name = "cp3"}
	cp4 = CommandPost:New{name = "cp4"}
	cp5 = CommandPost:New{name = "cp5"}
	
	--This sets up the actual objective.	This needs to happen after cp's are defined
	conquest = ObjectiveConquest:New{teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true}
	
	--This adds the CPs to the objective.	This needs to happen after the objective is set up
	conquest:AddCommandPost(cp1)
	conquest:AddCommandPost(cp2)
	conquest:AddCommandPost(cp3)
	conquest:AddCommandPost(cp4)
	conquest:AddCommandPost(cp5)
	
	SetProperty("cp1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp2", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp3", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp4", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp5", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp2", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp3", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp4", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp5", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp4", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp5", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp4", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp5", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			
			SetProperty("cp1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp3", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp4", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp5", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp3", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp4", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp5", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp2", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp3", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp4", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp5", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp2", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp3", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp4", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp5", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
		elseif RandomSide == 2 then
			SetProperty("cp1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp4", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp5", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp2", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp3", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp4", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp5", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
		elseif RandomSide == 3 then
			SetProperty("cp1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp3", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp4", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp5", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp3", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp4", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp5", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp2", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp3", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp4", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp5", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp2", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp3", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp4", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp5", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
		end
	else
		SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp4", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp5", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
		SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp4", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		SetProperty("cp5", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
	end
	
	conquest:Start()

	EnableSPHeroRules()
end

---------------------------------------------------------------------------
-- ScriptInit
---------------------------------------------------------------------------
function ScriptInit()
    StealArtistHeap(700*1024)   -- steal from art heap
    -- Designers, these two lines *MUST* be first!
    SetPS2ModelMemory(4087000)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;tat3")
	PreLoadStuff()

	--	Empire Attacking (attacker is always #1)
	REP = 1
	CIS = 2
	CD1 = 3
	--	These variables do not change
	ATT = 1
	DEF = 2


	-- Memory settings ---------------------------------------------------------------------
	SetMemoryPoolSize("Combo::Condition", 100)
    SetMemoryPoolSize("Combo::State", 160)
    SetMemoryPoolSize("Combo::Transition", 100)
	local weaponCnt = 190
	SetMemoryPoolSize("ActiveRegion", 8)
	SetMemoryPoolSize("Aimer", 10)
	SetMemoryPoolSize("AmmoCounter", weaponCnt)
	SetMemoryPoolSize("BaseHint", 105)
	SetMemoryPoolSize("EnergyBar", weaponCnt)
	SetMemoryPoolSize("EntityCloth", 17)
	SetMemoryPoolSize("EntityFlyer", 6) -- to account for rocket upgrade
	SetMemoryPoolSize("EntityLight", 141)
	SetMemoryPoolSize("EntitySoundStatic", 3)
	SetMemoryPoolSize("EntitySoundStream", 2)
	SetMemoryPoolSize("FLEffectObject::OffsetMatrix", 50)
	SetMemoryPoolSize("MountedTurret", 1)
	SetMemoryPoolSize("Navigator", 35)
	SetMemoryPoolSize("Obstacle", 200)
	SetMemoryPoolSize("PathNode", 196)
	SetMemoryPoolSize("PathFollower", 35)
	SetMemoryPoolSize("RedOmniLight", 146) 
	SetMemoryPoolSize("SoundSpaceRegion", 80)
	SetMemoryPoolSize("TentacleSimulator", 12)
	SetMemoryPoolSize("TreeGridStack", 75)
	SetMemoryPoolSize("UnitAgent", 35)
	SetMemoryPoolSize("UnitController", 35)
	SetMemoryPoolSize("Weapon", weaponCnt)
	----------------------------------------------------------------------------------------

	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\tat.lvl;tat3cw")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			LoadSSV()
			LoadGTH()
			Setup_SSVxGTH_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus GTH")
			
		elseif RandomSide == 2 then
			LoadSSV()
			LoadECL()
			Setup_SSVxECL_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus ECL")
			
		elseif RandomSide == 3 then
			LoadSSV()
			LoadGTH()
			LoadECL()
			Setup_GTHxECL_med()
					print("Load/setup GTH versus ECL")
				
		elseif RandomSide == 4 then
			LoadSSV()
			LoadCER()
			Setup_SSVxCER_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus CER")
				
		end
	else
		LoadSSV()
		LoadECL()
		Setup_SSVxECL_med()
			print("decide ssv hero::jack")
		SetHeroClass(REP, "ssv_hero_jack")
				print("Load/setup SSV versus ECL")
		
	end

	--[[ Gamorrean Guards
	ReadDataFile("SIDE\\gam.lvl",
		"gam_inf_gamorreanguard")
	SetTeamName(3, "locals")
	AddUnitClass(3, "gam_inf_gamorreanguard",3)
	SetUnitCount(3, 2)
	SetTeamAsEnemy(3, ATT)
	SetTeamAsEnemy(3, DEF) 
	SetTeamAsEnemy(ATT, 3)
	SetTeamAsEnemy(DEF, 3)
	AddAIGoal(3,"Deathmatch",100)
	]]

	SetSpawnDelay(10.0, 0.25)

	--	Level Stats
	ClearWalkers()
	AddWalkerType(0, 0) -- Droidekas
	AddWalkerType(1, 0)
	AddWalkerType(2, 0)

	SetSpawnDelay(10.0, 0.25)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ME5\\tat3.lvl", "tat3_con")
	SetDenseEnvironment("true")
	--AddDeathRegion("Sarlac01")
	
	SetMaxFlyHeight(90)
	SetMaxPlayerFlyHeight(90)
    AISnipeSuitabilityDist(30)
	
	

	--	Sound Stats
	
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5n_music")
	OpenAudioStream("sound\\tat.lvl",	"tat3")
	OpenAudioStream("sound\\tat.lvl",	"tat3")
	OpenAudioStream("sound\\tat.lvl",	"tat3_emt")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")

	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			Music06()
			
			SSVWorldVO()
			GTHWorldVO()
		elseif RandomSide == 2 then
			Music04()
			
			SSVWorldVO()
		elseif RandomSide == 3 then
			Music04()
			
			GTHWorldVO()
		elseif RandomSide == 4 then
			Music06()
			
			SSVWorldVO()
		end
	else
		Music04()
		
		SSVWorldVO()
	end
	
	SoundFX()

	--	Camera Stats
	--Tat 3 - Jabbas' Palace
	AddCameraShot(0.685601, -0.253606, -0.639994, -0.236735, -65.939224, -0.176558, 127.400444)
	AddCameraShot(0.786944, 0.050288, -0.613719, 0.039218, -80.626396, 1.175180, 133.205551)
	AddCameraShot(0.997982, 0.061865, -0.014249, 0.000883, -65.227898, 1.322798, 123.976990)
	AddCameraShot(-0.367869, -0.027819, -0.926815, 0.070087, -19.548307, -5.736280, 163.360519)
	AddCameraShot(0.773980, -0.100127, -0.620077, -0.080217, -61.123989, -0.629283, 176.066025)
	AddCameraShot(0.978189, 0.012077, 0.207350, -0.002560, -88.388947, 5.674968, 153.745255)
	AddCameraShot(-0.144606, -0.010301, -0.986935, 0.070304, -106.872772, 2.066469, 102.783096)
	AddCameraShot(0.926756, -0.228578, -0.289446, -0.071390, -60.819584, -2.117482, 96.400620)
	AddCameraShot(0.873080, 0.134285, 0.463274, -0.071254, -52.071609, -8.430746, 67.122437)
	AddCameraShot(0.773398, -0.022789, -0.633236, -0.018659, -32.738083, -7.379394, 81.508003)
	AddCameraShot(0.090190, 0.005601, -0.993994, 0.061733, -15.379695, -9.939115, 72.110054)
	AddCameraShot(0.971737, -0.118739, -0.202524, -0.024747, -16.591295, -1.371236, 147.933029)
	AddCameraShot(0.894918, 0.098682, -0.432560, 0.047698, -20.577391, -10.683214, 128.752563)
end
