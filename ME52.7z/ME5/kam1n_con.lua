RandomSide = math.random(1,5)
-- end
--
-- Copyright (c) 2005 Pandemic Studios, LLC. All rights reserved.
--

ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("ME5_RandomSides")

    --  REP Attacking (attacker is always #1)
    REP = 2;
    CIS = 1;
	CD1 = 3;
    --  These variables do not change
    ATT = 1;
    DEF = 2;
---------------------------------------------------------------------------
-- FUNCTION:    ScriptInit
-- PURPOSE:     This function is only run once
-- INPUT:
-- OUTPUT:
-- NOTES:       The name, 'ScriptInit' is a chosen convention, and each
--              mission script must contain a version of this function, as
--              it is called from C to start the mission.
---------------------------------------------------------------------------



function ScriptPostLoad()
DisableBarriers("frog")
DisableBarriers("close")
DisableBarriers("camp")

    UnblockPlanningGraphArcs("connection71")

     SetProperty("cp1", "Team", "1")
    SetProperty("cp2", "Team", "2")
    SetProperty("cp3", "Team", "2")
    SetProperty("cp4", "Team", "2")
    SetProperty("cp5", "Team", "1")
    SetProperty("cp6", "Team", "1")
    SetAIDamageThreshold("Comp1", 0 )
    SetAIDamageThreshold("Comp2", 0 )
    SetAIDamageThreshold("Comp3", 0 )
    SetAIDamageThreshold("Comp4", 0 )
    SetAIDamageThreshold("Comp5", 0 )
  	SetAIDamageThreshold("Comp6", 0 )
    SetAIDamageThreshold("Comp7", 0 )
    SetAIDamageThreshold("Comp8", 0 )
    SetAIDamageThreshold("Comp9", 0 )
    SetAIDamageThreshold("Comp10", 0 )



	        SetProperty("Kam_Bldg_Podroom_Door32", "Islocked", 1)

    SetProperty("Kam_Bldg_Podroom_Door33", "Islocked", 1)
        SetProperty("Kam_Bldg_Podroom_Door32", "Islocked", 1)
                SetProperty("Kam_Bldg_Podroom_Door34", "Islocked", 1)
    SetProperty("Kam_Bldg_Podroom_Door35", "Islocked", 1)
        SetProperty("Kam_Bldg_Podroom_Door27", "Islocked", 0)       
            SetProperty("Kam_Bldg_Podroom_Door28", "Islocked", 1)       
    SetProperty("Kam_Bldg_Podroom_Door36", "Islocked", 1)
        SetProperty("Kam_Bldg_Podroom_Door20", "Islocked", 0)
    UnblockPlanningGraphArcs("connection71")
        
   --Objective1
    UnblockPlanningGraphArcs("connection85")
        UnblockPlanningGraphArcs("connection48")
            UnblockPlanningGraphArcs("connection63")
                UnblockPlanningGraphArcs("connection59")
                         UnblockPlanningGraphArcs("close")
                         UnblockPlanningGraphArcs("open")
                         DisableBarriers("frog")
                         DisableBarriers("close")
                         DisableBarriers("open")
        
    --blocking Locked Doors
    UnblockPlanningGraphArcs("connection194");
        UnblockPlanningGraphArcs("connection200");
            UnblockPlanningGraphArcs("connection118");
               DisableBarriers("FRONTDOOR2-3");
                DisableBarriers("FRONTDOOR2-1");  
                 DisableBarriers("FRONTDOOR2-2");  
   
    --Lower cloning facility
    UnblockPlanningGraphArcs("connection10")
        UnblockPlanningGraphArcs("connection159")
            UnblockPlanningGraphArcs("connection31")
               DisableBarriers("FRONTDOOR1-3")
                DisableBarriers("FRONTDOOR1-1")  
                 DisableBarriers("FRONTDOOR1-2")
    
        --This defines the CPs.  These need to happen first
    cp1 = CommandPost:New{name = "cp1"}
    cp2 = CommandPost:New{name = "cp2"}
    cp3 = CommandPost:New{name = "cp3"}
    cp4 = CommandPost:New{name = "cp4"}
    cp5 = CommandPost:New{name = "cp5"}
   	cp6 = CommandPost:New{name = "cp6"}
    
    --This sets up the actual objective.  This needs to happen after cp's are defined
    conquest = ObjectiveConquest:New{teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true}
    
    --This adds the CPs to the objective.  This needs to happen after the objective is set up
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
 	conquest:AddCommandPost(cp6)
conquest:Start()
 
    EnableSPHeroRules()
    
    SetProperty("cp2", "spawnpath", "cp2_spawn")
    SetProperty("cp2", "captureregion", "cp2_capture")
    
    BlockPlanningGraphArcs("group1");
        BlockPlanningGraphArcs("connection165");
            BlockPlanningGraphArcs("connection162");
                BlockPlanningGraphArcs("connection160");
                    BlockPlanningGraphArcs("connection225");
	
	SetProperty("cp1", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp2", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp3", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp4", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp5", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp6", "VO_Rep_RepCapture", "ssv_adm_com_report_captured_commandpost")
	SetProperty("cp1", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp2", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp3", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp4", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp5", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	SetProperty("cp6", "VO_Rep_RepLost", "ssv_adm_com_report_lost_commandpost")
	
	if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp4", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp5", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_CisCapture", "ssv_adm_com_report_gthCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp4", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp5", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			SetProperty("cp6", "VO_Rep_CisLost", "ssv_adm_com_report_gthLost_commandpost")
			
			SetProperty("cp1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp3", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp4", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp5", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp6", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp3", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp4", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp5", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp6", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp1", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp2", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp3", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp4", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp5", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp6", "VO_Cis_RepCapture", "gth_ann_com_report_ssvCaptured_commandpost")
			SetProperty("cp1", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp2", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp3", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp4", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp5", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
			SetProperty("cp6", "VO_Cis_RepLost", "gth_ann_com_report_ssvLost_commandpost")
		elseif RandomSide == 2 then
			herosupport = AIHeroSupport:New{AIATTHeroHealth = 4000, AIDEFHeroHealth = 4000, gameMode = "NonConquest",}
			herosupport:SetHeroClass(CIS, "col_hero_harbinger")
			herosupport:AddSpawnCP("cp1","cp1_spawn")
			herosupport:AddSpawnCP("cp2","path33")
			herosupport:AddSpawnCP("cp3","cp3_spawn")
			herosupport:AddSpawnCP("cp4","path32")
			herosupport:AddSpawnCP("cp5","cp5_spawn")
			herosupport:AddSpawnCP("cp6","path31")
			herosupport:Start()
			
			SetProperty("cp1", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp4", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp5", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_CisCapture", "ssv_adm_com_report_colCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp2", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp3", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp4", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp5", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
			SetProperty("cp6", "VO_Rep_CisLost", "ssv_adm_com_report_colLost_commandpost")
		elseif RandomSide == 3 then
			SetProperty("cp1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp2", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp3", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp4", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp5", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp6", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
			SetProperty("cp1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp2", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp3", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp4", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp5", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
			SetProperty("cp6", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
		elseif RandomSide == 4 then			
			SetProperty("cp1", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp2", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp3", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp4", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp5", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp6", "VO_Cis_CisCapture", "gth_ann_com_report_captured_commandpost")
			SetProperty("cp1", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp2", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp3", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp4", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp5", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp6", "VO_Cis_CisLost", "gth_ann_com_report_lost_commandpost")
			SetProperty("cp1", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp2", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp3", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp4", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp5", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp6", "VO_Cis_ImpCapture", "gth_ann_com_report_eclCaptured_commandpost")
			SetProperty("cp1", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("cp2", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("cp3", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("cp4", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("cp5", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
			SetProperty("cp6", "VO_Cis_ImpLost", "gth_ann_com_report_eclLost_commandpost")
		end
	else
		SetProperty("cp1", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("cp2", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("cp3", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("cp4", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("cp5", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("cp6", "VO_Rep_ImpCapture", "ssv_adm_com_report_eclCaptured_commandpost")
		SetProperty("cp1", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
		SetProperty("cp2", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
		SetProperty("cp3", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
		SetProperty("cp4", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
		SetProperty("cp5", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
		SetProperty("cp6", "VO_Rep_ImpLost", "ssv_adm_com_report_eclLost_commandpost")
	end
	
end

function ScriptInit()
	StealArtistHeap(2048*1024)
    -- Designers, these two lines *MUST* be first!
    SetPS2ModelMemory(3000000)
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\Load\\load.lvl;kam1")
    PreLoadStuff()
	
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl;ME5n")
	ReadDataFile("sound\\kam.lvl;kam1cw")
	ReadDataFile("SIDE\\tur.lvl", 
					"tur_bldg_laser")
	ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\SIDE\\me5tur.lvl",
					"tur_bldg_mturret")
	
    if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			LoadSSV()
			LoadGTH()
			Setup_SSVxGTH_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus GTH")
				
		elseif RandomSide == 2 then
			LoadSSV()
			LoadCOL()
			Setup_SSVxCOL_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus COL")
				
		elseif RandomSide == 3 then
			LoadSSV()
			LoadECL()
			Setup_SSVxECL_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus ECL")
				
		elseif RandomSide == 4 then
			LoadSSV()
			LoadGTH()
			LoadECL()
			Setup_GTHxECL_med()
					print("Load/setup GTH versus ECL")
		
		elseif RandomSide == 5 then
			LoadSSV()
			LoadCER()
			Setup_SSVxCER_med()
			DecideSSVHeroClass()
					print("Load/setup SSV versus CER")
		end
	else
		LoadSSV()
		LoadECL()
		Setup_SSVxECL_med()
			print("decide ssv hero::legion")
		SetHeroClass(REP, "ssv_hero_legion")
				print("Load/setup SSV versus ECL")
			
	end
	
	
    --  Level Stats
    ClearWalkers()
 
    AddWalkerType(0, 0) -- droidekas
    local weaponCnt = 215
    SetMemoryPoolSize("Aimer", 39)
    SetMemoryPoolSize("AmmoCounter", weaponCnt)
    SetMemoryPoolSize("BaseHint", 210)
    SetMemoryPoolSize("EnergyBar", weaponCnt)
    SetMemoryPoolSize("EntityCloth", 18)
	SetMemoryPoolSize("EntityHover", 10)
    SetMemoryPoolSize("EntityLight", 70)
    SetMemoryPoolSize("EntitySoundStream", 3)
    SetMemoryPoolSize("EntitySoundStatic", 84)
    SetMemoryPoolSize("MountedTurret", 25)
    SetMemoryPoolSize("Navigator", 50)
    SetMemoryPoolSize("Obstacle", 800)
    SetMemoryPoolSize("PathFollower", 50)
    SetMemoryPoolSize("PathNode", 256)
	SetMemoryPoolSize("SoldierAnimation", 280)
    SetMemoryPoolSize("SoundSpaceRegion", 36)
    SetMemoryPoolSize("TentacleSimulator", 0)
    SetMemoryPoolSize("TreeGridStack", 338)
    SetMemoryPoolSize("UnitAgent", 50)
    SetMemoryPoolSize("EntityFlyer", 6)
    SetMemoryPoolSize("UnitController", 50)
    SetMemoryPoolSize("Weapon", weaponCnt)
    
    SetSpawnDelay(10.0, 0.25)
    ReadDataFile("..\\..\\addon\\ME5\\data\\_LVL_PC\\ME5\\kam1.lvl", "kamino1_conquest")
    SetDenseEnvironment("false")

    --  AI
    SetMinFlyHeight(60)
    SetAllowBlindJetJumps(0)
       SetMaxFlyHeight(102)
    SetMaxPlayerFlyHeight(102)

    --  Sound
    
    OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ME5n_music")
    OpenAudioStream("sound\\kam.lvl",  "kam1")
    OpenAudioStream("sound\\kam.lvl",  "kam1")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "col_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "gth_unit_vo_quick")
	OpenAudioStream("..\\..\\addon\\ME5\\data\\_LVL_PC\\sound\\ME5.lvl",  "ssv_unit_vo_quick")

    if not ScriptCB_InMultiplayer() then
		if RandomSide == 1 then
			Music03()
			
			SSVWorldVO()
			GTHWorldVO()
		elseif RandomSide == 2 then
			Music05()
			
			SSVWorldVO()
		elseif RandomSide == 3 then
			Music03()
			
			SSVWorldVO()
		elseif RandomSide == 4 then
			Music04()
			
			GTHWorldVO()
		elseif RandomSide == 5 then
			Music07()
			
			SSVWorldVO()
		end
	else
		Music03()
		
		SSVWorldVO()
	end
	
	SoundFX()


    SetAttackingTeam(ATT)

    AddDeathRegion("deathregion")

 		    AddCameraShot(0.564619, -0.121047, 0.798288, 0.171142, 68.198814, 79.137611, 110.850922);

            AddCameraShot(-0.281100, 0.066889, -0.931340, -0.221616, 10.076019, 82.958336, -26.261774);

            AddCameraShot(0.209553, -0.039036, -0.960495, -0.178923, 92.558563, 58.820618, 130.675919);

            AddCameraShot(0.968794, 0.154227, 0.191627, -0.030506, -173.914413, 69.858940, 52.532421);

            AddCameraShot(0.744389, 0.123539, 0.647364, -0.107437, 97.475639, 53.216236, 76.477089);

            AddCameraShot(-0.344152, 0.086702, -0.906575, -0.228393, 95.062233, 105.285820, -37.661552);
end
